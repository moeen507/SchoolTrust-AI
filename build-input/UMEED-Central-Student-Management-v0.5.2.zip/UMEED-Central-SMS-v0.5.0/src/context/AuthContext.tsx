import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import type { AppUser, Role } from '../lib/types'
import { isSupabaseConfigured, supabase } from '../lib/supabase'
import { getRuntimeBackendConfig } from '../lib/runtimeConfig'

const demoUsers: Record<Role, AppUser> = {
  owner: { id: 'demo-owner', name: 'Organization Owner', email: 'owner@demo.local', role: 'owner', organizationId: 'org-demo', organizationName: 'UMEED Education System' },
  super_admin: { id: 'demo-super', name: 'Super Admin', email: 'super@demo.local', role: 'super_admin', organizationId: 'org-demo', organizationName: 'UMEED Education System' },
  admin: { id: 'demo-admin', name: 'School Admin', email: 'admin@demo.local', role: 'admin', organizationId: 'org-demo', organizationName: 'UMEED Education System' },
  cashier: { id: 'demo-cashier', name: 'Main Cashier', email: 'cashier@demo.local', role: 'cashier', organizationId: 'org-demo', organizationName: 'UMEED Education System' },
  accountant: { id: 'demo-accountant', name: 'Accountant', email: 'accounts@demo.local', role: 'accountant', organizationId: 'org-demo', organizationName: 'UMEED Education System' },
  student: { id: 'demo-student', name: 'Kaneez Zainab', email: 'student@demo.local', role: 'student', organizationId: 'org-demo', organizationName: 'UMEED Education System' },
  guardian: { id: 'demo-guardian', name: 'Guardian Account', email: 'guardian@demo.local', role: 'guardian', organizationId: 'org-demo', organizationName: 'UMEED Education System' },
  auditor: { id: 'demo-auditor', name: 'Auditor', email: 'audit@demo.local', role: 'auditor', organizationId: 'org-demo', organizationName: 'UMEED Education System' },
  academic_manager: { id: 'demo-academic', name: 'Academic Manager', email: 'academic@demo.local', role: 'academic_manager', organizationId: 'org-demo', organizationName: 'UMEED Education System' },
  teacher: { id: 'demo-teacher', name: 'Subject Teacher', email: 'teacher@demo.local', role: 'teacher', organizationId: 'org-demo', organizationName: 'UMEED Education System' },
  store_clerk: { id: 'demo-store', name: 'Student Store Clerk', email: 'store@demo.local', role: 'store_clerk', organizationId: 'org-demo', organizationName: 'UMEED Education System' },
  canteen_cashier: { id: 'demo-canteen', name: 'Canteen Cashier', email: 'canteen@demo.local', role: 'canteen_cashier', organizationId: 'org-demo', organizationName: 'UMEED Education System' },
  platform_owner: { id: 'demo-platform', name: 'SaaS Platform Owner', email: 'platform@demo.local', role: 'platform_owner', organizationId: 'platform', organizationName: 'UMEED Central SaaS' },
  platform_support: { id: 'demo-support', name: 'Platform Support', email: 'support@demo.local', role: 'platform_support', organizationId: 'platform', organizationName: 'UMEED Central SaaS' },
  platform_billing: { id: 'demo-billing', name: 'Platform Billing', email: 'billing@demo.local', role: 'platform_billing', organizationId: 'platform', organizationName: 'UMEED Central SaaS' },
  support_viewer: { id: 'demo-support-viewer', name: 'Platform Support', email: 'support@demo.local', role: 'support_viewer', organizationId: 'org-demo', organizationName: 'UMEED Education System', platformRole:'platform_support', supportSessionId:'demo-support-session' },
}

type AuthValue = {
  user: AppUser | null
  loading: boolean
  liveMode: boolean
  signIn: (email: string, password: string) => Promise<void>
  demoSignIn: (role: Role) => void
  signOut: () => Promise<void>
  exitSupportMode: () => Promise<void>
}

const AuthContext = createContext<AuthValue | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AppUser | null>(null)
  const [loading, setLoading] = useState(isSupabaseConfigured)

  useEffect(() => {
    if (!supabase || !isSupabaseConfigured) return
    let active = true
    async function hydrate() {
      const { data } = await supabase!.auth.getSession()
      if (!active) return
      if (!data.session?.user) { setUser(null); setLoading(false); return }

      const authUser = data.session.user
      const { data: platform } = await supabase!.from('v_my_platform_role').select('*').maybeSingle()
      if (platform?.role) {
        const [{ data: profile },{data:support}] = await Promise.all([
          supabase!.from('profiles').select('full_name').eq('id', authUser.id).maybeSingle(),
          supabase!.from('v_my_support_session').select('*').maybeSingle(),
        ])
        const name=profile?.full_name || authUser.email || 'Platform user'
        if(support?.id){
          setUser({id:authUser.id,name,email:authUser.email||'',role:'support_viewer',organizationId:support.organization_id,organizationName:support.organization_name,platformRole:platform.role,supportSessionId:support.id})
        }else{
          setUser({ id:authUser.id,name,email:authUser.email||'',role:platform.role,organizationId:'platform',organizationName:'UMEED Central SaaS',platformRole:platform.role })
        }
        setLoading(false); return
      }

      const { data: member } = await supabase!.from('v_my_active_membership').select('*').limit(1).maybeSingle()
      if (member) setUser({ id:authUser.id,name:member.full_name || authUser.email || 'User',email:authUser.email || '',role:member.role,organizationId:member.organization_id,organizationName:member.organization_name })
      else setUser(null)
      setLoading(false)
    }
    hydrate()
    const { data: listener } = supabase.auth.onAuthStateChange(() => hydrate())
    return () => { active = false; listener.subscription.unsubscribe() }
  }, [])

  const value = useMemo<AuthValue>(() => ({
    user, loading, liveMode: isSupabaseConfigured,
    async signIn(identifier, password) {
      if (!supabase) throw new Error('Supabase is not configured. Use demo access or add environment variables.')
      const orgSlug = getRuntimeBackendConfig().orgSlug
      const raw = identifier.trim()
      const email = raw.includes('@') ? raw : `${raw.toLowerCase()}@${orgSlug}.students.invalid`
      const { error } = await supabase.auth.signInWithPassword({ email, password })
      if (error) throw error
    },
    demoSignIn(role) { setUser(demoUsers[role]) },
    async signOut() { if (supabase && isSupabaseConfigured) await supabase.auth.signOut(); setUser(null) },
    async exitSupportMode(){
      if(user?.role!=='support_viewer') return
      if(supabase&&isSupabaseConfigured){const {error}=await supabase.rpc('end_support_session');if(error)throw error;window.location.reload();return}
      setUser(demoUsers[user.platformRole??'platform_support'])
    },
  }), [user, loading])

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export const useAuth = () => {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('AuthProvider missing')
  return ctx
}
