import { useEffect, useState } from 'react'
import { Banknote, Calculator, CheckCircle2, LockKeyhole, RefreshCw } from 'lucide-react'
import { closeCashierShift, getOpenCashierShift, openCashierShift } from '../lib/repository'
import { compactMoney } from '../lib/format'
import type { CashierShift } from '../lib/types'

export function OperationsPage(){
  const [shift,setShift]=useState<CashierShift|null>(null); const [opening,setOpening]=useState('0'); const [counted,setCounted]=useState(''); const [busy,setBusy]=useState(false); const [result,setResult]=useState<any>(null); const [error,setError]=useState('')
  async function load(){setShift(await getOpenCashierShift())} useEffect(()=>{load()},[])
  async function open(){setBusy(true);setError('');try{await openCashierShift(Math.round(Number(opening)*100));await load()}catch(e:any){setError(e.message)}finally{setBusy(false)}}
  async function close(){if(!shift)return;setBusy(true);setError('');try{const r=await closeCashierShift(shift.id,Math.round(Number(counted)*100));setResult(r);setShift(null)}catch(e:any){setError(e.message)}finally{setBusy(false)}}
  return <>
    <div className="page-head"><div><span className="eyebrow">Cash control</span><h1>Cashier Closing</h1><p>Opening float, expected cash, physical count and variance are controlled independently from accounting reports.</p></div><div className="security-inline"><LockKeyhole size={16}/>Audited shift workflow</div></div>
    {error&&<div className="form-error wide-error">{error}</div>}{result&&<div className="notice-banner"><CheckCircle2 size={17}/><span>Shift closed. Expected {compactMoney(result.expected_cash_minor)}, counted {compactMoney(result.counted_cash_minor)}, variance {compactMoney(result.variance_minor)}.</span></div>}
    <section className="operations-grid">
      <article className="card action-card"><div className="action-icon"><Banknote/></div><h3>{shift?'Shift is open':'Open cashier shift'}</h3>{shift?<><div className="shift-stat"><span>Opened</span><strong>{new Date(shift.openedAt).toLocaleString()}</strong></div><div className="shift-stat"><span>Opening float</span><strong>{compactMoney(shift.openingCashMinor)}</strong></div><label>Physical cash count at close (PKR)<input type="number" min="0" value={counted} onChange={e=>setCounted(e.target.value)} placeholder="Count drawer cash"/></label><button className="button primary" disabled={busy||counted===''} onClick={close}><Calculator size={16}/>Close & calculate variance</button></>:<><p>Start a controlled cash session before collecting at the counter.</p><label>Opening float (PKR)<input type="number" min="0" value={opening} onChange={e=>setOpening(e.target.value)}/></label><button className="button primary" disabled={busy} onClick={open}><Banknote size={16}/>Open shift</button></>}</article>
      <article className="card"><div className="card-head"><div><span className="eyebrow">Control model</span><h3>Reconciliation rules</h3></div><button className="icon-button" onClick={load}><RefreshCw size={16}/></button></div><div className="control-list"><div><span>01</span><p><strong>Expected cash</strong>Opening float + cash receipts − approved cash refunds.</p></div><div><span>02</span><p><strong>Counted cash</strong>Physical drawer count is entered by the closing user.</p></div><div><span>03</span><p><strong>Variance</strong>Any shortage/overage is stored and visible to accounting/audit.</p></div><div><span>04</span><p><strong>Bank deposits</strong>Recorded separately so cash collection and deposit timing are never confused.</p></div></div></article>
    </section>
  </>
}
