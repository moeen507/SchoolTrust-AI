import { useEffect, useState } from 'react'
import { ArrowLeft, Printer, ReceiptText } from 'lucide-react'
import { Link, useParams } from 'react-router-dom'
import { getReceipt } from '../lib/repository'
import { formatMoney } from '../lib/format'
import type { ReceiptRecord } from '../lib/types'
import { printCurrentPage, saveCurrentPagePdf, isDesktop } from '../lib/desktop'

export function ReceiptPage(){
  const {receiptNo=''}=useParams(); const [r,setR]=useState<ReceiptRecord|null>(null); const [loading,setLoading]=useState(true)
  useEffect(()=>{getReceipt(receiptNo).then(setR).finally(()=>setLoading(false))},[receiptNo])
  if(loading)return <div className="boot-screen"><span>Loading receipt…</span></div>
  if(!r)return <div className="empty-state tall"><ReceiptText/><strong>Receipt not found</strong><Link className="button ghost" to="/reports"><ArrowLeft size={15}/>Back</Link></div>
  return <div className="receipt-page"><div className="receipt-actions no-print"><Link className="button ghost" to="/"><ArrowLeft size={15}/>Workspace</Link><div style={{display:'flex',gap:8}}><button className="button ghost" onClick={()=>printCurrentPage()}><Printer size={16}/>Print</button><button className="button primary" onClick={()=>saveCurrentPagePdf(`${r.receiptNo}.pdf`)}><Printer size={16}/>{isDesktop?'Save PDF':'Print / Save PDF'}</button></div></div><article className="print-receipt"><header><div className="receipt-logo">U</div><div><h1>{r.organizationName}</h1><p>Official Fee Receipt</p></div><div className="receipt-number"><span>Receipt No.</span><strong>{r.receiptNo}</strong></div></header><div className="receipt-rule"/><section className="receipt-meta"><div><span>Student</span><strong>{r.studentName}</strong></div><div><span>Admission No.</span><strong>{r.admissionNo}</strong></div><div><span>Class</span><strong>{r.className}-{r.section}</strong></div><div><span>Date</span><strong>{new Date(r.receivedAt).toLocaleString()}</strong></div><div><span>Method</span><strong>{r.paymentMethod.toUpperCase()}</strong></div><div><span>Guardian</span><strong>{r.guardianName||'—'}</strong></div></section><section className="receipt-total"><span>Amount received</span><strong>{formatMoney(r.amountMinor)}</strong></section><section className="receipt-breakdown"><div><span>Allocated to dues</span><strong>{formatMoney(r.allocatedMinor)}</strong></div><div><span>Advance created</span><strong>{formatMoney(r.creditCreatedMinor)}</strong></div><div><span>Refunded</span><strong>{formatMoney(r.refundedMinor)}</strong></div></section><footer><p>This receipt is generated from the centralized ledger. Financial corrections are recorded as auditable reversals and do not overwrite original transactions.</p><div><span>System generated</span><strong>{r.receiptNo}</strong></div></footer></article></div>
}
