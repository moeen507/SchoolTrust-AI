import { useEffect, useState } from 'react'
import { ArrowUpRight, BookOpenCheck, CalendarDays, CircleDollarSign, Clock3, Coffee, CreditCard, GraduationCap, ReceiptText, RefreshCw, ShoppingBag, TrendingUp, Users, WalletCards } from 'lucide-react'
import { Link } from 'react-router-dom'
import { KpiCard } from '../components/KpiCard'
import { SparkBars } from '../components/SparkBars'
import { DefaulterModal } from '../components/DefaulterModal'
import { compactMoney, formatMoney } from '../lib/format'
import { getCollectionTrend, getDashboardMetrics } from '../lib/repository'
import { mockActivity, mockMetrics, mockTrend } from '../lib/mock'
import type { DashboardMetrics, TrendPoint } from '../lib/types'

export function DashboardPage() {
  const [metrics, setMetrics] = useState<DashboardMetrics>(mockMetrics)
  const [trend, setTrend] = useState<TrendPoint[]>(mockTrend)
  const [loading, setLoading] = useState(true)
  const [alert, setAlert] = useState(false)

  async function load() {
    setLoading(true)
    try { const [m,t] = await Promise.all([getDashboardMetrics(), getCollectionTrend()]); setMetrics(m); setTrend(t) } catch {} finally { setLoading(false) }
  }
  useEffect(() => { load() }, [])
  useEffect(() => { const day = new Date().getDate(); if (!loading && day >= 8 && metrics.defaulters > 0) { const t=setTimeout(()=>setAlert(true),650); return ()=>clearTimeout(t) } }, [loading,metrics.defaulters])

  return <>
    <DefaulterModal open={alert} onClose={()=>setAlert(false)} count={metrics.defaulters} outstanding={metrics.outstanding}/>
    <div className="page-head"><div><span className="eyebrow">Student management command center</span><h1>Institute Overview</h1><p>Central view of student finance, academic operations and daily student services.</p></div><div className="page-head-actions"><button className="button ghost" onClick={load}><RefreshCw size={16} className={loading?'spin':''}/>Refresh</button><Link className="button primary" to="/collect"><ReceiptText size={16}/>New fee receipt</Link></div></div>


    <section className="workspace-launch-grid">
      <Link to="/collect"><div><WalletCards size={18}/><span>Fee Counter</span></div><strong>School fees</strong><small>Tuition, annual fund, dues and advance credit</small></Link>
      <Link to="/sales"><div><ShoppingBag size={18}/><span>Student Store</span></div><strong>Books & items</strong><small>Independent STU slip series linked to students</small></Link>
      <Link to="/sales"><div><Coffee size={18}/><span>Canteen</span></div><strong>Canteen sales</strong><small>Independent CAN slip series and student history</small></Link>
      <Link to="/academic"><div><BookOpenCheck size={18}/><span>Academic Hub</span></div><strong>Performance</strong><small>Attendance, exams, marks and promotion</small></Link>
    </section>

    <section className="kpi-grid">
      <KpiCard icon={CircleDollarSign} label="Collected today" value={compactMoney(metrics.today)} hint="Payment date basis" accent="green"/>
      <KpiCard icon={CalendarDays} label="This week" value={compactMoney(metrics.week)} hint="Current business week"/>
      <KpiCard icon={TrendingUp} label="This month" value={compactMoney(metrics.month)} hint="Net after refunds" accent="blue"/>
      <KpiCard icon={CreditCard} label="Outstanding" value={compactMoney(metrics.outstanding)} hint={`${metrics.defaulters} current defaulters`} accent="red"/>
    </section>

    <section className="dashboard-grid">
      <article className="card span-2 collection-card">
        <div className="card-head"><div><span className="eyebrow">7-day movement</span><h3>Collection trend</h3></div><button className="text-button">Detailed report <ArrowUpRight size={15}/></button></div>
        <div className="chart-summary"><div><span>Month net</span><strong>{formatMoney(metrics.net)}</strong></div><div className="summary-split"><span><i className="dot good"/>Gross {compactMoney(metrics.gross)}</span><span><i className="dot bad"/>Refunds {compactMoney(metrics.refunds)}</span></div></div>
        <SparkBars data={trend}/>
      </article>
      <article className="card health-card">
        <div className="card-head"><div><span className="eyebrow">Month status</span><h3>Fee health</h3></div><span className="status-pill good">Live</span></div>
        <div className="ring-wrap"><div className="ring" style={{'--pct': `${Math.round((metrics.paidThisMonth/metrics.students)*100)}%`} as React.CSSProperties}><div><strong>{Math.round((metrics.paidThisMonth/metrics.students)*100)}%</strong><span>paid</span></div></div></div>
        <div className="mini-stats"><div><strong>{metrics.paidThisMonth}</strong><span>Paid</span></div><div><strong>{metrics.partialThisMonth}</strong><span>Partial</span></div><div><strong>{metrics.defaulters}</strong><span>Due</span></div></div>
      </article>
      <article className="card span-2">
        <div className="card-head"><div><span className="eyebrow">Operations</span><h3>Recent activity</h3></div><button className="text-button">View audit log</button></div>
        <div className="activity-list">{mockActivity.map((a)=><div className="activity-row" key={a.id}><div className={`activity-mark ${a.tone}`}><ReceiptText size={16}/></div><div><strong>{a.title}</strong><span>{a.detail}</span></div><time><Clock3 size={13}/>{a.time}</time></div>)}</div>
      </article>
      <article className="card">
        <div className="card-head"><div><span className="eyebrow">Scale snapshot</span><h3>Organization</h3></div></div>
        <div className="org-stat"><Users size={18}/><div><strong>{metrics.students}</strong><span>Active students</span></div></div>
        <div className="org-stat"><GraduationCap size={18}/><div><strong>14</strong><span>Classes / groups</span></div></div>
        <div className="org-stat"><ReceiptText size={18}/><div><strong>{compactMoney(metrics.academicYear)}</strong><span>Academic year collection</span></div></div>
      </article>
    </section>
  </>
}
