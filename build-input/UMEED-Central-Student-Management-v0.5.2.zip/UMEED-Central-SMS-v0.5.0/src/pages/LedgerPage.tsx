import { useEffect, useMemo, useState } from 'react'
import { BookOpen, Coffee, CreditCard, History, Printer, ReceiptText, Search, ShoppingBag, UserRound, X } from 'lucide-react'
import { Link } from 'react-router-dom'
import { getSaleSlips, getStudentLedger, getStudents } from '../lib/repository'
import { compactMoney, initials } from '../lib/format'
import type { LedgerEntry, SaleSlip, Student } from '../lib/types'

export function LedgerPage(){
  const [students,setStudents]=useState<Student[]>([])
  const [q,setQ]=useState('')
  const [classFilter,setClassFilter]=useState('All')
  const [selected,setSelected]=useState<Student|null>(null)
  const [ledger,setLedger]=useState<LedgerEntry[]>([])
  const [sales,setSales]=useState<SaleSlip[]>([])
  const [loading,setLoading]=useState(true)
  const [detailLoading,setDetailLoading]=useState(false)

  useEffect(()=>{getStudents().then(setStudents).finally(()=>setLoading(false))},[])
  const classes=useMemo(()=>['All',...Array.from(new Set(students.map(s=>s.className).filter(Boolean)))],[students])
  const visible=useMemo(()=>students.filter(s=>{
    const matchesClass=classFilter==='All'||s.className===classFilter
    const hay=[s.name,s.admissionNo,s.rollNo,s.guardian,s.phone,s.className,s.section].join(' ').toLowerCase()
    return matchesClass&&hay.includes(q.toLowerCase())
  }),[students,classFilter,q])

  async function openStudent(student:Student){
    setSelected(student); setDetailLoading(true)
    try{
      const [l,s]=await Promise.all([getStudentLedger(student.id),getSaleSlips({studentId:student.id,limit:30})])
      setLedger(l);setSales(s)
    } finally {setDetailLoading(false)}
  }

  const paid=ledger.filter(x=>x.entryType==='payment').reduce((a,x)=>a+x.creditMinor,0)
  const refunded=ledger.filter(x=>x.entryType==='refund').reduce((a,x)=>a+(x.debitMinor||x.creditMinor),0)
  const storeSpend=sales.filter(x=>x.channel==='student_store'&&x.status==='posted').reduce((a,x)=>a+x.totalMinor,0)
  const canteenSpend=sales.filter(x=>x.channel==='canteen'&&x.status==='posted').reduce((a,x)=>a+x.totalMinor,0)

  return <>
    <div className="page-head legacy-page-head"><div><span className="eyebrow">Central student financial truth</span><h1>Student Ledger</h1><p>Search any student and review the fee ledger, refunds, advance credit, store slips and canteen activity from one account.</p></div><div className="page-head-actions"><button className="button ghost" onClick={()=>window.print()}><Printer size={16}/>Print view</button></div></div>

    <section className="card ledger-master-card">
      <div className="ledger-filter-row">
        <div className="table-search ledger-search"><Search size={16}/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Roll no, student name, father name, class or phone..."/></div>
        <span className="record-count">{loading?'Loading…':`${visible.length} students`}</span>
      </div>
      <div className="class-pills">{classes.map(c=><button key={c} className={`class-pill ${classFilter===c?'active':''}`} onClick={()=>setClassFilter(c)}>{c}</button>)}</div>
      <div className="ledger-grid legacy-ledger-grid">
        {visible.map(s=><button className={`s-card ${s.outstanding>s.monthlyFee?'has-overdue':s.outstanding>0?'has-pending':''}`} key={s.id} onClick={()=>openStudent(s)}>
          <div className="s-card-head"><div className="s-card-avatar">{initials(s.name)}</div><div><div className="s-card-name">{s.name}</div><div className="s-card-sub">Roll {s.rollNo||'—'} · {s.className}-{s.section} · {s.guardian||'Guardian —'}</div></div></div>
          <div className="s-card-stats"><div className="s-mini-stat"><div className="s-mini-label">Monthly Fee</div><div className="s-mini-val">{compactMoney(s.monthlyFee)}</div></div><div className="s-mini-stat"><div className="s-mini-label">Outstanding</div><div className={`s-mini-val ${s.outstanding?'danger':'ok'}`}>{s.outstanding?compactMoney(s.outstanding):'Clear'}</div></div><div className="s-mini-stat"><div className="s-mini-label">Advance</div><div className={`s-mini-val ${s.advance?'ok':''}`}>{compactMoney(s.advance)}</div></div></div>
          <div className="s-card-tags"><span className="badge badge-gold">{s.admissionNo}</span><span className={`badge ${s.status==='active'?'badge-green':'badge-dim'}`}>{s.status}</span></div>
        </button>)}
        {!loading&&!visible.length&&<div className="empty-state tall"><UserRound size={34}/><strong>No student found</strong><span>Change the class filter or search term.</span></div>}
      </div>
    </section>

    {selected&&<><button className="ledger-backdrop" onClick={()=>setSelected(null)} aria-label="Close ledger"/><aside className="ledger-detail open">
      <div className="ld-header"><button className="ld-close" onClick={()=>setSelected(null)}><X size={17}/></button><div className="ld-student"><strong>{selected.name}</strong><span>Roll {selected.rollNo||'—'} · {selected.className}-{selected.section} · Father/Guardian: {selected.guardian||'—'}</span></div><span className="badge badge-gold">{selected.admissionNo}</span></div>
      <div className="ld-body">
        <div className="stats-row ledger-detail-stats"><div className="stat-card"><div className="stat-label">Total Paid</div><div className="stat-value money ok">{compactMoney(Math.max(0,paid-refunded))}</div></div><div className="stat-card"><div className="stat-label">Outstanding</div><div className={`stat-value money ${selected.outstanding?'danger':'ok'}`}>{compactMoney(selected.outstanding)}</div></div><div className="stat-card"><div className="stat-label">Advance Credit</div><div className="stat-value money ok">{compactMoney(selected.advance)}</div></div></div>
        <div className="fund-row"><div className={`fund-card ${selected.annualFund>0?'unpaid-fund':'paid-fund'}`}><div className="fund-name">Annual Fund</div><div className="fund-status">{selected.annualFund>0?compactMoney(selected.annualFund):'CLEAR'}</div><div className="fund-detail">Tracked separately from monthly tuition</div></div><div className="fund-card paid-fund"><div className="fund-name">Student Store</div><div className="fund-status">{compactMoney(storeSpend)}</div><div className="fund-detail">Independent STU slip ledger</div></div><div className="fund-card paid-fund"><div className="fund-name">Canteen</div><div className="fund-status">{compactMoney(canteenSpend)}</div><div className="fund-detail">Independent CAN slip ledger</div></div></div>

        <div className="card-title old-card-title"><div className="card-title-bar"/>Fee transaction history</div>
        <div className="table-outer"><table><thead><tr><th>Date</th><th>Reference</th><th>Type</th><th>Debit</th><th>Credit</th></tr></thead><tbody>{ledger.map((r,i)=><tr key={`${r.reference}-${i}`}><td>{new Date(r.occurredAt).toLocaleDateString()}</td><td><span className="badge badge-gold">{r.label}</span></td><td>{r.entryType}</td><td className="money-due">{r.debitMinor?compactMoney(r.debitMinor):'—'}</td><td className="money-ok">{r.creditMinor?compactMoney(r.creditMinor):'—'}</td></tr>)}</tbody></table>{!detailLoading&&!ledger.length&&<div className="empty-state"><History size={26}/><span>No fee ledger entries.</span></div>}</div>

        <div className="card-title old-card-title services-title"><div className="card-title-bar"/>Student services history</div>
        <div className="service-ledger-list">{sales.map(s=><Link to={`/sale-slip/${encodeURIComponent(s.slipNo)}`} key={s.saleId}><div className={`service-ledger-icon ${s.channel}`} >{s.channel==='canteen'?<Coffee size={15}/>:<ShoppingBag size={15}/>}</div><div><strong>{s.slipNo}</strong><span>{s.items.map(i=>`${i.name} × ${i.quantity}`).join(', ')}</span></div><div><b>{compactMoney(s.totalMinor)}</b><span>{new Date(s.soldAt).toLocaleDateString()}</span></div></Link>)}{!detailLoading&&!sales.length&&<div className="empty-state compact"><ShoppingBag size={22}/><span>No store or canteen slips.</span></div>}</div>

        <div className="ld-actions"><Link className="button primary" to="/collect"><CreditCard size={15}/>Collect fee</Link><Link className="button ghost" to="/sales"><BookOpen size={15}/>Student services</Link><button className="button ghost" onClick={()=>window.print()}><ReceiptText size={15}/>Print statement</button></div>
      </div>
    </aside></>}
  </>
}
