import { useState } from 'react'
import { ArrowRight, Building2, Eye, EyeOff, LockKeyhole, ShieldCheck, Sparkles } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import type { Role } from '../lib/types'
import { Logo } from '../components/Logo'

export function LoginPage() {
  const { signIn, demoSignIn, liveMode } = useAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [show, setShow] = useState(false)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setError(''); setBusy(true)
    try { await signIn(email, password) } catch (err: any) { setError(err.message || 'Sign in failed') } finally { setBusy(false) }
  }

  return <div className="login-page">
    <div className="login-visual">
      <div className="login-orb orb-one"/><div className="login-orb orb-two"/>
      <div className="login-hero-copy">
        <div className="hero-badge"><Sparkles size={15}/> Commercial SaaS foundation</div>
        <h1>One student record.<br/><span>Academics, finance and daily services.</span></h1>
        <p>Centralized student records, academics, fee operations, store and canteen slips, mobile self-service and audit-ready reporting.</p>
        <div className="hero-proof-grid">
          <div><strong>Central Ledger</strong><span>Single source of truth</span></div>
          <div><strong>Role Security</strong><span>Database-enforced access</span></div>
          <div><strong>Realtime</strong><span>Live collection visibility</span></div>
        </div>
      </div>
    </div>
    <div className="login-panel">
      <div className="login-box">
        <Logo />
        <div className="login-heading"><span className="eyebrow">Secure workspace</span><h2>Welcome back</h2><p>Sign in to your organization workspace.</p></div>
        {liveMode ? <form onSubmit={submit} className="login-form">
          <label>Email or Student Login ID<input type="text" value={email} onChange={(e)=>setEmail(e.target.value)} placeholder="name@school.com or UES-201616" required/></label>
          <label>Password<div className="password-input"><input type={show ? 'text':'password'} value={password} onChange={(e)=>setPassword(e.target.value)} placeholder="Enter your password" required/><button type="button" onClick={()=>setShow(!show)}>{show?<EyeOff size={17}/>:<Eye size={17}/>}</button></div></label>
          {error && <div className="form-error">{error}</div>}
          <button className="button primary login-submit" disabled={busy}>{busy ? 'Signing in...' : 'Sign in'}<ArrowRight size={17}/></button>
        </form> : <div className="demo-access">
          <div className="demo-note"><ShieldCheck size={18}/><div><strong>Preview build</strong><span>Connect Supabase env variables to switch to live auth.</span></div></div>
          <button className="button primary login-submit" onClick={()=>demoSignIn('super_admin')}>Open Admin Workspace <ArrowRight size={17}/></button>
          <div className="demo-grid">
            {([['cashier','Fee Cashier'],['store_clerk','Student Store'],['canteen_cashier','Canteen'],['academic_manager','Academic'],['student','Student'],['platform_owner','SaaS Owner']] as [Role,string][]).map(([role,label])=><button key={role} onClick={()=>demoSignIn(role)}><Building2 size={15}/>{label}</button>)}
          </div>
        </div>}
        <div className="login-footer"><LockKeyhole size={14}/> Protected by tenant-scoped authorization and encrypted transport</div>
      </div>
    </div>
  </div>
}
