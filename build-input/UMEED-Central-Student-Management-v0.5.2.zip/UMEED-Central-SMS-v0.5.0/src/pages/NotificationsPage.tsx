import { useEffect, useState } from 'react'
import { Bell, Mail, MessageSquare, RefreshCw, Send, Smartphone } from 'lucide-react'
import { getNotificationSummary } from '../lib/repository'
import type { NotificationQueueSummary } from '../lib/types'

export function NotificationsPage(){
  const [stats,setStats]=useState<NotificationQueueSummary>({pending:0,sent:0,failed:0,today:0}); const [loading,setLoading]=useState(false)
  async function load(){setLoading(true);try{setStats(await getNotificationSummary())}finally{setLoading(false)}} useEffect(()=>{load()},[])
  return <>
    <div className="page-head"><div><span className="eyebrow">Communication operations</span><h1>Notifications</h1><p>Outbox-based reminders keep financial transactions independent from external gateway failures.</p></div><button className="button ghost" onClick={load}><RefreshCw className={loading?'spin':''} size={16}/>Refresh</button></div>
    <section className="kpi-grid"><div className="kpi-card"><div className="kpi-icon"><Bell/></div><div className="kpi-copy"><span>Queued</span><strong>{stats.pending}</strong><small>Retry-safe outbox</small></div></div><div className="kpi-card"><div className="kpi-icon"><Send/></div><div className="kpi-copy"><span>Sent</span><strong>{stats.sent}</strong><small>Last 30 days view</small></div></div><div className="kpi-card"><div className="kpi-icon"><MessageSquare/></div><div className="kpi-copy"><span>Today</span><strong>{stats.today}</strong><small>Created today</small></div></div><div className="kpi-card"><div className="kpi-icon"><Smartphone/></div><div className="kpi-copy"><span>Failed</span><strong>{stats.failed}</strong><small>After gateway attempts</small></div></div></section>
    <section className="card"><div className="card-head"><div><span className="eyebrow">Provider adapters</span><h3>Channel architecture</h3></div></div><div className="channel-grid"><div><Smartphone/><strong>SMS</strong><span>Tenant-enabled channel, generic gateway adapter.</span></div><div><MessageSquare/><strong>WhatsApp</strong><span>Can connect an approved WhatsApp provider without changing ledger code.</span></div><div><Mail/><strong>Email</strong><span>Guardian notices, statements and account recovery channel.</span></div><div><Bell/><strong>In-app</strong><span>Stored directly for student/admin portals and never depends on a gateway.</span></div></div></section>
  </>
}
