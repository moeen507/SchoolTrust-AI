import { useEffect, useMemo, useState } from 'react'
import { Download, MoreHorizontal, Plus, Search, UserRound, X } from 'lucide-react'
import { createStudent, getAcademicSetup, getStudents } from '../lib/repository'
import type { ClassOption, SectionOption, Student } from '../lib/types'
import { compactMoney, initials } from '../lib/format'
import { useAuth } from '../context/AuthContext'

export function StudentsPage() {
  const {user}=useAuth(); const canAdd=['owner','super_admin','admin'].includes(user?.role??'');
  const [students,setStudents]=useState<Student[]>([])
  const [classes,setClasses]=useState<ClassOption[]>([])
  const [sections,setSections]=useState<SectionOption[]>([])
  const [q,setQ]=useState('')
  const [status,setStatus]=useState('active')
  const [loading,setLoading]=useState(true)
  const [showAdd,setShowAdd]=useState(false)
  const [busy,setBusy]=useState(false)
  const [message,setMessage]=useState('')
  const [form,setForm]=useState({admissionNo:'',rollNo:'',fullName:'',guardianName:'',guardianPhone:'',guardianEmail:'',classId:'',sectionId:'',joinedOn:new Date().toISOString().slice(0,10)})

  async function load(){
    setLoading(true)
    try{
      const [rows,academic]=await Promise.all([getStudents(),getAcademicSetup()])
      setStudents(rows); setClasses(academic.classes); setSections(academic.sections)
    } finally { setLoading(false) }
  }
  useEffect(()=>{load()},[])
  const filtered=useMemo(()=>students.filter(s=>(status==='all'||s.status===status)&&[s.name,s.admissionNo,s.rollNo,s.phone,s.className,s.guardian].join(' ').toLowerCase().includes(q.toLowerCase())),[students,q,status])
  const classSections=sections.filter(s=>!form.classId||s.classId===form.classId)

  async function add(){
    if(!form.admissionNo.trim()||!form.fullName.trim()) return
    setBusy(true); setMessage('')
    try{
      await createStudent(form)
      setMessage(`${form.fullName} added successfully.`)
      setForm({admissionNo:'',rollNo:'',fullName:'',guardianName:'',guardianPhone:'',guardianEmail:'',classId:'',sectionId:'',joinedOn:new Date().toISOString().slice(0,10)})
      setShowAdd(false); await load()
    }catch(e:any){setMessage(e.message||'Unable to add student')}finally{setBusy(false)}
  }

  function exportCsv(){
    const esc=(v:unknown)=>`"${String(v??'').replaceAll('"','""')}"`
    const rows=[['Admission No','Roll No','Student','Guardian','Phone','Class','Section','Monthly Fee','Outstanding','Advance','Status'],...filtered.map(s=>[s.admissionNo,s.rollNo,s.name,s.guardian,s.phone,s.className,s.section,s.monthlyFee/100,s.outstanding/100,s.advance/100,s.status])]
    const blob=new Blob([rows.map(r=>r.map(esc).join(',')).join('\n')],{type:'text/csv;charset=utf-8'})
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`students-${new Date().toISOString().slice(0,10)}.csv`;a.click();URL.revokeObjectURL(a.href)
  }

  return <>
    <div className="page-head"><div><span className="eyebrow">Student master</span><h1>Students</h1><p>Central identity, class placement and financial account summary.</p></div><div className="page-head-actions"><button className="button ghost" onClick={exportCsv}><Download size={16}/>Export</button>{canAdd&&<button className="button primary" onClick={()=>setShowAdd(true)}><Plus size={16}/>Add student</button>}</div></div>
    {message&&<div className="notice-banner selectable"><span>{message}</span></div>}
    <section className="student-registry-stats">
      <div className="stat-card"><div className="stat-label">Total Students</div><div className="stat-value">{students.length}</div></div>
      <div className="stat-card"><div className="stat-label">Active Students</div><div className="stat-value ok">{students.filter(s=>s.status==='active').length}</div></div>
      <div className="stat-card"><div className="stat-label">Classes</div><div className="stat-value">{new Set(students.map(s=>s.className).filter(Boolean)).size}</div></div>
      <div className="stat-card"><div className="stat-label">Visible Outstanding</div><div className="stat-value money danger">{compactMoney(filtered.reduce((a,s)=>a+s.outstanding,0))}</div></div>
    </section>
    {showAdd&&canAdd&&<section className="card commercial-form"><div className="card-head"><div><span className="eyebrow">New record</span><h3>Add student</h3></div><button className="icon-button" onClick={()=>setShowAdd(false)}><X size={17}/></button></div><div className="form-grid three">
      <label>Admission no<input value={form.admissionNo} onChange={e=>setForm({...form,admissionNo:e.target.value})} placeholder="UES-2026-001"/></label>
      <label>Roll no<input value={form.rollNo} onChange={e=>setForm({...form,rollNo:e.target.value})}/></label>
      <label>Joined on<input type="date" value={form.joinedOn} onChange={e=>setForm({...form,joinedOn:e.target.value})}/></label>
      <label className="span-2">Student full name<input value={form.fullName} onChange={e=>setForm({...form,fullName:e.target.value})}/></label>
      <label>Guardian name<input value={form.guardianName} onChange={e=>setForm({...form,guardianName:e.target.value})}/></label>
      <label>Guardian phone<input value={form.guardianPhone} onChange={e=>setForm({...form,guardianPhone:e.target.value})}/></label>
      <label>Guardian email<input type="email" value={form.guardianEmail} onChange={e=>setForm({...form,guardianEmail:e.target.value})}/></label>
      <label>Class<select value={form.classId} onChange={e=>setForm({...form,classId:e.target.value,sectionId:''})}><option value="">Unassigned</option>{classes.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
      <label>Section<select value={form.sectionId} onChange={e=>setForm({...form,sectionId:e.target.value})}><option value="">Unassigned</option>{classSections.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></label>
    </div><div className="form-actions"><button className="button ghost" onClick={()=>setShowAdd(false)}>Cancel</button><button className="button primary" disabled={busy||!form.admissionNo.trim()||!form.fullName.trim()} onClick={add}>{busy?'Saving…':'Create student'}</button></div></section>}
    <section className="card table-card">
      <div className="table-toolbar"><div className="table-search"><Search size={16}/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search name, admission no, roll no..."/></div><select className="toolbar-select" value={status} onChange={e=>setStatus(e.target.value)}><option value="active">Active</option><option value="all">All statuses</option><option value="inactive">Inactive</option><option value="graduated">Graduated</option><option value="left">Left</option></select><span className="record-count">{filtered.length} records</span></div>
      <div className="data-table-wrap"><table className="data-table"><thead><tr><th>Student</th><th>Class</th><th>Monthly fee</th><th>Outstanding</th><th>Advance</th><th>Status</th><th/></tr></thead><tbody>{filtered.map(s=><tr key={s.id}><td><div className="student-cell"><div className="avatar soft">{initials(s.name)}</div><div><strong>{s.name}</strong><span>{s.admissionNo} · Roll {s.rollNo||'—'}</span></div></div></td><td><strong>{s.className||'Unassigned'}{s.section?`-${s.section}`:''}</strong><span className="cell-muted">{s.guardian||'No guardian name'}</span></td><td>{compactMoney(s.monthlyFee)}</td><td><span className={s.outstanding?'money-due':'money-ok'}>{s.outstanding?compactMoney(s.outstanding):'Clear'}</span></td><td>{s.advance?compactMoney(s.advance):'—'}</td><td><span className={`status-pill ${s.status==='active'?'good':''}`}>{s.status}</span></td><td><button className="icon-button" title="More actions"><MoreHorizontal size={17}/></button></td></tr>)}</tbody></table>{loading&&<div className="loading-row">Loading students...</div>}{!loading&&!filtered.length&&<div className="empty-state"><UserRound size={28}/><strong>No matching students</strong><span>Try a different search or add a student.</span></div>}</div>
    </section>
  </>
}
