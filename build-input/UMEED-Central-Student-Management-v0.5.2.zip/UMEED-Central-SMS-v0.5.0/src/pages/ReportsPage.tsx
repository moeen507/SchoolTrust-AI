import { useEffect, useMemo, useState } from 'react'
import { CalendarRange, Coffee, Download, FileSpreadsheet, Printer, ReceiptText, Search, ShoppingBag, TriangleAlert } from 'lucide-react'
import { Link } from 'react-router-dom'
import { compactMoney } from '../lib/format'
import { getCurrentMonthDefaulters, getDashboardMetrics, getRecentReceipts, getSaleSlips } from '../lib/repository'
import { mockMetrics } from '../lib/mock'
import type { DashboardMetrics, ReceiptRecord, SaleSlip, Student } from '../lib/types'

type Tab='fees'|'defaulters'|'student_store'|'canteen'

export function ReportsPage(){
  const [metrics,setMetrics]=useState<DashboardMetrics>(mockMetrics)
  const [receipts,setReceipts]=useState<ReceiptRecord[]>([])
  const [sales,setSales]=useState<SaleSlip[]>([])
  const [defaulters,setDefaulters]=useState<Student[]>([])
  const [tab,setTab]=useState<Tab>('fees')
  const [q,setQ]=useState('')
  const [method,setMethod]=useState('all')
  const [from,setFrom]=useState('')
  const [to,setTo]=useState('')
  useEffect(()=>{Promise.all([getDashboardMetrics(),getRecentReceipts(250),getSaleSlips({limit:250}),getCurrentMonthDefaulters()]).then(([m,r,s,d])=>{setMetrics(m);setReceipts(r);setSales(s);setDefaulters(d)})},[])

  function inRange(value:string){const d=new Date(value);if(from&&d<new Date(`${from}T00:00:00`))return false;if(to&&d>new Date(`${to}T23:59:59`))return false;return true}
  const feeRows=useMemo(()=>receipts.filter(r=>inRange(r.receivedAt)&& (method==='all'||r.paymentMethod===method) && [r.receiptNo,r.studentName,r.admissionNo,r.rollNo,r.className,r.paymentMethod].join(' ').toLowerCase().includes(q.toLowerCase())),[receipts,q,method,from,to])
  const saleRows=useMemo(()=>sales.filter(s=>s.channel===tab && inRange(s.soldAt) && [s.slipNo,s.studentName,s.admissionNo,s.rollNo,s.className].join(' ').toLowerCase().includes(q.toLowerCase())),[sales,tab,q,from,to])
  const dueRows=useMemo(()=>defaulters.filter(s=>[s.name,s.admissionNo,s.rollNo,s.guardian,s.className,s.section].join(' ').toLowerCase().includes(q.toLowerCase())),[defaulters,q])

  function csvCell(v:unknown){return `"${String(v??'').replaceAll('"','""')}"`}
  function exportCurrent(){
    let rows:(string|number)[][]=[]
    if(tab==='fees')rows=[['Receipt','Date','Student','Admission','Class','Method','Amount','Refunded'],...feeRows.map(r=>[r.receiptNo,new Date(r.receivedAt).toLocaleDateString(),r.studentName,r.admissionNo,`${r.className}-${r.section}`,r.paymentMethod,r.amountMinor/100,r.refundedMinor/100])]
    if(tab==='defaulters')rows=[['Admission','Roll','Student','Guardian','Class','Current Month Due','Total Outstanding'],...dueRows.map(s=>[s.admissionNo,s.rollNo,s.name,s.guardian,`${s.className}-${s.section}`,Math.min(s.outstanding,s.monthlyFee)/100,s.outstanding/100])]
    if(tab==='student_store'||tab==='canteen')rows=[['Slip','Date','Student','Admission','Class','Amount','Status'],...saleRows.map(s=>[s.slipNo,new Date(s.soldAt).toLocaleDateString(),s.studentName,s.admissionNo,`${s.className}-${s.section}`,s.totalMinor/100,s.status])]
    const blob=new Blob([rows.map(r=>r.map(csvCell).join(',')).join('\n')],{type:'text/csv;charset=utf-8'})
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`umeed-${tab}-report-${new Date().toISOString().slice(0,10)}.csv`;a.click();URL.revokeObjectURL(a.href)
  }

  const visibleAmount=tab==='fees'?feeRows.reduce((a,r)=>a+r.amountMinor-r.refundedMinor,0):tab==='defaulters'?dueRows.reduce((a,s)=>a+s.outstanding,0):saleRows.reduce((a,s)=>a+(s.status==='posted'?s.totalMinor:0),0)
  const visibleCount=tab==='fees'?feeRows.length:tab==='defaulters'?dueRows.length:saleRows.length

  return <>
    <div className="page-head"><div><span className="eyebrow">Professional ERP reporting workspace</span><h1>Fee & Student Reports</h1><p>Search by student, filter the reporting period, separate school fees from student-store and canteen transactions, and export exactly the visible report.</p></div><div className="page-head-actions"><button className="button ghost" onClick={()=>window.print()}><Printer size={16}/>Print</button><button className="button primary" onClick={exportCurrent}><Download size={16}/>Export CSV</button></div></div>

    <section className="stats-row report-summary-row"><div className="stat-card"><div className="stat-label">Month Net Collection</div><div className="stat-value money ok">{compactMoney(metrics.month)}</div></div><div className="stat-card"><div className="stat-label">Visible Report Total</div><div className="stat-value money">{compactMoney(visibleAmount)}</div></div><div className="stat-card"><div className="stat-label">Visible Records</div><div className="stat-value">{visibleCount}</div></div><div className="stat-card"><div className="stat-label">Current Outstanding</div><div className="stat-value money danger">{compactMoney(metrics.outstanding)}</div></div></section>

    <section className="card report-workspace-card">
      <div className="report-tabs legacy-report-tabs">
        <button className={tab==='fees'?'active':''} onClick={()=>setTab('fees')}><ReceiptText size={14}/>Fee Receipts</button>
        <button className={tab==='defaulters'?'active':''} onClick={()=>setTab('defaulters')}><TriangleAlert size={14}/>Defaulters</button>
        <button className={tab==='student_store'?'active':''} onClick={()=>setTab('student_store')}><ShoppingBag size={14}/>Student Store</button>
        <button className={tab==='canteen'?'active':''} onClick={()=>setTab('canteen')}><Coffee size={14}/>Canteen</button>
      </div>
      <div className="erp-report-filters">
        <label className="report-search"><span>Search</span><div className="table-search"><Search size={15}/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Roll no, admission no, student or receipt/slip..."/></div></label>
        <label><span>From</span><input type="date" value={from} onChange={e=>setFrom(e.target.value)}/></label>
        <label><span>To</span><input type="date" value={to} onChange={e=>setTo(e.target.value)}/></label>
        {tab==='fees'&&<label><span>Method</span><select value={method} onChange={e=>setMethod(e.target.value)}><option value="all">All methods</option><option value="cash">Cash</option><option value="bank">Bank</option><option value="online">Online</option></select></label>}
        <button className="button ghost clear-filter" onClick={()=>{setQ('');setFrom('');setTo('');setMethod('all')}}><CalendarRange size={14}/>Clear filters</button>
      </div>

      <div className="table-outer report-table-old">
        {tab==='fees'&&<table><thead><tr><th>Receipt</th><th>Student</th><th>Class</th><th>Date</th><th>Method</th><th>Amount</th><th>Refunded</th><th/></tr></thead><tbody>{feeRows.map(r=><tr key={r.paymentId}><td><span className="badge badge-gold">{r.receiptNo}</span></td><td><strong>{r.studentName}</strong><span className="cell-muted">{r.admissionNo} · Roll {r.rollNo||'—'}</span></td><td>{r.className}-{r.section}</td><td>{new Date(r.receivedAt).toLocaleDateString()}</td><td>{r.paymentMethod}</td><td className="money-ok">{compactMoney(r.amountMinor)}</td><td>{r.refundedMinor?compactMoney(r.refundedMinor):'—'}</td><td><Link className="icon-button" to={`/receipt/${encodeURIComponent(r.receiptNo)}`}><Printer size={14}/></Link></td></tr>)}</tbody></table>}
        {tab==='defaulters'&&<table><thead><tr><th>Admission</th><th>Roll</th><th>Student</th><th>Father/Guardian</th><th>Class</th><th>Monthly Fee</th><th>Current Due</th><th>Total Pending</th></tr></thead><tbody>{dueRows.map(s=><tr key={s.id}><td><span className="badge badge-gold">{s.admissionNo}</span></td><td>{s.rollNo||'—'}</td><td><strong>{s.name}</strong></td><td>{s.guardian||'—'}</td><td>{s.className}-{s.section}</td><td>{compactMoney(s.monthlyFee)}</td><td className="money-due">{compactMoney(Math.min(s.outstanding,s.monthlyFee))}</td><td><strong className="money-due">{compactMoney(s.outstanding)}</strong></td></tr>)}</tbody></table>}
        {(tab==='student_store'||tab==='canteen')&&<table><thead><tr><th>Slip</th><th>Student</th><th>Class</th><th>Date</th><th>Items</th><th>Method</th><th>Amount</th><th/></tr></thead><tbody>{saleRows.map(s=><tr key={s.saleId}><td><span className="badge badge-gold">{s.slipNo}</span></td><td><strong>{s.studentName}</strong><span className="cell-muted">{s.admissionNo}</span></td><td>{s.className}-{s.section}</td><td>{new Date(s.soldAt).toLocaleDateString()}</td><td>{s.items.map(i=>`${i.name} × ${i.quantity}`).join(', ')}</td><td>{s.paymentMethod}</td><td className="money-ok">{compactMoney(s.totalMinor)}</td><td><Link className="icon-button" to={`/sale-slip/${encodeURIComponent(s.slipNo)}`}><Printer size={14}/></Link></td></tr>)}</tbody></table>}
        {!visibleCount&&<div className="empty-state tall"><FileSpreadsheet size={30}/><strong>No matching report rows</strong><span>Adjust the date or search filters.</span></div>}
      </div>
    </section>
  </>
}
