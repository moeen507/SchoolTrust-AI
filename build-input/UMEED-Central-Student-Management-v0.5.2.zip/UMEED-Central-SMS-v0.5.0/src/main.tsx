import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, HashRouter } from 'react-router-dom'
import App from './App'
import './styles.css'

const Router = window.umeedDesktop ? HashRouter : BrowserRouter

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Router>
      <App />
    </Router>
  </StrictMode>,
)

if (!window.umeedDesktop && 'serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>undefined))
}
