export {}
declare global {
  interface Window {
    umeedDesktop?: {
      getInfo(): Promise<{desktop:boolean;version:string;platform:string;packaged:boolean;theme:'dark'|'light'}>
      print(options?:Record<string,unknown>): Promise<{ok:boolean}>
      savePdf(suggestedName?:string): Promise<{ok:boolean;canceled?:boolean;filePath?:string}>
      saveTextFile(payload:{title?:string;suggestedName?:string;text:string;filters?:Array<{name:string;extensions:string[]}>}): Promise<{ok:boolean;canceled?:boolean;filePath?:string;sha256?:string}>
      readImportFile(extensions?:string[]): Promise<{ok:boolean;canceled?:boolean;filePath?:string;name?:string;text?:string}>
      openExternal(url:string): Promise<{ok:boolean}>
      showItem(filePath:string): Promise<{ok:boolean}>
      restart(): Promise<void>
      downloadUpdate(): Promise<{ok:boolean}>
      installUpdate(): Promise<void>
      onUpdateAvailable(handler:(payload:{version:string})=>void): ()=>void
      onUpdateError(handler:(payload:{message:string})=>void): ()=>void
    }
  }
}
