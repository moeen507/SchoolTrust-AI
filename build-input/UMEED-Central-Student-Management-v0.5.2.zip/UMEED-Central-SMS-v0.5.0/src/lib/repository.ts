import { isSupabaseConfigured, supabase } from './supabase'
import { mockMetrics, mockStudents, mockTrend } from './mock'
import type {
  AcademicSessionOption, CashierShift, ClassOption, DashboardMetrics, GuardianChild, ImportPreview,
  AcademicExam, AcademicSubject, AttendanceRecord, AttendanceSummary, AuditEvent, CatalogItem, CounterStudent, ExamSubject, LedgerEntry, NotificationQueueSummary, OrganizationSettings, PerformanceRow, ReceiptRecord, RefundRecord, SaleChannel, SaleSlip, SectionOption, StaffRole, StaffSummary, Student, TenantSummary, TrendPoint,
} from './types'

const live = () => Boolean(supabase && isSupabaseConfigured)
const demoReceipt = (): ReceiptRecord => ({
  paymentId:'demo-payment',receiptNo:'UES-2026-001248',receivedAt:new Date().toISOString(),amountMinor:200000,refundedMinor:0,allocatedMinor:200000,creditCreatedMinor:0,paymentMethod:'cash',studentId:mockStudents[0].id,admissionNo:mockStudents[0].admissionNo,rollNo:mockStudents[0].rollNo,studentName:mockStudents[0].name,guardianName:mockStudents[0].guardian,className:mockStudents[0].className,section:mockStudents[0].section,organizationName:'UMEED Education System',notes:'Counter collection'
})

export async function getDashboardMetrics(): Promise<DashboardMetrics> {
  if (!live()) return mockMetrics
  const { data, error } = await supabase!.rpc('dashboard_metrics')
  if (error || !data) throw error ?? new Error('Dashboard metrics unavailable')
  return data as DashboardMetrics
}

export async function getCollectionTrend(): Promise<TrendPoint[]> {
  if (!live()) return mockTrend
  const { data, error } = await supabase!.from('v_collection_last_7_days').select('label,amount')
  if (error) throw error
  return (data ?? []).map((r: any) => ({ label: r.label, amount: Number(r.amount) }))
}

export async function getStudents(): Promise<Student[]> {
  if (!live()) return mockStudents
  const { data, error } = await supabase!.from('v_student_account_summary').select('*').order('full_name').limit(1000)
  if (error) throw error
  return (data ?? []).map(mapStudent)
}

function mapStudent(r:any): Student {
  return {
    id:r.id, admissionNo:r.admission_no, rollNo:r.roll_no ?? '', name:r.full_name, guardian:r.guardian_name ?? '', phone:r.guardian_phone ?? '',
    className:r.class_name ?? '', section:r.section_name ?? '', monthlyFee:Number(r.monthly_fee_minor ?? 0), annualFund:Number(r.annual_fund_minor ?? 0),
    outstanding:Number(r.outstanding_minor ?? 0), advance:Number(r.credit_minor ?? 0), status:r.status,
  }
}


async function getCurrentMembership() {
  if(!live()) return { organization_id:'org-demo', role:'owner' }
  const {data,error}=await supabase!.from('v_my_active_membership').select('organization_id,role').limit(1).single()
  if(error) throw error
  return data as { organization_id:string; role:string }
}

export async function createStudent(input:{admissionNo:string;rollNo?:string;fullName:string;guardianName?:string;guardianPhone?:string;guardianEmail?:string;classId?:string;sectionId?:string;joinedOn?:string}) {
  if(!live()) return {...mockStudents[0],id:`student-${Date.now()}`,admissionNo:input.admissionNo,rollNo:input.rollNo??'',name:input.fullName,guardian:input.guardianName??'',phone:input.guardianPhone??''}
  const {data,error}=await supabase!.rpc('create_student',{
    p_admission_no:input.admissionNo,p_full_name:input.fullName,p_roll_no:input.rollNo||null,p_guardian_name:input.guardianName||null,
    p_guardian_phone:input.guardianPhone||null,p_guardian_email:input.guardianEmail||null,p_class_id:input.classId||null,p_section_id:input.sectionId||null,p_joined_on:input.joinedOn||new Date().toISOString().slice(0,10),
  })
  if(error) throw error
  return data
}


export async function getOrganizationSettings():Promise<OrganizationSettings>{
  if(!live()) return {id:'org-demo',name:'UMEED Education System',slug:'umeed-education-system',status:'active',currency:'PKR',timezone:'Asia/Karachi',receiptPrefix:'UES',branding:{primary:'#6d1028',accent:'#d7b46a'},settings:{defaulter_day:8}}
  const membership=await getCurrentMembership()
  const {data,error}=await supabase!.from('organizations').select('id,name,slug,status,currency,timezone,receipt_prefix,branding,settings').eq('id',membership.organization_id).single()
  if(error) throw error
  return {id:data.id,name:data.name,slug:data.slug,status:data.status,currency:data.currency,timezone:data.timezone,receiptPrefix:data.receipt_prefix,branding:data.branding??{},settings:data.settings??{}}
}

export async function updateOrganizationSettings(input:Partial<Pick<OrganizationSettings,'name'|'currency'|'timezone'|'receiptPrefix'|'branding'|'settings'>>){
  if(!live()) return input
  const current=await getOrganizationSettings()
  const {data,error}=await supabase!.rpc('update_organization_configuration',{
    p_name:input.name??current.name,p_currency:input.currency??current.currency,p_timezone:input.timezone??current.timezone,
    p_receipt_prefix:input.receiptPrefix??current.receiptPrefix,p_branding:input.branding??current.branding,p_settings:input.settings??current.settings,
  })
  if(error) throw error
  return data
}


export async function provisionStaff(fullName:string,email:string,role:StaffRole){
  if(!live()) return {userId:`staff-${Date.now()}`,temporaryPassword:'DemoA1!93482'}
  const membership=await getCurrentMembership()
  const {data,error}=await supabase!.functions.invoke('provision-staff',{body:{organizationId:membership.organization_id,fullName,email,role}})
  if(error) throw error
  if(data?.error) throw new Error(data.error)
  return data
}

export async function recordPayment(input: { studentId:string; amountMinor:number; method:string; notes?:string; idempotencyKey:string }) {
  if (!live()) return { payment_id:'demo-payment',receipt_no:`DEMO-${Date.now().toString().slice(-6)}`,amount_minor:input.amountMinor,advance_minor:Math.max(input.amountMinor-200000,0) }
  const { data,error }=await supabase!.rpc('record_payment',{p_student_id:input.studentId,p_amount_minor:input.amountMinor,p_payment_method:input.method,p_notes:input.notes??null,p_idempotency_key:input.idempotencyKey})
  if(error) throw error
  return data as any
}

export async function applyStudentCredit(studentId:string, amountMinor?:number) {
  if (!live()) return {applied_minor:Math.min(amountMinor??50000,50000),remaining_credit_minor:0}
  const {data,error}=await supabase!.rpc('apply_student_credit',{p_student_id:studentId,p_amount_minor:amountMinor??null})
  if(error) throw error
  return data as any
}

export async function getCurrentMonthDefaulters(): Promise<Student[]> {
  if (!live()) return mockStudents.filter(s=>s.outstanding>0)
  const { data,error }=await supabase!.from('v_current_month_defaulters').select('*').order('outstanding_minor',{ascending:false})
  if(error) throw error
  return (data??[]).map((r:any)=>({id:r.student_id,admissionNo:r.admission_no,rollNo:r.roll_no??'',name:r.full_name,guardian:r.guardian_name??'',phone:r.guardian_phone??'',className:r.class_name??'',section:r.section_name??'',monthlyFee:Number(r.current_month_due_minor??0),annualFund:0,outstanding:Number(r.outstanding_minor??0),advance:Number(r.credit_minor??0),status:'active'}))
}

export async function getMyStudentAccount(): Promise<Student|null> {
  if (!live()) return mockStudents[0]
  const {data,error}=await supabase!.from('v_student_account_summary').select('*').limit(1).maybeSingle()
  if(error) throw error
  return data?mapStudent(data):null
}

export async function getGuardianChildren(): Promise<GuardianChild[]> {
  if(!live()) return mockStudents.slice(0,2).map(s=>({studentId:s.id,admissionNo:s.admissionNo,rollNo:s.rollNo,name:s.name,className:s.className,section:s.section,outstanding:s.outstanding,credit:s.advance}))
  const {data,error}=await supabase!.from('v_guardian_children').select('*').order('full_name')
  if(error) throw error
  return (data??[]).map((r:any)=>({studentId:r.student_id,admissionNo:r.admission_no,rollNo:r.roll_no??'',name:r.full_name,className:r.class_name??'',section:r.section_name??'',outstanding:Number(r.outstanding_minor??0),credit:Number(r.credit_minor??0)}))
}

export async function getStudentLedger(studentId:string): Promise<LedgerEntry[]> {
  if(!live()) return [
    {occurredAt:new Date().toISOString(),entryType:'invoice',reference:'demo-invoice',label:'INV-202609-001',debitMinor:200000,creditMinor:0,status:'paid'},
    {occurredAt:new Date().toISOString(),entryType:'payment',reference:'demo-payment',label:'UES-2026-001248',debitMinor:0,creditMinor:200000,status:'posted'},
  ]
  const {data,error}=await supabase!.from('v_student_ledger').select('*').eq('student_id',studentId).order('occurred_at',{ascending:false}).limit(250)
  if(error) throw error
  return (data??[]).map((r:any)=>({occurredAt:r.occurred_at,entryType:r.entry_type,reference:r.reference,label:r.label,debitMinor:Number(r.debit_minor??0),creditMinor:Number(r.credit_minor??0),status:r.status}))
}

export async function getRecentReceipts(limit=50): Promise<ReceiptRecord[]> {
  if(!live()) return [demoReceipt()]
  const {data,error}=await supabase!.from('v_receipts').select('*').order('received_at',{ascending:false}).limit(limit)
  if(error) throw error
  return (data??[]).map(mapReceipt)
}

export async function getReceipt(receiptNo:string): Promise<ReceiptRecord|null> {
  if(!live()) return {...demoReceipt(),receiptNo}
  const {data,error}=await supabase!.from('v_receipts').select('*').eq('receipt_no',receiptNo).maybeSingle()
  if(error) throw error
  return data?mapReceipt(data):null
}

function mapReceipt(r:any):ReceiptRecord { return {
  paymentId:r.payment_id,receiptNo:r.receipt_no,receivedAt:r.received_at,amountMinor:Number(r.amount_minor??0),refundedMinor:Number(r.refunded_minor??0),allocatedMinor:Number(r.allocated_minor??0),creditCreatedMinor:Number(r.credit_created_minor??0),paymentMethod:r.payment_method,reference:r.reference??'',notes:r.notes??'',studentId:r.student_id,admissionNo:r.admission_no,rollNo:r.roll_no??'',studentName:r.full_name,guardianName:r.guardian_name??'',className:r.class_name??'',section:r.section_name??'',organizationName:r.organization_name,
} }

export async function getRefundQueue(): Promise<RefundRecord[]> {
  if(!live()) return [{id:'rf-demo',refundNo:'RF-UES-2026-001247-120100',paymentId:'demo-payment',receiptNo:'UES-2026-001247',studentId:mockStudents[0].id,studentName:mockStudents[0].name,amountMinor:50000,reason:'Duplicate counter collection',status:'pending',createdAt:new Date().toISOString()}]
  const {data,error}=await supabase!.from('v_refund_queue').select('*').order('created_at',{ascending:false}).limit(100)
  if(error) throw error
  return (data??[]).map((r:any)=>({id:r.id,refundNo:r.refund_no,paymentId:r.payment_id,receiptNo:r.receipt_no,studentId:r.student_id,studentName:r.full_name,amountMinor:Number(r.amount_minor),reason:r.reason,status:r.status,createdAt:r.created_at,approvedAt:r.approved_at??undefined,rejectionReason:r.rejection_reason??undefined}))
}

export async function requestRefund(paymentId:string, amountMinor:number, reason:string) {
  if(!live()) return {refund_id:'demo-refund',refund_no:`RF-DEMO-${Date.now().toString().slice(-6)}`,status:'pending'}
  const {data,error}=await supabase!.rpc('request_refund',{p_payment_id:paymentId,p_amount_minor:amountMinor,p_reason:reason})
  if(error) throw error
  return data as any
}

export async function approveRefund(refundId:string) {
  if(!live()) return {refund_id:refundId,status:'posted'}
  const {data,error}=await supabase!.rpc('approve_refund',{p_refund_id:refundId})
  if(error) throw error
  return data as any
}

export async function rejectRefund(refundId:string, reason:string) {
  if(!live()) return {refund_id:refundId,status:'rejected'}
  const {data,error}=await supabase!.rpc('reject_refund',{p_refund_id:refundId,p_reason:reason})
  if(error) throw error
  return data as any
}

export async function getAcademicSetup(): Promise<{sessions:AcademicSessionOption[];classes:ClassOption[];sections:SectionOption[]}> {
  if(!live()) return {sessions:[{id:'session-2026',name:'2026-27',active:true,startsOn:'2026-04-01',endsOn:'2027-03-31'}],classes:[...new Set(mockStudents.map(s=>s.className))].map((name,i)=>({id:`class-${i}`,name,sortOrder:i})),sections:[{id:'section-a',classId:'class-0',name:'A'}]}
  const [{data:sessions,error:e1},{data:classes,error:e2},{data:sections,error:e3}]=await Promise.all([
    supabase!.from('academic_sessions').select('id,name,active,starts_on,ends_on').order('starts_on',{ascending:false}),
    supabase!.from('classes').select('id,name,sort_order').eq('active',true).order('sort_order'),
    supabase!.from('sections').select('id,class_id,name').order('name'),
  ])
  if(e1||e2||e3) throw e1??e2??e3
  return {sessions:(sessions??[]).map((r:any)=>({id:r.id,name:r.name,active:r.active,startsOn:r.starts_on,endsOn:r.ends_on})),classes:(classes??[]).map((r:any)=>({id:r.id,name:r.name,sortOrder:r.sort_order})),sections:(sections??[]).map((r:any)=>({id:r.id,classId:r.class_id,name:r.name}))}
}

export async function generateMonthlyInvoices(month:string) {
  if(!live()) return {month,created:mockStudents.length}
  const {data,error}=await supabase!.rpc('generate_monthly_invoices',{p_month:month})
  if(error) throw error
  return data as any
}

export async function generateAnnualInvoices(sessionId:string) {
  if(!live()) return {session_id:sessionId,created:mockStudents.length,skipped:0}
  const {data,error}=await supabase!.rpc('generate_annual_invoices',{p_session_id:sessionId})
  if(error) throw error
  return data as any
}

export async function promoteStudents(studentIds:string[],sessionId:string,classId:string,sectionId?:string) {
  if(!live()) return {promoted:studentIds.length,session_id:sessionId,class_id:classId,section_id:sectionId??null}
  const {data,error}=await supabase!.rpc('promote_students',{p_student_ids:studentIds,p_session_id:sessionId,p_class_id:classId,p_section_id:sectionId??null,p_started_on:new Date().toISOString().slice(0,10)})
  if(error) throw error
  return data as any
}

export async function getOpenCashierShift():Promise<CashierShift|null>{
  if(!live()) return null
  const {data:{user}}=await supabase!.auth.getUser(); if(!user) return null
  const {data,error}=await supabase!.from('cashier_shifts').select('*').eq('cashier_id',user.id).eq('status','open').maybeSingle(); if(error) throw error
  return data?mapShift(data):null
}

export async function openCashierShift(openingCashMinor:number,notes?:string):Promise<any>{
  if(!live()) return {shift_id:'demo-shift',status:'open'}
  const {data,error}=await supabase!.rpc('open_cashier_shift',{p_opening_cash_minor:openingCashMinor,p_notes:notes??null}); if(error) throw error; return data
}

export async function closeCashierShift(shiftId:string,countedCashMinor:number,notes?:string):Promise<any>{
  if(!live()) return {shift_id:shiftId,expected_cash_minor:countedCashMinor-1000,counted_cash_minor:countedCashMinor,variance_minor:1000,status:'closed'}
  const {data,error}=await supabase!.rpc('close_cashier_shift',{p_shift_id:shiftId,p_counted_cash_minor:countedCashMinor,p_notes:notes??null}); if(error) throw error; return data
}

function mapShift(r:any):CashierShift{return{id:r.id,openedAt:r.opened_at,closedAt:r.closed_at??undefined,openingCashMinor:Number(r.opening_cash_minor??0),expectedCashMinor:r.expected_cash_minor==null?undefined:Number(r.expected_cash_minor),countedCashMinor:r.counted_cash_minor==null?undefined:Number(r.counted_cash_minor),varianceMinor:r.variance_minor==null?undefined:Number(r.variance_minor),status:r.status}}

export async function importStudents(rows:Record<string,string>[],filename:string,dryRun:boolean):Promise<ImportPreview>{
  if(!live()){
    const errors=rows.flatMap((r,i)=>!r.admission_no||!r.full_name?[{row:i+2,error:'Admission number and full name are required'}]:[])
    return {jobId:'demo-import',dryRun,total:rows.length,valid:rows.length-errors.length,invalid:errors.length,errors}
  }
  const {data:membership,error:membershipError}=await supabase!.from('v_my_active_membership').select('organization_id').limit(1).single(); if(membershipError) throw membershipError
  const {data,error}=await supabase!.functions.invoke('import-students',{body:{organizationId:membership.organization_id,rows,filename,dryRun}}); if(error) throw error; if(data?.error) throw new Error(data.error); return data
}

export async function provisionStudentAccess(studentId:string,loginId:string){
  if(!live()) return {loginId,temporaryPassword:'DemoA1!93482'}
  const {data:m,error:e}=await supabase!.from('v_my_active_membership').select('organization_id').limit(1).single(); if(e) throw e
  const {data,error}=await supabase!.functions.invoke('provision-student',{body:{studentId,organizationId:m.organization_id,loginId}}); if(error) throw error; if(data?.error) throw new Error(data.error); return data
}

export async function provisionGuardian(fullName:string,email:string,studentIds:string[]){
  if(!live()) return {login:email||'guardian.demo',temporaryPassword:'DemoA1!93482',linkedStudents:studentIds.length}
  const {data:m,error:e}=await supabase!.from('v_my_active_membership').select('organization_id').limit(1).single(); if(e) throw e
  const {data,error}=await supabase!.functions.invoke('provision-guardian',{body:{organizationId:m.organization_id,fullName,email:email||undefined,studentIds}}); if(error) throw error; if(data?.error) throw new Error(data.error); return data
}

export async function getNotificationSummary():Promise<NotificationQueueSummary>{
  if(!live()) return {pending:18,sent:142,failed:2,today:36}
  const since=new Date(); since.setHours(0,0,0,0)
  const {data,error}=await supabase!.from('notification_queue').select('status,created_at').gte('created_at',new Date(Date.now()-30*86400_000).toISOString()).limit(5000); if(error) throw error
  const rows=data??[]; return {pending:rows.filter((r:any)=>r.status==='pending').length,sent:rows.filter((r:any)=>r.status==='sent').length,failed:rows.filter((r:any)=>r.status==='failed').length,today:rows.filter((r:any)=>new Date(r.created_at)>=since).length}
}

export async function getTenants():Promise<TenantSummary[]>{
  if(!live()) return [{id:'org-demo',name:'UMEED Education System',slug:'umeed-education-system',status:'active',plan:'growth',subscriptionStatus:'trialing',trialEndsAt:'2026-10-20',activeStudents:600,activeStaff:12,createdAt:'2026-09-20'}]
  const {data,error}=await supabase!.from('v_platform_tenants').select('*').order('created_at',{ascending:false}); if(error) throw error
  return (data??[]).map((r:any)=>({id:r.id,name:r.name,slug:r.slug,status:r.status,plan:r.plan,subscriptionStatus:r.subscription_status??'unknown',trialEndsAt:r.trial_ends_at??undefined,currentPeriodEnd:r.current_period_end??undefined,activeStudents:Number(r.active_students??0),activeStaff:Number(r.active_staff??0),createdAt:r.created_at}))
}

export async function createTenant(input:{name:string;slug:string;ownerName:string;ownerEmail:string;planId:string;timezone:string;currency:string}){
  if(!live()) return {organization:{id:`org-${Date.now()}`,name:input.name,slug:input.slug},temporaryPassword:'DemoA1!93482'}
  const {data,error}=await supabase!.functions.invoke('provision-tenant',{body:input}); if(error) throw error; if(data?.error) throw new Error(data.error); return data
}

export async function setTenantStatus(id:string,status:'active'|'suspended'|'closed'){
  if(!live()) return
  const {error}=await supabase!.from('organizations').update({status}).eq('id',id); if(error) throw error
}

export async function exportTenant(organizationId:string){
  if(!live()) return {schema:'umeed-central-export-v1',organizationId,exportedAt:new Date().toISOString(),tables:{students:mockStudents}}
  const {data,error}=await supabase!.functions.invoke('tenant-export',{body:{organizationId}}); if(error) throw error; if(data?.error) throw new Error(data.error); return data
}

export async function queueCurrentDefaulterReminders(){
  if(!live()) return {queued:mockStudents.filter(s=>s.outstanding>0).length,as_of:new Date().toISOString().slice(0,10)}
  const {data,error}=await supabase!.rpc('queue_current_defaulter_reminders'); if(error) throw error; return data as any
}


export async function startSupportSession(organizationId:string,reason:string,minutes=30){
  if(!live()) return {session_id:`support-${Date.now()}`,expires_at:new Date(Date.now()+minutes*60_000).toISOString()}
  const {data,error}=await supabase!.rpc('start_support_session',{p_organization_id:organizationId,p_reason:reason,p_minutes:minutes})
  if(error) throw error
  return data as any
}

export async function endSupportSession(){
  if(!live()) return {ended:true}
  const {data,error}=await supabase!.rpc('end_support_session')
  if(error) throw error
  return data as any
}


export async function getStaff():Promise<StaffSummary[]>{
  if(!live()) return [
    {membershipId:'m-1',userId:'u-1',fullName:'Main Cashier',email:'cashier@demo.local',role:'cashier',active:true,createdAt:new Date().toISOString()},
    {membershipId:'m-2',userId:'u-2',fullName:'Accountant',email:'accounts@demo.local',role:'accountant',active:true,createdAt:new Date().toISOString()},
  ]
  const {data,error}=await supabase!.from('v_org_staff').select('*').order('created_at')
  if(error) throw error
  return (data??[]).map((r:any)=>({membershipId:r.membership_id,userId:r.user_id,fullName:r.full_name||'Unnamed user',email:r.email||undefined,role:r.role,active:r.active,createdAt:r.created_at}))
}

export async function setStaffActive(membershipId:string,active:boolean){
  if(!live()) return {membershipId,active}
  const {data,error}=await supabase!.from('organization_memberships').update({active}).eq('id',membershipId).select('id,active').single()
  if(error) throw error
  return data
}

export async function getAuditEvents(limit=150):Promise<AuditEvent[]>{
  if(!live()) return [
    {id:1,actorName:'Main Cashier',action:'payment.recorded',entityType:'payment',entityId:'demo-payment',afterData:{receipt_no:'UES-2026-001248',amount_minor:200000},createdAt:new Date().toISOString()},
    {id:2,actorName:'Super Admin',action:'student.created',entityType:'student',entityId:'student-demo',afterData:{admission_no:'UES-2026-001'},createdAt:new Date(Date.now()-3600_000).toISOString()},
  ]
  const {data,error}=await supabase!.from('v_audit_feed').select('*').order('created_at',{ascending:false}).limit(limit)
  if(error) throw error
  return (data??[]).map((r:any)=>({id:Number(r.id),actorId:r.actor_id??undefined,actorName:r.actor_name||'System',action:r.action,entityType:r.entity_type,entityId:r.entity_id??undefined,beforeData:r.before_data,afterData:r.after_data,createdAt:r.created_at}))
}


const demoCatalog: CatalogItem[] = [
  {id:'book-eng-9',sku:'BK-ENG-09',name:'English Book Grade 9',category:'Books',channel:'student_store',unitPriceMinor:85000,trackStock:true,stockQuantity:42,active:true},
  {id:'fee-card',sku:'ST-FCARD',name:'Student Fee Card',category:'Student stationery',channel:'student_store',unitPriceMinor:15000,trackStock:true,stockQuantity:180,active:true},
  {id:'envelope',sku:'ST-ENV',name:'School Envelope',category:'Student stationery',channel:'student_store',unitPriceMinor:5000,trackStock:true,stockQuantity:350,active:true},
  {id:'juice',sku:'CAN-JUICE',name:'Juice',category:'Drinks',channel:'canteen',unitPriceMinor:8000,trackStock:true,stockQuantity:60,active:true},
  {id:'sandwich',sku:'CAN-SAND',name:'Sandwich',category:'Food',channel:'canteen',unitPriceMinor:18000,trackStock:true,stockQuantity:35,active:true},
]

export async function searchCounterStudents(query=''):Promise<CounterStudent[]> {
  if(!live()) return mockStudents.filter(s=>[s.name,s.admissionNo,s.rollNo,s.className].join(' ').toLowerCase().includes(query.toLowerCase())).map(s=>({id:s.id,admissionNo:s.admissionNo,rollNo:s.rollNo,name:s.name,className:s.className,section:s.section})).slice(0,30)
  const {data,error}=await supabase!.rpc('search_students_for_counter',{p_query:query,p_limit:30})
  if(error) throw error
  return (data??[]).map((r:any)=>({id:r.student_id,admissionNo:r.admission_no,rollNo:r.roll_no??'',name:r.full_name,className:r.class_name??'',section:r.section_name??''}))
}

export async function getCatalogItems(channel:SaleChannel):Promise<CatalogItem[]> {
  if(!live()) return demoCatalog.filter(x=>x.channel===channel||x.channel==='both')
  const {data,error}=await supabase!.from('catalog_items').select('*').eq('active',true).in('sale_channel',[channel,'both']).order('name')
  if(error) throw error
  return (data??[]).map(mapCatalogItem)
}

function mapCatalogItem(r:any):CatalogItem{return {id:r.id,sku:r.sku,name:r.name,category:r.category??'',channel:r.sale_channel,unitPriceMinor:Number(r.unit_price_minor??0),trackStock:Boolean(r.track_stock),stockQuantity:Number(r.stock_quantity??0),active:Boolean(r.active)}}

export async function createCatalogItem(input:{sku:string;name:string;category?:string;channel:'student_store'|'canteen'|'both';unitPriceMinor:number;stockQuantity:number;trackStock:boolean}):Promise<CatalogItem>{
  if(!live()) return {id:`item-${Date.now()}`,sku:input.sku,name:input.name,category:input.category??'',channel:input.channel,unitPriceMinor:input.unitPriceMinor,stockQuantity:input.stockQuantity,trackStock:input.trackStock,active:true}
  const membership=await getCurrentMembership()
  const {data,error}=await supabase!.from('catalog_items').insert({organization_id:membership.organization_id,sku:input.sku.trim(),name:input.name.trim(),category:input.category?.trim()||null,sale_channel:input.channel,unit_price_minor:input.unitPriceMinor,stock_quantity:input.stockQuantity,track_stock:input.trackStock}).select('*').single()
  if(error) throw error
  return mapCatalogItem(data)
}

export async function adjustCatalogStock(itemId:string,quantityDelta:number,note:string){
  if(!live()) return {item_id:itemId,stock_quantity:Math.max(0,quantityDelta)}
  const {data,error}=await supabase!.rpc('adjust_catalog_stock',{p_item_id:itemId,p_quantity_delta:quantityDelta,p_note:note})
  if(error) throw error
  return data as any
}

export async function recordStudentSale(input:{studentId:string;channel:SaleChannel;items:Array<{itemId:string;quantity:number}>;paymentMethod:string;notes?:string;reference?:string;discountMinor?:number;idempotencyKey:string}){
  if(!live()){
    const catalog=demoCatalog; let subtotal=0
    for(const line of input.items){const item=catalog.find(x=>x.id===line.itemId);if(item)subtotal+=Math.round(item.unitPriceMinor*line.quantity)}
    return {sale_id:`sale-${Date.now()}`,slip_no:`${input.channel==='canteen'?'CAN':'STU'}-2026-${String(Date.now()).slice(-6)}`,subtotal_minor:subtotal,discount_minor:input.discountMinor??0,total_minor:subtotal-(input.discountMinor??0),channel:input.channel}
  }
  const {data,error}=await supabase!.rpc('record_student_sale',{p_student_id:input.studentId,p_channel:input.channel,p_items:input.items.map(x=>({item_id:x.itemId,quantity:x.quantity})),p_payment_method:input.paymentMethod,p_notes:input.notes??null,p_reference:input.reference??null,p_discount_minor:input.discountMinor??0,p_idempotency_key:input.idempotencyKey})
  if(error) throw error
  return data as any
}

function mapSaleSlip(r:any):SaleSlip{return {saleId:r.sale_id,studentId:r.student_id,channel:r.channel,slipNo:r.slip_no,soldAt:r.sold_at,subtotalMinor:Number(r.subtotal_minor??0),discountMinor:Number(r.discount_minor??0),totalMinor:Number(r.total_minor??0),paymentMethod:r.payment_method,reference:r.reference??undefined,notes:r.notes??undefined,status:r.status,admissionNo:r.admission_no,rollNo:r.roll_no??'',studentName:r.full_name,className:r.class_name??'',section:r.section_name??'',organizationName:r.organization_name,items:Array.isArray(r.items)?r.items.map((x:any)=>({name:x.name,sku:x.sku,quantity:Number(x.quantity),unitPriceMinor:Number(x.unit_price_minor),totalMinor:Number(x.total_minor)})):[]}}

export async function getSaleSlips(options:{channel?:SaleChannel;studentId?:string;limit?:number}={}):Promise<SaleSlip[]>{
  if(!live()){
    const s=mockStudents[0], channel=options.channel??'student_store', item=demoCatalog.find(x=>x.channel===channel)??demoCatalog[0]
    return [{saleId:'demo-sale',studentId:s.id,channel,slipNo:`${channel==='canteen'?'CAN':'STU'}-2026-000021`,soldAt:new Date().toISOString(),subtotalMinor:item.unitPriceMinor,discountMinor:0,totalMinor:item.unitPriceMinor,paymentMethod:'cash',status:'posted',admissionNo:s.admissionNo,rollNo:s.rollNo,studentName:s.name,className:s.className,section:s.section,organizationName:'UMEED Education System',items:[{name:item.name,sku:item.sku,quantity:1,unitPriceMinor:item.unitPriceMinor,totalMinor:item.unitPriceMinor}]}]
  }
  let q=supabase!.from('v_sales_slips').select('*').order('sold_at',{ascending:false}).limit(options.limit??100)
  if(options.channel)q=q.eq('channel',options.channel)
  if(options.studentId)q=q.eq('student_id',options.studentId)
  const {data,error}=await q
  if(error) throw error
  return (data??[]).map(mapSaleSlip)
}

export async function getSaleSlip(slipNo:string):Promise<SaleSlip|null>{
  if(!live()) return (await getSaleSlips({limit:1}))[0]??null
  const {data,error}=await supabase!.from('v_sales_slips').select('*').eq('slip_no',slipNo).maybeSingle()
  if(error) throw error
  return data?mapSaleSlip(data):null
}

export async function getSubjects():Promise<AcademicSubject[]>{
  if(!live()) return [{id:'sub-eng',code:'ENG',name:'English',active:true},{id:'sub-math',code:'MATH',name:'Mathematics',active:true},{id:'sub-bio',code:'BIO',name:'Biology',active:true},{id:'sub-urdu',code:'URD',name:'Urdu',active:true}]
  const {data,error}=await supabase!.from('subjects').select('id,code,name,active').eq('active',true).order('name');if(error)throw error
  return (data??[]).map((r:any)=>({id:r.id,code:r.code,name:r.name,active:r.active}))
}

export async function createSubject(code:string,name:string){
  if(!live()) return {id:`subject-${Date.now()}`,code,name,active:true}
  const membership=await getCurrentMembership();const {data,error}=await supabase!.from('subjects').insert({organization_id:membership.organization_id,code:code.trim().toUpperCase(),name:name.trim()}).select('id,code,name,active').single();if(error)throw error;return data
}

export async function getExams():Promise<AcademicExam[]>{
  if(!live()) return [{id:'exam-mid',name:'Mid Term 2026',term:'Term 1',status:'published',startsOn:'2026-09-01',endsOn:'2026-09-10'}]
  const {data,error}=await supabase!.from('exams').select('id,name,term,status,starts_on,ends_on').order('created_at',{ascending:false});if(error)throw error
  return (data??[]).map((r:any)=>({id:r.id,name:r.name,term:r.term??undefined,status:r.status,startsOn:r.starts_on??undefined,endsOn:r.ends_on??undefined}))
}

export async function createExam(input:{name:string;term?:string;startsOn?:string;endsOn?:string}){
  if(!live()) return {exam_id:`exam-${Date.now()}`}
  const {data,error}=await supabase!.rpc('create_exam',{p_name:input.name,p_term:input.term??null,p_starts_on:input.startsOn??null,p_ends_on:input.endsOn??null});if(error)throw error;return data as any
}

export async function setExamStatus(examId:string,status:'draft'|'published'|'locked'){
  if(!live()) return {exam_id:examId,status}
  const {data,error}=await supabase!.rpc('set_exam_status',{p_exam_id:examId,p_status:status});if(error)throw error;return data as any
}

export async function getExamSubjects(examId?:string):Promise<ExamSubject[]>{
  if(!live()) return [{id:'es-1',examId:'exam-mid',classId:'class-0',subjectId:'sub-eng',subjectName:'English',maxMarks:100,passMarks:40}]
  let q=supabase!.from('exam_subjects').select('id,exam_id,class_id,section_id,subject_id,max_marks,pass_marks,subjects(name)').order('created_at')
  if(examId)q=q.eq('exam_id',examId)
  const {data,error}=await q;if(error)throw error
  return (data??[]).map((r:any)=>({id:r.id,examId:r.exam_id,classId:r.class_id,sectionId:r.section_id??undefined,subjectId:r.subject_id,subjectName:r.subjects?.name??'Subject',maxMarks:Number(r.max_marks),passMarks:Number(r.pass_marks)}))
}

export async function configureExamSubject(input:{examId:string;classId:string;sectionId?:string;subjectId:string;maxMarks:number;passMarks:number}){
  if(!live()) return {exam_subject_id:`es-${Date.now()}`}
  const {data,error}=await supabase!.rpc('upsert_exam_subject',{p_exam_id:input.examId,p_class_id:input.classId,p_section_id:input.sectionId??null,p_subject_id:input.subjectId,p_max_marks:input.maxMarks,p_pass_marks:input.passMarks});if(error)throw error;return data as any
}

export async function saveStudentMark(examSubjectId:string,studentId:string,marks:number,remarks?:string){
  if(!live()) return {mark_id:`mark-${Date.now()}`,student_id:studentId,marks,max_marks:100}
  const {data,error}=await supabase!.rpc('upsert_student_mark',{p_exam_subject_id:examSubjectId,p_student_id:studentId,p_marks:marks,p_remarks:remarks??null});if(error)throw error;return data as any
}

export async function saveStudentAttendance(studentId:string,date:string,status:AttendanceRecord['status'],remarks?:string){
  if(!live()) return {attendance_id:`att-${Date.now()}`,student_id:studentId,date,status}
  const {data,error}=await supabase!.rpc('upsert_student_attendance',{p_student_id:studentId,p_date:date,p_status:status,p_remarks:remarks??null});if(error)throw error;return data as any
}

export async function getStudentAttendanceSummary(studentId:string):Promise<AttendanceSummary>{
  if(!live()) return {recordedDays:94,presentDays:84,absentDays:5,lateDays:3,leaveDays:2,attendancePercentage:92.55}
  const {data,error}=await supabase!.from('v_student_attendance_summary').select('*').eq('student_id',studentId).maybeSingle();if(error)throw error
  if(!data)return {recordedDays:0,presentDays:0,absentDays:0,lateDays:0,leaveDays:0,attendancePercentage:0}
  return {recordedDays:Number(data.recorded_days??0),presentDays:Number(data.present_days??0),absentDays:Number(data.absent_days??0),lateDays:Number(data.late_days??0),leaveDays:Number(data.leave_days??0),attendancePercentage:Number(data.attendance_percentage??0)}
}

export async function getStudentAttendanceHistory(studentId:string,limit=60):Promise<AttendanceRecord[]>{
  if(!live()) return [{id:'att-1',studentId,date:new Date().toISOString().slice(0,10),status:'present'},{id:'att-2',studentId,date:new Date(Date.now()-86400000).toISOString().slice(0,10),status:'late'}]
  const {data,error}=await supabase!.from('student_attendance').select('id,student_id,attendance_date,status,remarks').eq('student_id',studentId).order('attendance_date',{ascending:false}).limit(limit);if(error)throw error
  return (data??[]).map((r:any)=>({id:r.id,studentId:r.student_id,date:r.attendance_date,status:r.status,remarks:r.remarks??undefined}))
}

export async function getStudentPerformance(studentId:string):Promise<PerformanceRow[]>{
  if(!live()) return [
    {examId:'exam-mid',examName:'Mid Term 2026',term:'Term 1',subjectId:'sub-eng',subjectName:'English',maxMarks:100,passMarks:40,marksObtained:86,percentage:86,passed:true,updatedAt:new Date().toISOString()},
    {examId:'exam-mid',examName:'Mid Term 2026',term:'Term 1',subjectId:'sub-math',subjectName:'Mathematics',maxMarks:100,passMarks:40,marksObtained:91,percentage:91,passed:true,updatedAt:new Date().toISOString()},
    {examId:'exam-mid',examName:'Mid Term 2026',term:'Term 1',subjectId:'sub-bio',subjectName:'Biology',maxMarks:100,passMarks:40,marksObtained:82,percentage:82,passed:true,updatedAt:new Date().toISOString()},
  ]
  const {data,error}=await supabase!.from('v_student_performance').select('*').eq('student_id',studentId).in('exam_status',['published','locked']).order('updated_at',{ascending:false});if(error)throw error
  return (data??[]).map((r:any)=>({examId:r.exam_id,examName:r.exam_name,term:r.term??undefined,subjectId:r.subject_id,subjectName:r.subject_name,maxMarks:Number(r.max_marks),passMarks:Number(r.pass_marks),marksObtained:Number(r.marks_obtained),percentage:Number(r.percentage),passed:Boolean(r.passed),grade:r.grade??undefined,gradeRemark:r.grade_remark??undefined,remarks:r.remarks??undefined,updatedAt:r.updated_at}))
}
