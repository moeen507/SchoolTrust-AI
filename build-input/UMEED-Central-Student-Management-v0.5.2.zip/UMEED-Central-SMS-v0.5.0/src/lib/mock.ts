import type { Activity, DashboardMetrics, Student, TrendPoint } from './types'

const rupees = (v: number) => v * 100

export const mockMetrics: DashboardMetrics = {
  today: rupees(84_500),
  week: rupees(312_000),
  month: rupees(892_500),
  academicYear: rupees(6_740_000),
  allTime: rupees(18_450_000),
  gross: rupees(910_000),
  refunds: rupees(17_500),
  net: rupees(892_500),
  outstanding: rupees(1_428_000),
  students: 603,
  defaulters: 147,
  paidThisMonth: 421,
  partialThisMonth: 35,
}

export const mockTrend: TrendPoint[] = [
  { label: 'Mon', amount: rupees(44_000) },
  { label: 'Tue', amount: rupees(67_500) },
  { label: 'Wed', amount: rupees(52_000) },
  { label: 'Thu', amount: rupees(89_000) },
  { label: 'Fri', amount: rupees(74_000) },
  { label: 'Sat', amount: rupees(102_500) },
  { label: 'Sun', amount: rupees(0) },
]

const names = [
  ['Kaneez Zainab', '201616', '10', 'A', 2200, 2150, 4350],
  ['Salman Babar', '201584', '10', 'A', 2200, 2150, 2200],
  ['Abu Bakar Khalid', '201702', '10', 'B', 2200, 2150, 0],
  ['Umme Habiba', '198422', '9', 'A', 2200, 2150, 2200],
  ['Hira Haseeb', '208811', '8', 'A', 2000, 2150, 2000],
  ['Zahra Haseeb', '208812', '7', 'A', 2000, 2150, 0],
  ['Gul-e-Eman', '208813', '7', 'B', 2000, 2150, 1500],
  ['Wasi Ullah', '208814', '6', 'A', 2000, 2150, 4000],
  ['Ayesha Noor', '208815', '5', 'A', 2000, 2150, 0],
  ['Muhammad Ahmad', '208816', '4', 'B', 2000, 2150, 2000],
  ['Fatima Zahra', '208817', '3', 'A', 2000, 2150, 4150],
  ['Ali Raza', '208818', '2', 'A', 2000, 2150, 0],
] as const

export const mockStudents: Student[] = names.map((n, i) => ({
  id: `stu-${i + 1}`,
  admissionNo: `UES-${String(1001 + i)}`,
  rollNo: n[1],
  name: n[0],
  guardian: i % 2 ? 'Muhammad Aslam' : 'Muhammad Imran',
  phone: `03${String(10 + i).padStart(2, '0')}-1234567`,
  className: n[2],
  section: n[3],
  monthlyFee: rupees(n[4]),
  annualFund: rupees(n[5]),
  outstanding: rupees(n[6]),
  advance: i === 2 ? rupees(4000) : 0,
  status: 'active',
}))

export const mockActivity: Activity[] = [
  { id: '1', title: 'Receipt UES-2026-001842', detail: 'Rs. 2,000 · Class 7A · Cash', time: '4 min ago', tone: 'good' },
  { id: '2', title: 'Partial payment recorded', detail: 'Rs. 1,500 against September invoice', time: '18 min ago', tone: 'warn' },
  { id: '3', title: 'Annual fund collected', detail: 'Rs. 2,150 · Student UES-1008', time: '31 min ago', tone: 'good' },
  { id: '4', title: 'Daily closing pending', detail: 'Cashier closing has not been posted yet', time: 'Today', tone: 'neutral' },
]
