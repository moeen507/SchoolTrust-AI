export const desktop = window.umeedDesktop
export const isDesktop = Boolean(window.umeedDesktop)

export async function printCurrentPage(){
  if(desktop) return desktop.print({})
  window.print(); return {ok:true}
}

export async function saveCurrentPagePdf(filename:string){
  if(desktop) return desktop.savePdf(filename)
  window.print(); return {ok:true,canceled:false}
}

export async function saveText(filename:string,text:string,kind:'json'|'csv'|'txt'='txt'){
  if(desktop) return desktop.saveTextFile({suggestedName:filename,text,filters:[{name:kind.toUpperCase(),extensions:[kind]}]})
  const blob=new Blob([text],{type:kind==='json'?'application/json':kind==='csv'?'text/csv':'text/plain'})
  const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url;a.download=filename;a.click();URL.revokeObjectURL(url)
  return {ok:true}
}
