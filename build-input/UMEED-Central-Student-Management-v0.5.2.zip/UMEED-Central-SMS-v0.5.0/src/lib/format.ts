export const formatMoney = (amountMinor: number) =>
  new Intl.NumberFormat('en-PK', { style: 'currency', currency: 'PKR', maximumFractionDigits: 0 }).format(amountMinor / 100)

export const compactMoney = (amountMinor: number) => {
  const rupees = amountMinor / 100
  if (rupees >= 1_000_000) return `Rs. ${(rupees / 1_000_000).toFixed(2)}M`
  if (rupees >= 1_000) return `Rs. ${(rupees / 1_000).toFixed(1)}K`
  return `Rs. ${rupees.toLocaleString('en-PK')}`
}

export const initials = (name: string) => name.split(' ').filter(Boolean).slice(0, 2).map((p) => p[0]).join('').toUpperCase()
