export type RuntimeBackendConfig = {
  url: string
  publishableKey: string
  orgSlug: string
}

const KEYS = {
  url: 'umeed.backend.url',
  key: 'umeed.backend.publishableKey',
  org: 'umeed.backend.orgSlug',
}

function safeGet(key: string) {
  try { return window.localStorage.getItem(key) || '' } catch { return '' }
}

export function getRuntimeBackendConfig(): RuntimeBackendConfig {
  const envUrl = (import.meta.env.VITE_SUPABASE_URL as string | undefined) || ''
  const envKey = (import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string | undefined) || ''
  const envOrg = (import.meta.env.VITE_DEFAULT_ORG_SLUG as string | undefined) || 'umeed-education-system'
  const storedUrl = typeof window !== 'undefined' ? safeGet(KEYS.url) : ''
  const storedKey = typeof window !== 'undefined' ? safeGet(KEYS.key) : ''
  const storedOrg = typeof window !== 'undefined' ? safeGet(KEYS.org) : ''
  return {
    url: storedUrl || envUrl,
    publishableKey: storedKey || envKey,
    orgSlug: storedOrg || envOrg,
  }
}

export function saveRuntimeBackendConfig(input: RuntimeBackendConfig) {
  const url = input.url.trim().replace(/\/$/, '')
  const publishableKey = input.publishableKey.trim()
  const orgSlug = input.orgSlug.trim().toLowerCase() || 'umeed-education-system'
  if (url && !/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(url)) {
    throw new Error('Use a valid Supabase project URL such as https://project-ref.supabase.co')
  }
  if (publishableKey && !publishableKey.startsWith('sb_publishable_') && !publishableKey.startsWith('eyJ')) {
    throw new Error('Use the Supabase publishable key. Never enter a secret/service-role key here.')
  }
  window.localStorage.setItem(KEYS.url, url)
  window.localStorage.setItem(KEYS.key, publishableKey)
  window.localStorage.setItem(KEYS.org, orgSlug)
}

export function clearRuntimeBackendConfig() {
  Object.values(KEYS).forEach(k => window.localStorage.removeItem(k))
}
