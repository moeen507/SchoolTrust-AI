export type Role =
  | 'owner' | 'super_admin' | 'admin' | 'cashier' | 'accountant' | 'student' | 'guardian' | 'auditor'
  | 'academic_manager' | 'teacher' | 'store_clerk' | 'canteen_cashier'
  | 'platform_owner' | 'platform_support' | 'platform_billing' | 'support_viewer'

export type AppUser = {
  id: string
  name: string
  email: string
  role: Role
  organizationId: string
  organizationName: string
  platformRole?: 'platform_owner' | 'platform_support' | 'platform_billing'
  supportSessionId?: string
}

export type Student = {
  id: string
  admissionNo: string
  rollNo: string
  name: string
  guardian: string
  phone: string
  className: string
  section: string
  monthlyFee: number
  annualFund: number
  outstanding: number
  advance: number
  status: 'active' | 'inactive' | 'graduated' | 'left'
}

export type DashboardMetrics = {
  today: number
  week: number
  month: number
  academicYear: number
  allTime: number
  gross: number
  refunds: number
  net: number
  outstanding: number
  students: number
  defaulters: number
  paidThisMonth: number
  partialThisMonth: number
}

export type TrendPoint = { label: string; amount: number }
export type Activity = { id: string; title: string; detail: string; time: string; tone: 'good' | 'warn' | 'neutral' }

export type ReceiptRecord = {
  paymentId: string
  receiptNo: string
  receivedAt: string
  amountMinor: number
  refundedMinor: number
  allocatedMinor: number
  creditCreatedMinor: number
  paymentMethod: string
  reference?: string
  notes?: string
  studentId: string
  admissionNo: string
  rollNo: string
  studentName: string
  guardianName: string
  className: string
  section: string
  organizationName: string
  platformRole?: 'platform_owner' | 'platform_support' | 'platform_billing'
  supportSessionId?: string
}

export type RefundRecord = {
  id: string
  refundNo: string
  paymentId: string
  receiptNo: string
  studentId: string
  studentName: string
  amountMinor: number
  reason: string
  status: 'pending' | 'posted' | 'rejected' | 'voided'
  createdAt: string
  approvedAt?: string
  rejectionReason?: string
}

export type LedgerEntry = {
  occurredAt: string
  entryType: 'invoice' | 'payment' | 'refund'
  reference: string
  label: string
  debitMinor: number
  creditMinor: number
  status: string
}

export type GuardianChild = {
  studentId: string
  admissionNo: string
  rollNo: string
  name: string
  className: string
  section: string
  outstanding: number
  credit: number
}

export type AcademicSessionOption = { id: string; name: string; active: boolean; startsOn: string; endsOn: string }
export type ClassOption = { id: string; name: string; sortOrder: number }
export type SectionOption = { id: string; classId: string; name: string }

export type CashierShift = {
  id: string
  openedAt: string
  closedAt?: string
  openingCashMinor: number
  expectedCashMinor?: number
  countedCashMinor?: number
  varianceMinor?: number
  status: 'open' | 'closed'
}

export type ImportPreview = {
  jobId: string
  dryRun: boolean
  total: number
  valid: number
  invalid: number
  errors: Array<{ row?: number; error: string }>
}

export type TenantSummary = {
  id: string
  name: string
  slug: string
  status: string
  plan: string
  subscriptionStatus: string
  trialEndsAt?: string
  currentPeriodEnd?: string
  activeStudents: number
  activeStaff: number
  createdAt: string
}

export type NotificationQueueSummary = {
  pending: number
  sent: number
  failed: number
  today: number
}


export type OrganizationSettings = {
  id: string
  name: string
  slug: string
  status: string
  currency: string
  timezone: string
  receiptPrefix: string
  branding: Record<string, unknown>
  settings: Record<string, unknown>
}

export type StaffRole = 'super_admin' | 'admin' | 'cashier' | 'accountant' | 'auditor' | 'academic_manager' | 'teacher' | 'store_clerk' | 'canteen_cashier'

export type StaffSummary = {
  membershipId: string
  userId: string
  fullName: string
  email?: string
  role: StaffRole
  active: boolean
  createdAt: string
}

export type AuditEvent = {
  id: number
  actorId?: string
  actorName: string
  action: string
  entityType: string
  entityId?: string
  beforeData?: Record<string, unknown> | null
  afterData?: Record<string, unknown> | null
  createdAt: string
}


export type SaleChannel = 'student_store' | 'canteen'

export type CounterStudent = {
  id: string
  admissionNo: string
  rollNo: string
  name: string
  className: string
  section: string
}

export type CatalogItem = {
  id: string
  sku: string
  name: string
  category: string
  channel: 'student_store' | 'canteen' | 'both'
  unitPriceMinor: number
  trackStock: boolean
  stockQuantity: number
  active: boolean
}

export type SaleSlipItem = {
  name: string
  sku: string
  quantity: number
  unitPriceMinor: number
  totalMinor: number
}

export type SaleSlip = {
  saleId: string
  studentId: string
  channel: SaleChannel
  slipNo: string
  soldAt: string
  subtotalMinor: number
  discountMinor: number
  totalMinor: number
  paymentMethod: string
  reference?: string
  notes?: string
  status: 'posted' | 'voided'
  admissionNo: string
  rollNo: string
  studentName: string
  className: string
  section: string
  organizationName: string
  items: SaleSlipItem[]
}

export type AcademicSubject = { id: string; code: string; name: string; active: boolean }
export type AcademicExam = { id: string; name: string; term?: string; status: 'draft'|'published'|'locked'; startsOn?: string; endsOn?: string }
export type ExamSubject = { id: string; examId: string; classId: string; sectionId?: string; subjectId: string; subjectName: string; maxMarks: number; passMarks: number }
export type PerformanceRow = { examId: string; examName: string; term?: string; subjectId: string; subjectName: string; maxMarks: number; passMarks: number; marksObtained: number; percentage: number; passed: boolean; grade?: string; gradeRemark?: string; remarks?: string; updatedAt: string }
export type AttendanceSummary = { recordedDays: number; presentDays: number; absentDays: number; lateDays: number; leaveDays: number; attendancePercentage: number }
export type AttendanceRecord = { id: string; studentId: string; date: string; status: 'present'|'absent'|'late'|'leave'|'holiday'; remarks?: string }
