import { createClient } from '@supabase/supabase-js'
import { getRuntimeBackendConfig } from './runtimeConfig'

const runtime = getRuntimeBackendConfig()
const url = runtime.url
const key = runtime.publishableKey

export const isSupabaseConfigured = Boolean(url && key && !url.includes('YOUR_PROJECT'))

export const supabase = isSupabaseConfigured
  ? createClient(url, key, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: !window.umeedDesktop },
      db: { schema: 'public' },
    })
  : null
