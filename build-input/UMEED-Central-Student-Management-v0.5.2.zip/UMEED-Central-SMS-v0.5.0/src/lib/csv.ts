export type CsvRow = Record<string, string>

export function parseCsv(text: string): CsvRow[] {
  const rows: string[][] = []
  let row: string[] = []
  let cell = ''
  let quoted = false
  const source = text.replace(/^\uFEFF/, '')
  for (let i = 0; i < source.length; i++) {
    const ch = source[i]
    if (quoted) {
      if (ch === '"' && source[i + 1] === '"') { cell += '"'; i++ }
      else if (ch === '"') quoted = false
      else cell += ch
    } else if (ch === '"') quoted = true
    else if (ch === ',') { row.push(cell.trim()); cell = '' }
    else if (ch === '\n') { row.push(cell.trim()); rows.push(row); row = []; cell = '' }
    else if (ch !== '\r') cell += ch
  }
  if (cell.length || row.length) { row.push(cell.trim()); rows.push(row) }
  if (!rows.length) return []
  const headers = rows[0].map(h => normalizeHeader(h))
  return rows.slice(1).filter(r => r.some(Boolean)).map(values => Object.fromEntries(headers.map((h, i) => [h, values[i] ?? ''])))
}

export function normalizeHeader(value: string) {
  const key = value.trim().toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '')
  const aliases: Record<string,string> = {
    admission: 'admission_no', admission_number: 'admission_no', admissionno: 'admission_no',
    roll: 'roll_no', roll_number: 'roll_no', rollno: 'roll_no',
    name: 'full_name', student_name: 'full_name', student: 'full_name',
    guardian: 'guardian_name', parent_name: 'guardian_name', father_name: 'guardian_name',
    mobile: 'guardian_phone', phone: 'guardian_phone', contact: 'guardian_phone',
    email: 'guardian_email', class: 'class_name', section: 'section_name',
  }
  return aliases[key] ?? key
}

export function csvTemplate() {
  return 'admission_no,roll_no,full_name,guardian_name,guardian_phone,guardian_email,class_name,section_name\nUES-0001,1,Student Name,Guardian Name,03000000000,parent@example.com,10,A\n'
}
