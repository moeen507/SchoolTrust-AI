import { Navigate, Route, Routes } from 'react-router-dom'
import { AuthProvider, useAuth } from './context/AuthContext'
import { Shell } from './components/Shell'
import { LoginPage } from './pages/LoginPage'
import { DashboardPage } from './pages/DashboardPage'
import { StudentsPage } from './pages/StudentsPage'
import { FeeCollectionPage } from './pages/FeeCollectionPage'
import { DefaultersPage } from './pages/DefaultersPage'
import { ReportsPage } from './pages/ReportsPage'
import { SettingsPage } from './pages/SettingsPage'
import { StudentPortalPage } from './pages/StudentPortalPage'
import { BillingPage } from './pages/BillingPage'
import { RefundsPage } from './pages/RefundsPage'
import { OperationsPage } from './pages/OperationsPage'
import { ImportPage } from './pages/ImportPage'
import { AcademicPage } from './pages/AcademicPage'
import { AccessPage } from './pages/AccessPage'
import { NotificationsPage } from './pages/NotificationsPage'
import { PlatformPage } from './pages/PlatformPage'
import { ReceiptPage } from './pages/ReceiptPage'
import { CommercePage } from './pages/CommercePage'
import { SaleSlipPage } from './pages/SaleSlipPage'
import { LedgerPage } from './pages/LedgerPage'

const platformRoles = ['platform_owner','platform_support','platform_billing']

function AppRoutes(){
  const { user, loading } = useAuth()
  if (loading) return <div className="boot-screen"><div className="boot-logo">U</div><span>Loading secure workspace…</span></div>
  if (!user) return <LoginPage />
  if (user.role === 'student' || user.role === 'guardian') return <StudentPortalPage />
  if (platformRoles.includes(user.role)) return <Shell><Routes><Route path="/" element={<PlatformPage/>}/><Route path="*" element={<Navigate to="/" replace/>}/></Routes></Shell>
  return <Shell><Routes>
    <Route path="/" element={user.role==='teacher'||user.role==='academic_manager'?<AcademicPage/>:user.role==='store_clerk'||user.role==='canteen_cashier'?<CommercePage/>:<DashboardPage/>}/>
    <Route path="/students" element={['owner','super_admin','admin','cashier','accountant','auditor','academic_manager','support_viewer'].includes(user.role)?<StudentsPage/>:<Navigate to="/"/>}/>
    <Route path="/ledger" element={['owner','super_admin','admin','cashier','accountant','auditor','support_viewer'].includes(user.role)?<LedgerPage/>:<Navigate to="/"/>}/>
    <Route path="/collect" element={['owner','super_admin','cashier','accountant'].includes(user.role)?<FeeCollectionPage/>:<Navigate to="/"/>}/>
    <Route path="/billing" element={['owner','super_admin','admin','accountant'].includes(user.role)?<BillingPage/>:<Navigate to="/"/>}/>
    <Route path="/refunds" element={['owner','super_admin','cashier','accountant','auditor'].includes(user.role)?<RefundsPage/>:<Navigate to="/"/>}/>
    <Route path="/operations" element={['owner','super_admin','cashier','accountant','auditor'].includes(user.role)?<OperationsPage/>:<Navigate to="/"/>}/>
    <Route path="/defaulters" element={['owner','super_admin','admin','cashier','accountant','auditor','support_viewer'].includes(user.role)?<DefaultersPage/>:<Navigate to="/"/>}/>
    <Route path="/reports" element={['owner','super_admin','admin','accountant','auditor','support_viewer'].includes(user.role)?<ReportsPage/>:<Navigate to="/"/>}/>
    <Route path="/academic" element={['owner','super_admin','admin','academic_manager','teacher'].includes(user.role)?<AcademicPage/>:<Navigate to="/"/>}/>
    <Route path="/sales" element={['owner','super_admin','admin','accountant','store_clerk','canteen_cashier'].includes(user.role)?<CommercePage/>:<Navigate to="/"/>}/>
    <Route path="/import" element={['owner','super_admin','admin','accountant'].includes(user.role)?<ImportPage/>:<Navigate to="/"/>}/>
    <Route path="/access" element={['owner','super_admin','admin'].includes(user.role)?<AccessPage/>:<Navigate to="/"/>}/>
    <Route path="/notifications" element={['owner','super_admin','admin','accountant','auditor'].includes(user.role)?<NotificationsPage/>:<Navigate to="/"/>}/>
    <Route path="/settings" element={['owner','super_admin'].includes(user.role)?<SettingsPage/>:<Navigate to="/"/>}/>
    <Route path="/receipt/:receiptNo" element={<ReceiptPage/>}/>
    <Route path="/sale-slip/:slipNo" element={<SaleSlipPage/>}/>
    <Route path="*" element={<Navigate to="/" replace/>}/>
  </Routes></Shell>
}

export default function App(){return <AuthProvider><AppRoutes/></AuthProvider>}
