export function Logo({ compact = false }: { compact?: boolean }) {
  return <div className={`brand ${compact ? 'brand--compact' : ''}`}>
    <div className="brand-mark"><span>U</span></div>
    {!compact && <div><strong>UMEED Central</strong><small>Education Finance OS</small></div>}
  </div>
}
