import { AlertTriangle, ArrowRight, X } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { compactMoney } from '../lib/format'

export function DefaulterModal({ open, onClose, count, outstanding }: { open: boolean; onClose: () => void; count: number; outstanding: number }) {
  const navigate = useNavigate()
  if (!open) return null
  return <div className="modal-backdrop" onMouseDown={onClose}>
    <section className="modal-card" onMouseDown={(e) => e.stopPropagation()}>
      <button className="icon-button modal-close" onClick={onClose}><X size={18} /></button>
      <div className="modal-alert-icon"><AlertTriangle size={26} /></div>
      <span className="eyebrow">Current month fee alert</span>
      <h2>Defaulter review required</h2>
      <p><strong>{count}</strong> students have unpaid or partially paid current-month fees. Total outstanding is <strong>{compactMoney(outstanding)}</strong>.</p>
      <div className="modal-actions">
        <button className="button ghost" onClick={onClose}>Review later</button>
        <button className="button primary" onClick={() => { onClose(); navigate('/defaulters') }}>View defaulters <ArrowRight size={17} /></button>
      </div>
    </section>
  </div>
}
