import type { TrendPoint } from '../lib/types'

export function SparkBars({ data }: { data: TrendPoint[] }) {
  const max = Math.max(1, ...data.map((d) => d.amount))
  return <div className="spark-chart" aria-label="Seven day collection trend">
    {data.map((d) => <div className="spark-col" key={d.label}>
      <div className="spark-bar-wrap"><div className="spark-bar" style={{ height: `${Math.max(4, (d.amount / max) * 100)}%` }} /></div>
      <span>{d.label}</span>
    </div>)}
  </div>
}
