import type { LucideIcon } from 'lucide-react'

export function KpiCard({ icon: Icon, label, value, hint, accent = 'gold' }: { icon: LucideIcon; label: string; value: string; hint?: string; accent?: 'gold' | 'green' | 'red' | 'blue' }) {
  return <article className={`kpi-card kpi-card--${accent}`}>
    <div className="kpi-icon"><Icon size={19} /></div>
    <div className="kpi-copy"><span>{label}</span><strong>{value}</strong>{hint && <small>{hint}</small>}</div>
  </article>
}
