import { useEffect, useMemo, useState, type ReactNode } from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import { Bell, BookOpenCheck, Building2, Calculator, ChevronDown, CircleDollarSign, Coffee, CreditCard, FileBarChart2, Headphones, History, Import, KeyRound, LayoutDashboard, LogOut, Menu, Moon, ReceiptText, RotateCcw, Search, Send, Settings, ShieldCheck, ShoppingBag, Sun, Users, WalletCards, X } from 'lucide-react'
import { Logo } from './Logo'
import { useAuth } from '../context/AuthContext'
import { initials } from '../lib/format'

const navGroups = [
  {label:'Main Workspace',items:[
    { to:'/', label:'Dashboard', icon:LayoutDashboard, roles:['owner','super_admin','admin','cashier','accountant','auditor','academic_manager','teacher','store_clerk','canteen_cashier','support_viewer'] },
    { to:'/students', label:'Students', icon:Users, roles:['owner','super_admin','admin','cashier','accountant','auditor','academic_manager','support_viewer'] },
    { to:'/ledger', label:'Student Ledger', icon:History, roles:['owner','super_admin','admin','cashier','accountant','auditor','support_viewer'] },
  ]},
  {label:'Finance',items:[
    { to:'/collect', label:'Fee Entry', icon:WalletCards, roles:['owner','super_admin','cashier','accountant'] },
    { to:'/billing', label:'Billing', icon:ReceiptText, roles:['owner','super_admin','admin','accountant'] },
    { to:'/defaulters', label:'Defaulters', icon:CreditCard, roles:['owner','super_admin','admin','cashier','accountant','auditor','support_viewer'] },
    { to:'/refunds', label:'Refunds', icon:RotateCcw, roles:['owner','super_admin','cashier','accountant','auditor'] },
    { to:'/operations', label:'Cashier Close', icon:Calculator, roles:['owner','super_admin','cashier','accountant','auditor'] },
    { to:'/reports', label:'Reports', icon:FileBarChart2, roles:['owner','super_admin','admin','accountant','auditor','support_viewer'] },
  ]},
  {label:'Academic & Student Services',items:[
    { to:'/academic', label:'Academic Hub', icon:BookOpenCheck, roles:['owner','super_admin','admin','academic_manager','teacher'] },
    { to:'/sales', label:'Store & Canteen', icon:ShoppingBag, roles:['owner','super_admin','admin','accountant','store_clerk','canteen_cashier'] },
    { to:'/notifications', label:'Notifications', icon:Send, roles:['owner','super_admin','admin','accountant','auditor'] },
  ]},
  {label:'Administration',items:[
    { to:'/import', label:'Import Data', icon:Import, roles:['owner','super_admin','admin','accountant'] },
    { to:'/access', label:'Access Control', icon:KeyRound, roles:['owner','super_admin','admin'] },
    { to:'/settings', label:'Settings', icon:Settings, roles:['owner','super_admin'] },
    { to:'/', label:'Tenants', icon:Building2, roles:['platform_owner','platform_support','platform_billing'] },
  ]},
] as const

const pageNames:Record<string,{title:string;sub:string}>={
  '/':{title:'Dashboard',sub:'Student Management Command Center'},
  '/students':{title:'Students',sub:'Student Registry'},
  '/ledger':{title:'Ledger',sub:'Central Student Account'},
  '/collect':{title:'Fee Entry',sub:'School Fee Counter'},
  '/billing':{title:'Billing',sub:'Monthly Fee & Annual Fund'},
  '/defaulters':{title:'Defaulters',sub:'Recovery & Follow-up'},
  '/refunds':{title:'Refunds',sub:'Controlled Reversals'},
  '/operations':{title:'Cashier Close',sub:'Daily Reconciliation'},
  '/reports':{title:'Reports',sub:'Finance & Student Intelligence'},
  '/academic':{title:'Academic Hub',sub:'Attendance, Exams & Performance'},
  '/sales':{title:'Student Services',sub:'Store & Canteen Counters'},
  '/notifications':{title:'Notifications',sub:'Student & Guardian Communication'},
  '/import':{title:'Import',sub:'Bulk Student Data'},
  '/access':{title:'Access Control',sub:'Users, Roles & Guardians'},
  '/settings':{title:'Settings',sub:'Institute Configuration'},
}

export function Shell({ children }: { children: ReactNode }) {
  const { user, signOut, liveMode, exitSupportMode } = useAuth()
  const [open,setOpen]=useState(false)
  const [theme,setTheme]=useState<'dark'|'ivory'>('dark')
  const location=useLocation()
  useEffect(()=>setOpen(false),[location.pathname])
  useEffect(()=>{document.documentElement.dataset.theme=theme},[theme])
  if(!user)return null
  const groups=useMemo(()=>navGroups.map(g=>({...g,items:g.items.filter(n=>(n.roles as readonly string[]).includes(user.role))})).filter(g=>g.items.length),[user.role])
  const page=pageNames[location.pathname]??{title:'UMEED Central',sub:'Student Management System'}
  const mobileItems=groups.flatMap(g=>g.items).filter(x=>['/','/students','/collect','/academic','/sales'].includes(x.to)).slice(0,5)
  return <div className="app-shell legacy-shell">
    <aside className={`sidebar legacy-sidebar ${open?'sidebar--open':''}`}>
      <div className="sidebar-top legacy-brand-row"><Logo/><button className="icon-button sidebar-x" onClick={()=>setOpen(false)}><X size={18}/></button></div>
      <div className={`mode-pill ${liveMode?'live':'demo'}`}><span/>{liveMode?'Central database connected':'Preview database mode'}</div>
      {user.role==='support_viewer'&&<div className="support-mode-card"><Headphones size={17}/><div><strong>Read-only support</strong><span>{user.organizationName}</span></div><button className="icon-button" title="Exit support session" onClick={exitSupportMode}><X size={16}/></button></div>}
      <nav className="sidebar-nav legacy-nav">{groups.map(group=><div className="legacy-nav-group" key={group.label}><span className="nav-label">{group.label}</span>{group.items.map(item=><NavLink to={item.to} key={`${group.label}-${item.to}-${item.label}`} className={({isActive})=>`nav-item ${isActive?'active':''}`} end={item.to==='/' }><item.icon size={17}/><span>{item.label}</span></NavLink>)}</div>)}</nav>
      <div className="sidebar-foot"><div className="security-chip"><ShieldCheck size={17}/><div><strong>Protected student ledger</strong><span>Tenant + role + RLS scoped</span></div></div><button className="nav-item signout" onClick={signOut}><LogOut size={18}/><span>Sign out</span></button></div>
    </aside>
    {open&&<button className="sidebar-overlay" onClick={()=>setOpen(false)} aria-label="Close menu"/>}
    <main className="main-area">
      <header className="topbar legacy-topbar">
        <button className="icon-button mobile-menu" onClick={()=>setOpen(true)}><Menu size={20}/></button>
        <div className="desktop-page-id"><span>{page.sub}</span><strong>{page.title}</strong></div>
        <div className="top-search"><Search size={16}/><input placeholder="Search student, roll no, receipt or slip..."/><kbd>Ctrl K</kbd></div>
        <div className="top-actions"><div className="counter-shortcuts"><span title="Fee receipt"><CircleDollarSign size={15}/></span><span title="Student store"><ShoppingBag size={15}/></span><span title="Canteen"><Coffee size={15}/></span></div><button className="icon-button" onClick={()=>setTheme(theme==='dark'?'ivory':'dark')}>{theme==='dark'?<Sun size={17}/>:<Moon size={17}/>}</button><button className="icon-button notification"><Bell size={17}/><span/></button><div className="profile-chip"><div className="avatar">{initials(user.name)}</div><div><strong>{user.name}</strong><span>{user.role.replaceAll('_',' ')}</span></div><ChevronDown size={14}/></div></div>
      </header>
      <div className="workspace legacy-workspace">{children}</div>
      <nav className="mobile-bottom-nav">{mobileItems.map(item=><NavLink to={item.to} key={`mobile-${item.to}-${item.label}`} className={({isActive})=>isActive?'active':''} end={item.to==='/' }><item.icon size={18}/><span>{item.label.replace('Fee Entry','Fees').replace('Store & Canteen','Services').replace('Academic Hub','Academic')}</span></NavLink>)}</nav>
    </main>
  </div>
}
