# UMEED Desktop Design Reference Map

v0.5 uses the April/May 2026 UMEED desktop fee-management workspace as the visual/interaction reference.

## Preserved design characteristics

- Dark charcoal desktop canvas
- Maroon and champagne-gold accent hierarchy
- Dense desktop-first information layout
- Student Registry / financial table emphasis
- Class-wise filtering
- Clickable student account/ledger cards
- Total Paid / Outstanding / Advance-style financial summaries
- Separate annual-fund visibility
- Compact transaction-history tables
- Professional ERP report filters
- Wide desktop reports rather than mobile-card-only design
- A5/printable financial document direction

## Modernized underneath

- Central Supabase/Postgres data source
- Multi-tenant SaaS isolation
- Database RLS
- Server-generated receipt/slip numbering
- Atomic payment allocation
- Refund approval/reversal ledger
- Guardian/student authentication
- Academic attendance/exam/result workflow
- Student Store and Canteen independent ledgers
- PWA/mobile self-service

The rule for future UI changes is: preserve the UMEED desktop workspace identity unless a specific workflow requires a different mobile presentation.
