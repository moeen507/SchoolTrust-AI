# Mobile / PWA Client

## Purpose
The mobile client uses the same React application, Supabase Auth session and central Postgres data as the Windows desktop client. There is no duplicate mobile database.

## Student and guardian mobile functions
- Sign in with the issued student/guardian credentials.
- View class, section, roll and admission identity.
- View only Published/Locked exam performance.
- View subject marks, percentage, tenant grading scale and pass/fail status.
- View attendance percentage and recent attendance history.
- View tuition/school-fee ledger and advance credit.
- View Student Store slips.
- View Canteen slips.
- Guardians can switch between linked children.

## Admin/counter mobile functions
The responsive shell also works on a phone for urgent administrative use. Role permissions remain identical to desktop. A mobile screen does not gain extra access.

## Installation
### Android
Open the deployed HTTPS site in Chrome/Edge and use **Install app** or **Add to Home screen** when offered.

### iPhone/iPad
Open the deployed HTTPS site in Safari, use Share, then **Add to Home Screen**.

## Offline model
The service worker caches the application shell/static assets for a faster launch. It does not create offline financial or academic mutations. Posting fees, Store/Canteen sales, attendance or marks requires the central server so sequence numbers, access rules and audit logs stay authoritative.

## Native app later
A later Android/iOS wrapper can reuse this client and backend. Native packaging should not fork the business rules or create another source of truth.
