# Product status and commercial rollout gates

## Implemented in v0.4 source
- Central multi-tenant student identity and role model.
- School fee billing/payment/refund/advance-credit architecture.
- Cashier opening/closing and reporting foundations.
- Student and guardian portals.
- Academic attendance, subjects, exams, marks and grading.
- Controlled exam publication and locking.
- Student Store catalog, stock, posting and independent slips.
- Canteen catalog, stock, posting and independent slips.
- Student-linked Store/Canteen history.
- Responsive installable PWA shell for student/guardian mobile use.
- Windows Electron desktop shell and installer/portable build configuration.
- Bulk student import and academic promotion foundation.
- Defaulter and notification queue/dispatcher architecture.
- Tenant/platform administration foundations.

## Required validation before commercial rollout
- Run all migrations on the real Supabase project and run security/performance advisors.
- Execute the full role/RLS matrix with real Auth users.
- Complete a networked `npm install`, typecheck, production web build and Windows build.
- Code-sign Windows installer/update artifacts.
- Reconcile migrated UMEED v1.2 ledger against real historical totals.
- Perform receipt/A4 printer tests.
- Configure and test the selected SMS/WhatsApp/email provider.
- Run backup restoration and disaster-recovery drill.
- Run load/concurrency tests with production-like student, mark and transaction volumes.
- Perform external security review before onboarding third-party institutions.

## Later extensions
These are optional modules rather than blockers for the Student Management core: timetable, homework/daily diary, library, transport, HR/payroll and inventory beyond Student Store/Canteen.
