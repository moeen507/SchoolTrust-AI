# UMEED Central Desktop

## Purpose
The desktop client is the cashier/admin workstation for the centralized UMEED Central SaaS. It never stores a second authoritative financial ledger. Supabase/Postgres remains the source of truth.

## Windows requirements
- Windows 10/11 64-bit
- Node.js 22+ for developers/build machines
- Internet access to the configured Supabase project for live financial operations
- Receipt/A4 printer optional

## Configure
Copy `.env.example` to `.env` and set the public Supabase URL and **publishable** key only. Never put a secret/service-role key in the desktop client.

## Development
```bash
npm install
npm run desktop:dev
```

## Production build
```bash
npm install
npm run desktop:verify
npm run typecheck
npm run build
npm run desktop:build
```

Artifacts are written to `release/`:
- NSIS Windows installer
- x64 portable EXE

## Security model
- `contextIsolation: true`
- `nodeIntegration: false`
- Chromium sandbox enabled
- permission requests denied by default
- renderer has no filesystem or Node access
- all filesystem/printing operations use a narrow preload IPC API
- untrusted navigation is blocked and external HTTPS/mail/tel links are opened by the OS
- single application instance
- no Supabase secret key in renderer

## Printing
Receipt screens can use native Windows printing or Electron `printToPDF`. PDFs are generated from the current receipt view with print CSS.

## Updates
Set `UMEED_UPDATE_URL` in the packaged app environment to a generic electron-builder update feed. Update downloads are opt-in. For commercial distribution, code-sign the installer and update artifacts before enabling automatic updates.

## Offline behavior
Authentication sessions/cache may remain locally available, but **payments, refunds and other financial mutations are not committed offline**. This is deliberate. Financial writes require the central server so receipt numbering, idempotency and balances remain correct.
