# Architecture

## Product boundary

UMEED Central is designed as a multi-tenant SaaS. Every business record carries `organization_id`. A user reaches an organization through `organization_memberships`; a student reaches only their own row (or rows explicitly linked to a guardian).

## Runtime

- React + TypeScript + Vite frontend.
- Supabase Auth for identity and sessions.
- Supabase Postgres as the authoritative finance database.
- RLS for row authorization.
- Edge Functions for privileged user provisioning.
- Database RPCs for atomic financial mutations.
- Netlify-compatible SPA deployment.
- Responsive/PWA shell so the same web client can later become an installable mobile experience.

## Financial flow

1. Cashier searches a student.
2. Client sends amount, method and an idempotency UUID to `record_payment`.
3. Database verifies the signed-in user has an allowed finance role in the student's organization.
4. Database atomically generates the next tenant receipt number.
5. Payment is inserted once.
6. Payment is allocated to the oldest open invoices.
7. Surplus becomes a student credit/advance balance.
8. An immutable audit event is inserted.
9. Dashboards and student portals read the same central ledger.

## Tenant scale

The schema is not tied to UMEED. Branding, receipt prefix, currency, timezone, academic sessions, fee structures, users, classes and students are tenant-scoped. This is the base required for selling the platform to other institutions without forking code.
