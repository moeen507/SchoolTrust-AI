# Security baseline

- No secret/service key is shipped to React or Electron clients.
- Client uses only a Supabase publishable key.
- Every exposed business table has RLS enabled.
- Data API privileges are granted explicitly because new Supabase projects no longer automatically expose new public tables by default in 2026.
- Student and guardian access is linked to `auth.uid()` through database policies.
- Financial inserts are not granted directly to authenticated clients; they go through guarded RPC functions.
- Receipt sequence is not directly readable/writable by clients.
- Payment requests are idempotent per organization.
- Roles are stored in database membership rows, not user-editable metadata.
- Privileged Auth user creation happens in Edge Functions with server secrets.
- `app_metadata` may carry non-authoritative account context, but database membership remains the authorization source.
- Audit records are append-only from the client perspective.

Before commercial launch: enable MFA for privileged staff, configure custom SMTP, session policy, rate limits, bot protection, backup/PITR policy, log alerts, CSP/security headers, dependency scanning and penetration testing.
