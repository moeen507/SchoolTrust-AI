# Student Management Product Scope

## Product focus
UMEED Central is not intended to become an unfocused all-purpose ERP. Its commercial core is:

1. Student identity and lifecycle
2. Academic performance and attendance
3. School fee management
4. Student-linked Store purchases
5. Student-linked Canteen purchases
6. Student/guardian self-service on mobile
7. Administrative control and reporting

## Entry workspaces

### Fee Counter
Authorized roles: Fee Cashier, Accountant, Owner/Super Admin.
Posts only school-fee payments. Generates the fee receipt series and affects invoices, allocations, advance credit and the school-fee ledger.

### Student Store Counter
Authorized roles: Store Clerk plus authorized management/accounting roles.
Posts books, fee cards, envelopes, stationery and other institute items. Generates only the Student Store slip series. Supports stock tracking.

### Canteen Counter
Authorized roles: Canteen Cashier plus authorized management/accounting roles.
Posts student canteen purchases. Generates only the Canteen slip series. Supports stock tracking.

### Academic Workspace
Authorized roles: Academic Manager, Teacher and management roles.
Handles attendance, subjects, exams and marks. Students cannot enter or edit performance records.

## Student mobile experience
A student or linked guardian sees one consolidated identity with separate tabs for:
- Home summary
- Published academic performance
- Attendance
- Student Store and Canteen purchases
- School-fee ledger

Academic draft data is withheld until an authorized academic manager publishes an exam. A locked exam cannot be edited afterward through the transactional API.

## Ledger integrity
Fee, Store and Canteen transactions intentionally never share receipt numbering or accounting tables. Every non-fee sale contains the student ID, so an institute can match all transactions to one student without mixing their accounting meaning.
