'use strict'

const { app, BrowserWindow, dialog, ipcMain, shell, session, Menu, nativeTheme } = require('electron')
const fs = require('node:fs/promises')
const path = require('node:path')
const crypto = require('node:crypto')

const DEV_URL = process.env.VITE_DEV_SERVER_URL || 'http://127.0.0.1:5173'
const isDev = !app.isPackaged
const ALLOWED_EXTERNAL_PROTOCOLS = new Set(['https:', 'mailto:', 'tel:'])
let mainWindow = null

function appRoot(){ return path.join(__dirname, '..') }
function distIndex(){ return path.join(appRoot(), 'dist', 'index.html') }

function safeSuggestedName(name='export.txt') {
  return String(name).replace(/[<>:"/\\|?*\u0000-\u001F]/g, '_').slice(0, 160) || 'export.txt'
}

function isTrustedNavigation(url) {
  try {
    const parsed = new URL(url)
    if (isDev) return parsed.origin === new URL(DEV_URL).origin
    return parsed.protocol === 'file:' && path.normalize(decodeURIComponent(parsed.pathname)).includes(path.normalize(path.dirname(distIndex())))
  } catch { return false }
}

async function openExternalSafely(raw) {
  const parsed = new URL(String(raw))
  if (!ALLOWED_EXTERNAL_PROTOCOLS.has(parsed.protocol)) throw new Error('Blocked external protocol')
  await shell.openExternal(parsed.toString())
}

function createMenu(){
  const template = [
    { label:'File', submenu:[
      { label:'Print', accelerator:'CmdOrCtrl+P', click:()=>mainWindow?.webContents.print({printBackground:true}) },
      { type:'separator' },
      { role:'quit' },
    ]},
    { label:'View', submenu:[
      { role:'reload' }, { role:'forceReload' }, { type:'separator' },
      { role:'resetZoom' }, { role:'zoomIn' }, { role:'zoomOut' }, { role:'togglefullscreen' },
      ...(isDev ? [{ type:'separator' }, { role:'toggleDevTools' }] : []),
    ]},
    { label:'Help', submenu:[
      { label:'UMEED Central Website', click:()=>openExternalSafely('https://umeedschool.com').catch(()=>{}) },
      { label:`Version ${app.getVersion()}`, enabled:false },
    ]},
  ]
  Menu.setApplicationMenu(Menu.buildFromTemplate(template))
}

async function createWindow(){
  mainWindow = new BrowserWindow({
    width: 1500,
    height: 940,
    minWidth: 1100,
    minHeight: 720,
    show: false,
    backgroundColor: '#0e090c',
    autoHideMenuBar: true,
    icon: path.join(appRoot(),'build','icon.png'),
    title: 'UMEED Central',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false,
      spellcheck: false,
      devTools: isDev,
    },
  })

  mainWindow.once('ready-to-show', ()=>mainWindow?.show())
  mainWindow.webContents.setWindowOpenHandler(({url})=>{
    openExternalSafely(url).catch(()=>{})
    return {action:'deny'}
  })
  mainWindow.webContents.on('will-navigate',(event,url)=>{
    if (!isTrustedNavigation(url)) {
      event.preventDefault()
      openExternalSafely(url).catch(()=>{})
    }
  })

  if (isDev) await mainWindow.loadURL(DEV_URL)
  else await mainWindow.loadFile(distIndex())
}

function registerIpc(){
  ipcMain.handle('desktop:get-info', ()=>({
    desktop:true,
    version:app.getVersion(),
    platform:process.platform,
    packaged:app.isPackaged,
    theme:nativeTheme.shouldUseDarkColors?'dark':'light',
  }))

  ipcMain.handle('desktop:print', async (_event, options={})=>{
    if(!mainWindow) throw new Error('Window unavailable')
    return await new Promise((resolve,reject)=>{
      mainWindow.webContents.print({silent:false,printBackground:true,...options},(success,reason)=>success?resolve({ok:true}):reject(new Error(reason||'Print failed')))
    })
  })

  ipcMain.handle('desktop:save-pdf', async (_event, suggestedName='receipt.pdf')=>{
    if(!mainWindow) throw new Error('Window unavailable')
    const {canceled,filePath}=await dialog.showSaveDialog(mainWindow,{title:'Save PDF',defaultPath:safeSuggestedName(suggestedName),filters:[{name:'PDF',extensions:['pdf']}]})
    if(canceled||!filePath) return {ok:false,canceled:true}
    const data=await mainWindow.webContents.printToPDF({printBackground:true,preferCSSPageSize:true,pageSize:'A4'})
    await fs.writeFile(filePath,data)
    return {ok:true,filePath}
  })

  ipcMain.handle('desktop:save-text-file', async (_event, payload={})=>{
    const text=String(payload.text??'')
    if(Buffer.byteLength(text,'utf8')>50*1024*1024) throw new Error('Export exceeds 50 MB limit')
    const name=safeSuggestedName(payload.suggestedName||'export.txt')
    const filters=Array.isArray(payload.filters)?payload.filters:undefined
    const {canceled,filePath}=await dialog.showSaveDialog(mainWindow,{title:payload.title||'Save export',defaultPath:name,filters})
    if(canceled||!filePath) return {ok:false,canceled:true}
    await fs.writeFile(filePath,text,'utf8')
    return {ok:true,filePath,sha256:crypto.createHash('sha256').update(text).digest('hex')}
  })

  ipcMain.handle('desktop:read-import-file', async (_event, extensions=['csv','json'])=>{
    const safeExt=extensions.map(x=>String(x).replace(/[^a-z0-9]/gi,'').toLowerCase()).filter(Boolean).slice(0,8)
    const {canceled,filePaths}=await dialog.showOpenDialog(mainWindow,{title:'Select import file',properties:['openFile'],filters:[{name:'Supported imports',extensions:safeExt.length?safeExt:['csv','json']}]})
    if(canceled||!filePaths[0]) return {ok:false,canceled:true}
    const stat=await fs.stat(filePaths[0]); if(stat.size>50*1024*1024) throw new Error('Import exceeds 50 MB limit')
    const text=await fs.readFile(filePaths[0],'utf8')
    return {ok:true,filePath:filePaths[0],name:path.basename(filePaths[0]),text}
  })

  ipcMain.handle('desktop:open-external', async (_event,url)=>{ await openExternalSafely(url); return {ok:true} })
  ipcMain.handle('desktop:show-item', async (_event,filePath)=>{ if(filePath) shell.showItemInFolder(String(filePath)); return {ok:true} })
  ipcMain.handle('desktop:restart', ()=>{ app.relaunch(); app.exit(0) })
}

function setupSecurity(){
  session.defaultSession.setPermissionRequestHandler((_wc,_permission,callback)=>callback(false))
  session.defaultSession.setPermissionCheckHandler(()=>false)
}

async function configureUpdates(){
  const updateUrl=process.env.UMEED_UPDATE_URL
  if(!app.isPackaged || !updateUrl) return
  try {
    const { autoUpdater } = require('electron-updater')
    autoUpdater.autoDownload = false
    autoUpdater.autoInstallOnAppQuit = true
    autoUpdater.setFeedURL({provider:'generic',url:updateUrl})
    autoUpdater.on('update-available', info=>mainWindow?.webContents.send('desktop:update-available',{version:info.version}))
    autoUpdater.on('error', err=>mainWindow?.webContents.send('desktop:update-error',{message:err.message}))
    await autoUpdater.checkForUpdates()
    ipcMain.handle('desktop:download-update', async ()=>{ await autoUpdater.downloadUpdate(); return {ok:true} })
    ipcMain.handle('desktop:install-update', ()=>autoUpdater.quitAndInstall(false,true))
  } catch(err) {
    console.error('Updater disabled:',err?.message||err)
  }
}

const gotLock = app.requestSingleInstanceLock()
if(!gotLock){ app.quit() }
else {
  app.on('second-instance',()=>{
    if(mainWindow){ if(mainWindow.isMinimized()) mainWindow.restore(); mainWindow.show(); mainWindow.focus() }
  })
  app.whenReady().then(async()=>{
    registerIpc()
    await createWindow()
    setupSecurity()
    createMenu()
    await configureUpdates()
    app.on('activate',()=>{ if(BrowserWindow.getAllWindows().length===0) createWindow() })
  })
}
app.on('window-all-closed',()=>{ if(process.platform!=='darwin') app.quit() })
