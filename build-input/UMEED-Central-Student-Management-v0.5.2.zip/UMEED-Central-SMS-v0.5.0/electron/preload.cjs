'use strict'
const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('umeedDesktop', {
  getInfo: () => ipcRenderer.invoke('desktop:get-info'),
  print: (options) => ipcRenderer.invoke('desktop:print', options),
  savePdf: (suggestedName) => ipcRenderer.invoke('desktop:save-pdf', suggestedName),
  saveTextFile: (payload) => ipcRenderer.invoke('desktop:save-text-file', payload),
  readImportFile: (extensions) => ipcRenderer.invoke('desktop:read-import-file', extensions),
  openExternal: (url) => ipcRenderer.invoke('desktop:open-external', url),
  showItem: (filePath) => ipcRenderer.invoke('desktop:show-item', filePath),
  restart: () => ipcRenderer.invoke('desktop:restart'),
  downloadUpdate: () => ipcRenderer.invoke('desktop:download-update'),
  installUpdate: () => ipcRenderer.invoke('desktop:install-update'),
  onUpdateAvailable: (handler) => {
    const wrapped = (_event, payload) => handler(payload)
    ipcRenderer.on('desktop:update-available', wrapped)
    return () => ipcRenderer.removeListener('desktop:update-available', wrapped)
  },
  onUpdateError: (handler) => {
    const wrapped = (_event, payload) => handler(payload)
    ipcRenderer.on('desktop:update-error', wrapped)
    return () => ipcRenderer.removeListener('desktop:update-error', wrapped)
  },
})
