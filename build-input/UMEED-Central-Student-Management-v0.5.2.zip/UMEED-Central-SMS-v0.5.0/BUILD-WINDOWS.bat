@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js 22+ is required.& pause & exit /b 1)
call npm install || goto :fail
call npm run desktop:verify || goto :fail
call npm run typecheck || goto :fail
call npm run desktop:build || goto :fail
echo.
echo Build complete. Check the release folder.
pause
exit /b 0
:fail
echo.
echo Build failed. Review the error above.
pause
exit /b 1
