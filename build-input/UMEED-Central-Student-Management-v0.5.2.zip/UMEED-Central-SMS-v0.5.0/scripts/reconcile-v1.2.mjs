#!/usr/bin/env node
import fs from 'node:fs'
const legacyPath=process.argv[2], centralPath=process.argv[3]
if(!legacyPath||!centralPath){console.error('Usage: npm run reconcile:v1 -- legacy-normalized.json central-export.json');process.exit(2)}
const legacy=JSON.parse(fs.readFileSync(legacyPath,'utf8')); const central=JSON.parse(fs.readFileSync(centralPath,'utf8'))
const t=central.tables||{}
const sum=(rows,key,filter=()=>true)=>(rows||[]).filter(filter).reduce((a,r)=>a+Number(r[key]||0),0)
const centralStudents=(t.students||[]).length
const centralPayments=sum(t.payments,'amount_minor',r=>r.status==='posted')
const centralRefunds=sum(t.refunds,'amount_minor',r=>r.status==='posted')
const centralInvoices=sum(t.invoices,'total_minor',r=>r.status!=='void')-sum(t.invoices,'discount_minor',r=>r.status!=='void')
const report={
 students:{legacy:legacy.summary.students,central:centralStudents,match:legacy.summary.students===centralStudents},
 gross_receipts_minor:{legacy:legacy.summary.receipt_total_minor,central:centralPayments,difference:centralPayments-legacy.summary.receipt_total_minor},
 refunds_minor:{legacy:legacy.summary.refund_total_minor,central:centralRefunds,difference:centralRefunds-legacy.summary.refund_total_minor},
 billed_minor:{legacy:legacy.summary.charge_total_minor,central:centralInvoices,difference:centralInvoices-legacy.summary.charge_total_minor},
}
const ok=Object.values(report).every(v=>v.match===undefined ? v.difference===0 : v.match)
console.log(JSON.stringify({ok,report},null,2)); if(!ok)process.exitCode=1
