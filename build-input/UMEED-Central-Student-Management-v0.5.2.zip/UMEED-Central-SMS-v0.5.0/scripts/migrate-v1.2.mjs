#!/usr/bin/env node
import fs from 'node:fs'
import path from 'node:path'

const input = process.argv[2]
const output = process.argv[3] || 'umeed-v1-normalized.json'
if (!input) {
  console.error('Usage: npm run migrate:v1 -- <umeed-fees.sqlite|state.json> [output.json]')
  process.exit(2)
}

function looksLikeState(value) {
  return value && typeof value === 'object' && Array.isArray(value.students) && Array.isArray(value.charges) && Array.isArray(value.receipts)
}

async function readState(filename) {
  if (filename.toLowerCase().endsWith('.json')) {
    const parsed = JSON.parse(fs.readFileSync(filename, 'utf8'))
    if (looksLikeState(parsed)) return parsed
    for (const candidate of [parsed.state, parsed.payload, parsed.data]) if (looksLikeState(candidate)) return candidate
    throw new Error('JSON does not look like a UMEED Fees v1.x state export')
  }
  const { DatabaseSync } = await import('node:sqlite')
  const db = new DatabaseSync(filename, { readOnly: true })
  try {
    const tables = db.prepare("select name from sqlite_master where type='table' and name not like 'sqlite_%'").all().map(r => r.name)
    for (const table of tables) {
      const cols = db.prepare(`pragma table_info(${JSON.stringify(table)})`).all().map(r => r.name)
      const rows = db.prepare(`select * from ${JSON.stringify(table)} limit 50`).all()
      for (const row of rows) for (const col of cols) {
        if (typeof row[col] !== 'string') continue
        try {
          const parsed = JSON.parse(row[col])
          for (const candidate of [parsed, parsed?.state, parsed?.payload, parsed?.data]) if (looksLikeState(candidate)) return candidate
        } catch {}
      }
    }
    throw new Error(`Could not locate UMEED Fees state in SQLite tables: ${tables.join(', ')}`)
  } finally { db.close() }
}

const text=(v)=>String(v??'').trim()
const integerMinor=(value,label)=>{
  const n=Number(value??0)
  if(!Number.isSafeInteger(n)||n<0) throw new Error(`${label} must be a non-negative integer in legacy minor units; got ${value}`)
  return n
}
const rupeesToMinor=(value,label)=>{
  const n=Number(value??0)
  if(!Number.isFinite(n)||n<0) throw new Error(`${label} must be a non-negative rupee amount; got ${value}`)
  return Math.round(n*100)
}
const iso=(value)=>{
  if(!value) return null
  const raw=String(value)
  const d=/^\d{4}-\d{2}-\d{2}$/.test(raw)?new Date(`${raw}T12:00:00Z`):new Date(raw)
  return Number.isNaN(d.getTime())?null:d.toISOString()
}

const state=await readState(input)
if(Number(state.version??1)!==1) console.warn(`Warning: source state version is ${state.version}; parser targets UMEED Fees v1.x.`)

const students=(state.students||[]).filter(s=>!s.deletedAt).map((s,i)=>({
  legacy_id:text(s.id)||`legacy-student-${i+1}`,
  admission_no:text(s.roll)||`LEGACY-${i+1}`,
  roll_no:text(s.roll)||null,
  full_name:text(s.name)||'Unknown Student',
  guardian_name:text(s.father)||null,
  guardian_phone:text(s.phone)||null,
  guardian_email:text(s.email)||null,
  class_name:text(s.className)||null,
  section_name:text(s.section)||null,
  joined_on:text(s.admission)||null,
  billing_start:text(s.billingStart)||null,
  monthly_fee_minor:rupeesToMinor(s.monthlyFee??state.settings?.monthlyFee??0,`student ${s.id||i+1} monthlyFee`),
  annual_type:s.annualType==='new'?'new':'regular',
  status:s.active===false?'inactive':'active',
  metadata:{dob:s.dob||null,gender:s.gender||null,mother:s.mother||null,address:s.address||null,emergency_name:s.emergencyName||null,emergency_phone:s.emergencyPhone||null,notes:s.notes||null,legacy_excluded_months:s.excludedMonths||[]},
}))
const studentIds=new Set(students.map(s=>s.legacy_id))

const allocationsByCharge=new Map()
for(const receipt of state.receipts||[]){
  for(const line of receipt.lines||[]){
    const cur=allocationsByCharge.get(line.chargeId)||{paid:0,discount:0}
    cur.paid+=integerMinor(line.paid,`receipt ${receipt.number} line paid`)
    cur.discount+=integerMinor(line.discount,`receipt ${receipt.number} line discount`)
    allocationsByCharge.set(line.chargeId,cur)
  }
}
const refundsByCharge=new Map()
for(const refund of state.refunds||[]){
  const cur=refundsByCharge.get(refund.chargeId)||0
  refundsByCharge.set(refund.chargeId,cur+integerMinor(refund.amount,`refund ${refund.id} amount`))
}

const charges=(state.charges||[]).map((c,i)=>{
  const a=allocationsByCharge.get(c.id)||{paid:0,discount:0}; const refunded=refundsByCharge.get(c.id)||0
  return {
    legacy_id:text(c.id)||`legacy-charge-${i+1}`,
    legacy_key:text(c.key)||null,
    student_legacy_id:text(c.studentId),
    type:text(c.type)||'monthly', period:text(c.period)||'', label:text(c.label)||'Legacy charge',
    amount_minor:integerMinor(c.amount,`charge ${c.id||i+1} amount`),
    original_paid_minor:a.paid, discount_minor:a.discount, refunded_minor:refunded,
    net_paid_minor:Math.max(0,a.paid-refunded), created_at:iso(c.createdAt),
  }
})

const receipts=(state.receipts||[]).map((r,i)=>({
  legacy_id:text(r.id)||`legacy-payment-${i+1}`,
  request_id:text(r.requestId)||null,
  receipt_no:text(r.number)||`LEGACY-R-${i+1}`,
  student_legacy_id:text(r.studentId),
  amount_minor:integerMinor(r.cash??(r.lines||[]).reduce((a,l)=>a+Number(l.paid||0),0),`receipt ${r.number||i+1} cash`),
  discount_minor:integerMinor(r.discount??(r.lines||[]).reduce((a,l)=>a+Number(l.discount||0),0),`receipt ${r.number||i+1} discount`),
  payment_method:'cash', received_at:iso(r.date||r.createdAt), fee_month:text(r.month)||null, cashier:text(r.cashier)||null, notes:text(r.notes)||null,
  lines:(r.lines||[]).map(l=>({charge_legacy_id:text(l.chargeId),label:text(l.label),period:text(l.period),type:text(l.type),paid_minor:integerMinor(l.paid,`receipt ${r.number} line paid`),discount_minor:integerMinor(l.discount,`receipt ${r.number} line discount`)})),
}))

const refunds=(state.refunds||[]).map((r,i)=>({
  legacy_id:text(r.id)||`legacy-refund-${i+1}`,
  payment_legacy_id:text(r.receiptId), receipt_no:text(r.receiptNumber)||null, student_legacy_id:text(r.studentId), charge_legacy_id:text(r.chargeId),
  amount_minor:integerMinor(r.amount,`refund ${r.id||i+1} amount`), reason:text(r.reason)||'Legacy refund', created_at:iso(r.date), user:text(r.user)||null,
}))

const chargeIds=new Set(charges.map(c=>c.legacy_id)), receiptIds=new Set(receipts.map(r=>r.legacy_id))
const warnings=[]
for(const c of charges) if(!studentIds.has(c.student_legacy_id)) warnings.push(`Charge ${c.legacy_id} references missing student ${c.student_legacy_id}`)
for(const r of receipts){
  if(!studentIds.has(r.student_legacy_id)) warnings.push(`Receipt ${r.receipt_no} references missing student ${r.student_legacy_id}`)
  for(const l of r.lines) if(!chargeIds.has(l.charge_legacy_id)) warnings.push(`Receipt ${r.receipt_no} line references missing charge ${l.charge_legacy_id}`)
  const lines=r.lines.reduce((a,l)=>a+l.paid_minor,0); if(lines!==r.amount_minor) warnings.push(`Receipt ${r.receipt_no} cash ${r.amount_minor} != line payments ${lines}`)
}
for(const r of refunds){
  if(!receiptIds.has(r.payment_legacy_id)) warnings.push(`Refund ${r.legacy_id} references missing receipt ${r.payment_legacy_id}`)
  if(!chargeIds.has(r.charge_legacy_id)) warnings.push(`Refund ${r.legacy_id} references missing charge ${r.charge_legacy_id}`)
}
for(const c of charges) if(c.original_paid_minor+c.discount_minor>c.amount_minor) warnings.push(`Charge ${c.legacy_id} was overallocated before refunds`)

const settings={
  school:text(state.settings?.school), address:text(state.settings?.address), phone:text(state.settings?.phone), receipt_prefix:text(state.settings?.prefix)||'UES-',
  next_receipt:Number(state.settings?.nextReceipt||1), session_start:Number(state.settings?.sessionStart||4),
  monthly_fee_minor:rupeesToMinor(state.settings?.monthlyFee||0,'settings monthlyFee'),
  annual_regular_minor:rupeesToMinor(state.settings?.annualRegular||0,'settings annualRegular'), annual_new_minor:rupeesToMinor(state.settings?.annualNew||0,'settings annualNew'),
}
const summary={
  students:students.length, charges:charges.length, receipts:receipts.length, refunds:refunds.length,
  receipt_total_minor:receipts.reduce((a,r)=>a+r.amount_minor,0), refund_total_minor:refunds.reduce((a,r)=>a+r.amount_minor,0),
  charge_total_minor:charges.reduce((a,r)=>a+r.amount_minor,0), discount_total_minor:charges.reduce((a,r)=>a+r.discount_minor,0),
  net_paid_minor:charges.reduce((a,r)=>a+r.net_paid_minor,0), warnings:warnings.length,
}

const bundle={schema:'umeed-v1-normalized-v2',source:path.resolve(input),generated_at:new Date().toISOString(),legacy_version:state.version??1,summary,students,charges,receipts,refunds,settings,warnings:warnings.slice(0,500)}
fs.writeFileSync(output,JSON.stringify(bundle,null,2))
console.log(JSON.stringify({output:path.resolve(output),summary,warnings:bundle.warnings.slice(0,10)},null,2))
