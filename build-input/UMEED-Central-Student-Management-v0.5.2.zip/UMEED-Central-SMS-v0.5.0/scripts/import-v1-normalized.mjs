#!/usr/bin/env node
import fs from 'node:fs'
import crypto from 'node:crypto'

const file=process.argv[2]
const commit=process.argv.includes('--commit')
const url=(process.env.SUPABASE_URL||'').replace(/\/$/,'')
const key=process.env.SUPABASE_SECRET_KEY||''
const orgId=process.env.ORGANIZATION_ID||''
const actorId=process.env.IMPORT_ACTOR_USER_ID||''
if(!file){console.error('Usage: npm run import:v1 -- normalized.json [--commit]');process.exit(2)}
if(!url||!key||!orgId||!actorId){console.error('Required env: SUPABASE_URL, SUPABASE_SECRET_KEY, ORGANIZATION_ID, IMPORT_ACTOR_USER_ID');process.exit(2)}
const bundle=JSON.parse(fs.readFileSync(file,'utf8'))
if(!String(bundle.schema||'').startsWith('umeed-v1-normalized-v')) throw new Error('Unsupported normalized bundle')
if((bundle.warnings||[]).length) console.warn(`Bundle contains ${bundle.warnings.length} warnings. Review before commit.`)

const headers={'apikey':key,'Content-Type':'application/json'}
async function api(path,{method='GET',body,prefer}={}){
  const h={...headers}; if(prefer)h.Prefer=prefer
  const res=await fetch(`${url}/rest/v1/${path}`,{method,headers:h,body:body===undefined?undefined:JSON.stringify(body)})
  const text=await res.text(); let data=null; try{data=text?JSON.parse(text):null}catch{data=text}
  if(!res.ok) throw new Error(`${method} ${path}: ${res.status} ${typeof data==='string'?data:JSON.stringify(data)}`)
  return data
}
const quote=v=>encodeURIComponent(v)
function uuid(seed){
  const b=Buffer.from(crypto.createHash('sha256').update(`${orgId}:${seed}`).digest().subarray(0,16)); b[6]=(b[6]&0x0f)|0x50; b[8]=(b[8]&0x3f)|0x80
  const h=b.toString('hex'); return `${h.slice(0,8)}-${h.slice(8,12)}-${h.slice(12,16)}-${h.slice(16,20)}-${h.slice(20)}`
}
const dateOnly=v=>v?String(v).slice(0,10):new Date().toISOString().slice(0,10)
const monthDate=p=>/^\d{4}-\d{2}$/.test(p||'')?`${p}-01`:null
const invoiceStatus=(total,discount,paid)=>paid>=Math.max(0,total-discount)?'paid':paid>0?'partial':'open'
async function batchInsert(table,rows,size=250){
  for(let i=0;i<rows.length;i+=size) await api(table,{method:'POST',body:rows.slice(i,i+size),prefer:'resolution=merge-duplicates,return=minimal'})
}

const existing=await Promise.all([
  api(`students?organization_id=eq.${orgId}&select=id&limit=1`),api(`payments?organization_id=eq.${orgId}&select=id&limit=1`),api(`invoices?organization_id=eq.${orgId}&select=id&limit=1`),
])
if(existing.some(x=>Array.isArray(x)&&x.length)&&process.env.ALLOW_NONEMPTY!=='true') throw new Error('Target tenant is not empty. Refusing legacy import. Set ALLOW_NONEMPTY=true only after a reviewed reconciliation plan.')

const classes=await api(`classes?organization_id=eq.${orgId}&select=id,name`)
const sections=await api(`sections?organization_id=eq.${orgId}&select=id,name,class_id`)
const classMap=new Map(classes.map(c=>[String(c.name).toLowerCase(),c.id]))
const sectionMap=new Map(sections.map(s=>[`${s.class_id}:${String(s.name).toLowerCase()}`,s.id]))
const missingClasses=[...new Set(bundle.students.map(s=>s.class_name).filter(Boolean))].filter(n=>!classMap.has(String(n).toLowerCase()))
const classRows=missingClasses.map((name,i)=>({id:uuid(`class:${name}`),organization_id:orgId,name:String(name),sort_order:100+i,active:true}))
for(const r of classRows)classMap.set(r.name.toLowerCase(),r.id)
const sectionPairs=[]
for(const s of bundle.students){if(!s.class_name||!s.section_name)continue;const cid=classMap.get(String(s.class_name).toLowerCase());const k=`${cid}:${String(s.section_name).toLowerCase()}`;if(!sectionMap.has(k)){const row={id:uuid(`section:${s.class_name}:${s.section_name}`),organization_id:orgId,class_id:cid,name:String(s.section_name)};sectionMap.set(k,row.id);sectionPairs.push(row)}}

const studentRows=bundle.students.map(s=>({id:uuid(`student:${s.legacy_id}`),organization_id:orgId,admission_no:s.admission_no,roll_no:s.roll_no,full_name:s.full_name,guardian_name:s.guardian_name,guardian_phone:s.guardian_phone,guardian_email:s.guardian_email,class_id:s.class_name?classMap.get(String(s.class_name).toLowerCase()):null,section_id:s.class_name&&s.section_name?sectionMap.get(`${classMap.get(String(s.class_name).toLowerCase())}:${String(s.section_name).toLowerCase()}`):null,joined_on:s.joined_on||null,status:['active','inactive','graduated','left'].includes(s.status)?s.status:'active',metadata:{...(s.metadata||{}),legacy_id:s.legacy_id,legacy_billing_start:s.billing_start,legacy_monthly_fee_minor:s.monthly_fee_minor,legacy_annual_type:s.annual_type}}))
const studentMap=new Map(bundle.students.map((s,i)=>[s.legacy_id,studentRows[i].id]))

const invoiceRows=bundle.charges.map(c=>{
  const issue=monthDate(c.period)||dateOnly(c.created_at); const paid=Math.max(0,Number(c.net_paid_minor||0)); const total=Number(c.amount_minor||0); const discount=Number(c.discount_minor||0)
  return {id:uuid(`invoice:${c.legacy_id}`),organization_id:orgId,student_id:studentMap.get(c.student_legacy_id),academic_session_id:null,invoice_no:`LEG-${uuid(`inv-no:${c.legacy_id}`).slice(0,13).toUpperCase()}`,invoice_month:monthDate(c.period),issue_date:issue,due_date:issue,total_minor:total,discount_minor:discount,paid_minor:paid,status:invoiceStatus(total,discount,paid),notes:`Imported from UMEED Fees v1 · ${c.label||c.type}`,created_by:actorId,created_at:c.created_at||new Date().toISOString()}
})
const invoiceMap=new Map(bundle.charges.map((c,i)=>[c.legacy_id,invoiceRows[i].id]))
const itemRows=bundle.charges.map(c=>({id:uuid(`invoice-item:${c.legacy_id}`),organization_id:orgId,invoice_id:invoiceMap.get(c.legacy_id),fee_category_id:null,description:c.label||`Legacy ${c.type}`,quantity:1,unit_amount_minor:Number(c.amount_minor||0),total_amount_minor:Number(c.amount_minor||0)}))

const paymentRows=bundle.receipts.map(r=>({id:uuid(`payment:${r.legacy_id}`),organization_id:orgId,student_id:studentMap.get(r.student_legacy_id),receipt_no:r.receipt_no,received_at:r.received_at||new Date().toISOString(),amount_minor:Number(r.amount_minor),payment_method:['cash','bank','online','cheque','other'].includes(r.payment_method)?r.payment_method:'cash',reference:null,notes:r.notes||`Legacy cashier: ${r.cashier||'unknown'}`,status:'posted',idempotency_key:uuid(`idempotency:${r.legacy_id}`),created_by:actorId,created_at:r.received_at||new Date().toISOString()}))
const paymentMap=new Map(bundle.receipts.map((r,i)=>[r.legacy_id,paymentRows[i].id]))
const refundByPair=new Map()
for(const r of bundle.refunds){const k=`${r.payment_legacy_id}:${r.charge_legacy_id}`;refundByPair.set(k,(refundByPair.get(k)||0)+Number(r.amount_minor||0))}
const allocationRows=[]
for(const r of bundle.receipts){
  const grouped=new Map(); for(const l of r.lines||[]){const cur=grouped.get(l.charge_legacy_id)||0;grouped.set(l.charge_legacy_id,cur+Number(l.paid_minor||0))}
  for(const [chargeId,amount] of grouped){allocationRows.push({id:uuid(`allocation:${r.legacy_id}:${chargeId}`),organization_id:orgId,payment_id:paymentMap.get(r.legacy_id),invoice_id:invoiceMap.get(chargeId),amount_minor:amount,refunded_minor:Math.min(amount,refundByPair.get(`${r.legacy_id}:${chargeId}`)||0)})}
}
const refundRows=bundle.refunds.map(r=>({id:uuid(`refund:${r.legacy_id}`),organization_id:orgId,payment_id:paymentMap.get(r.payment_legacy_id),refund_no:`LEG-RF-${uuid(`refund-no:${r.legacy_id}`).slice(0,12).toUpperCase()}`,amount_minor:Number(r.amount_minor),reason:r.reason||'Legacy refund',status:'posted',created_by:actorId,approved_by:actorId,created_at:r.created_at||new Date().toISOString(),approved_at:r.created_at||new Date().toISOString()}))

const preview={commit,organizationId:orgId,classesToCreate:classRows.length,sectionsToCreate:sectionPairs.length,students:studentRows.length,invoices:invoiceRows.length,payments:paymentRows.length,allocations:allocationRows.length,refunds:refundRows.length,expected:bundle.summary}
console.log(JSON.stringify(preview,null,2))
if(!commit){console.log('Dry run only. Re-run with --commit after reviewing the counts and normalized bundle.');process.exit(0)}

await batchInsert('classes?on_conflict=id',classRows)
await batchInsert('sections?on_conflict=id',sectionPairs)
await batchInsert('students?on_conflict=id',studentRows)
await batchInsert('invoices?on_conflict=id',invoiceRows)
await batchInsert('invoice_items?on_conflict=id',itemRows)
await batchInsert('payments?on_conflict=id',paymentRows)
await batchInsert('payment_allocations?on_conflict=id',allocationRows)
await batchInsert('refunds?on_conflict=id',refundRows)
await api('audit_logs',{method:'POST',body:{organization_id:orgId,actor_id:actorId,action:'legacy.v1.imported',entity_type:'migration',entity_id:uuid(`migration:${bundle.generated_at}`),after_data:preview},prefer:'return=minimal'})
console.log(JSON.stringify({ok:true,...preview},null,2))
