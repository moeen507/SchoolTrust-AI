import fs from 'node:fs'
import path from 'node:path'
const required=['electron/main.cjs','electron/preload.cjs','build/icon.ico','src/desktop.d.ts','src/lib/desktop.ts','supabase/migrations/202609200001_initial_saas.sql']
const missing=required.filter(p=>!fs.existsSync(path.resolve(p)))
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'))
const issues=[]
if(missing.length) issues.push(`Missing: ${missing.join(', ')}`)
if(pkg.main!=='electron/main.cjs') issues.push('package.json main must be electron/main.cjs')
if(!pkg.scripts?.['desktop:build']) issues.push('desktop:build script missing')
if(pkg.dependencies?.['electron']||pkg.dependencies?.['electron-builder']) issues.push('Electron build tools must be devDependencies')
if(issues.length){console.error(issues.join('\n'));process.exit(1)}
console.log('Desktop package structure: PASS')
