import { spawnSync } from 'node:child_process'
const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm'
const npx = process.platform === 'win32' ? 'npx.cmd' : 'npx'
function run(cmd,args){ const r=spawnSync(cmd,args,{stdio:'inherit'}); if(r.status!==0) process.exit(r.status??1) }
run(npm,['run','build'])
run(npx,['electron-builder','--win','nsis','portable','--x64'])
