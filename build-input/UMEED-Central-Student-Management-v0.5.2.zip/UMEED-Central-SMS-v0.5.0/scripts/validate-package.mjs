#!/usr/bin/env node
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto'
const root=process.cwd();const failures=[];const required=['src/App.tsx','src/lib/repository.ts','supabase/migrations/202609200001_initial_saas.sql','supabase/migrations/202609200002_commercial_completion.sql','supabase/migrations/202609200003_automation.sql','supabase/functions/provision-student/index.ts','supabase/functions/dispatch-notifications/index.ts']
for(const f of required)if(!fs.existsSync(path.join(root,f)))failures.push(`Missing ${f}`)
const textFiles=[];function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){if(['node_modules','dist','.git'].includes(e.name))continue;const p=path.join(dir,e.name);if(e.isDirectory())walk(p);else if(/\.(ts|tsx|js|mjs|sql|md|json|toml|env|example)$/.test(e.name))textFiles.push(p)}}walk(root)
const secretPatterns=[/sb_secret_[A-Za-z0-9_-]{12,}/g,/service_role[^\n]{0,30}[=:][^\n]{8,}/gi,/SUPABASE_SECRET_KEY\s*=\s*[^\s#]+/g]
for(const file of textFiles){const content=fs.readFileSync(file,'utf8');for(const re of secretPatterns){const matches=content.match(re)||[];for(const m of matches){if(file.endsWith('.env.example')||m.includes('SUPABASE_SECRET_KEY'))continue;failures.push(`Potential secret in ${path.relative(root,file)}: ${m.slice(0,40)}`)}}}
const migrations=fs.readdirSync(path.join(root,'supabase/migrations')).filter(x=>x.endsWith('.sql')).sort();if(new Set(migrations).size!==migrations.length)failures.push('Duplicate migration file names')
const sha=crypto.createHash('sha256');for(const f of textFiles.sort())sha.update(path.relative(root,f)).update(fs.readFileSync(f))
console.log(JSON.stringify({ok:failures.length===0,files:textFiles.length,migrations,content_fingerprint:sha.digest('hex'),failures},null,2));if(failures.length)process.exitCode=1
