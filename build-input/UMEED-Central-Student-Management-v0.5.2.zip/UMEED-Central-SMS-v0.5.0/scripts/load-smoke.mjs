#!/usr/bin/env node
const url=process.env.SMOKE_URL
if(!url){console.error('Set SMOKE_URL to the deployed web app URL.');process.exit(2)}
const concurrency=Number(process.env.SMOKE_CONCURRENCY||10);const requests=Number(process.env.SMOKE_REQUESTS||100)
let next=0,failed=0;const timings=[]
async function worker(){while(next<requests){const i=next++;const start=performance.now();try{const r=await fetch(url,{redirect:'follow'});if(!r.ok)failed++;await r.arrayBuffer()}catch{failed++}timings.push(performance.now()-start)}}
await Promise.all(Array.from({length:concurrency},worker));timings.sort((a,b)=>a-b)
const pct=p=>Math.round(timings[Math.min(timings.length-1,Math.floor(timings.length*p))]||0)
console.log(JSON.stringify({url,requests,concurrency,failed,p50_ms:pct(.5),p95_ms:pct(.95),max_ms:Math.round(timings.at(-1)||0)},null,2));if(failed)process.exitCode=1
