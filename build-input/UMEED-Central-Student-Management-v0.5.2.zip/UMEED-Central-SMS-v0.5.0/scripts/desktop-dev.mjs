import { spawn } from 'node:child_process'
import net from 'node:net'

const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm'
const electron = process.platform === 'win32' ? 'node_modules\\.bin\\electron.cmd' : 'node_modules/.bin/electron'
const vite = spawn(npm,['run','dev'],{stdio:'inherit',env:{...process.env,VITE_DEV_SERVER_URL:'http://127.0.0.1:5173'}})

function waitPort(port,host='127.0.0.1',deadline=Date.now()+30000){
  return new Promise((resolve,reject)=>{
    const tryOnce=()=>{
      const s=net.connect(port,host,()=>{s.end();resolve()})
      s.on('error',()=>{s.destroy(); if(Date.now()>deadline) reject(new Error('Vite did not start')); else setTimeout(tryOnce,250)})
    }; tryOnce()
  })
}

try {
  await waitPort(5173)
  const desktop=spawn(electron,['.'],{stdio:'inherit',env:{...process.env,VITE_DEV_SERVER_URL:'http://127.0.0.1:5173'}})
  desktop.on('exit',code=>{vite.kill('SIGTERM');process.exit(code??0)})
} catch(err){ vite.kill('SIGTERM'); console.error(err); process.exit(1) }
