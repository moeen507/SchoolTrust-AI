# Third-party software

This project currently references open-source packages including React, React DOM, React Router, Vite, Supabase JS and Lucide React. Review and preserve their respective license notices before commercial redistribution. The application code in this repository can remain proprietary to the product owner.
