@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js 22+ is required. Install Node.js and run this file again.& pause & exit /b 1)
call npm install || goto :fail
call npm run desktop:verify || goto :fail
call npm run desktop:dev
goto :eof
:fail
echo.
echo Setup failed. Review the error above.
pause
exit /b 1
