# UMEED Central Student Management System v0.5.0

This release combines the centralized multi-tenant Student Management SaaS architecture with the premium UMEED Electron desktop workspace direction originally used in the April/May fee-ledger project.

## What changed in v0.5

The backend architecture from v0.4 remains centralized and tenant-aware, but the desktop workspace is no longer a generic SaaS dashboard. The administrative/counter interface now follows the original UMEED desktop visual language:

- Deep black/charcoal workspace
- UMEED maroon + champagne-gold accents
- Compact professional desktop density
- Permanent desktop sidebar with grouped navigation
- ERP-style top workspace bar
- Large Student Registry tables
- Class filter pills
- Dedicated Student Ledger workspace
- Clickable student ledger cards
- Slide-out student account detail panel
- Compact finance KPIs and transaction tables
- Professional report tabs and report filters
- Original-style receipt/financial emphasis
- Responsive fallback for tablets/mobile administration

The design change does not restore the old local-only data architecture. Supabase/Postgres remains the centralized source of truth.

## Product scope

### Student Management
- Student master record
- Admission number and roll number
- Guardian information
- Class and section placement
- Academic session history and promotion
- CSV import/export
- Role-based access
- Dedicated Student Ledger workspace

### Academic Management
- Subjects
- Attendance
- Exams and exam subjects
- Marks entry
- Draft -> Published -> Locked result workflow
- Grading scale
- Student/guardian result and attendance portal

### School Fee Management
- Monthly fee and annual fund billing
- Fee structures and invoices
- Server-generated receipt sequence
- Payment allocation to oldest dues
- Student advance credit
- Refund/reversal workflow
- Defaulter workflow
- Cashier close/reconciliation
- Financial reporting

### Student Store
Independent student-service sales for books, fee cards, envelopes, stationery, uniforms and other school items.

Example slip series: `STU-2026-000001`

### Canteen
Independent student-linked canteen counter ledger and inventory.

Example slip series: `CAN-2026-000001`

### School Fee Receipts
School fee receipts remain financially independent from Student Store and Canteen.

Example receipt series: `FEE-2026-000001`

All three streams share the same student identity, but Store/Canteen sales never change school-fee outstanding balances.

## Central Student Ledger

The new desktop Ledger page is the unified student account workspace. It shows:

- Student identity and placement
- Monthly fee
- Outstanding school-fee balance
- Advance credit
- Annual fund status/value
- Payment/invoice/refund transaction history
- Student Store spending/slips
- Canteen spending/slips

This is intentionally a consolidated view, not a combined accounting ledger. Fee, Store and Canteen remain separate financial streams.

## Reports workspace

Reports now use an ERP-style desktop layout with:

- Fee Receipt report
- Current Defaulters report
- Student Store report
- Canteen report
- Student / admission / roll / receipt / slip search
- Date From / To filters
- Fee payment-method filter
- Current visible total
- CSV export of the currently selected report
- Printable transaction drill-downs

## Desktop and Mobile

### Windows Desktop
Electron remains the main back-office/counter shell with:
- Native print/PDF support
- Safe import/export dialogs
- NSIS installer configuration
- Portable EXE configuration
- Secure preload/IPC separation

### Mobile / PWA
The same backend serves the mobile/PWA experience. Students/guardians can view:
- Results/performance
- Attendance
- Fee balance and ledger
- Student Store slips
- Canteen slips

The mobile app does not maintain a second financial database.

## Development

```bash
cp .env.example .env
npm install
npm run dev
```

Without Supabase environment variables the application opens in Preview Mode.

## Windows Build

On Windows 10/11 with Node.js 22+:

```bat
BUILD-WINDOWS.bat
```

or:

```bash
npm install
npm run desktop:verify
npm run typecheck
npm run desktop:build
```

Expected release artifacts are written to `release/`.

## Supabase Setup

Apply the SQL migrations in `supabase/migrations/` in filename order. The browser/mobile/desktop renderer uses only a Supabase publishable key. Secret keys remain server-side.

## Validation status

Static source/package checks are included in `QA-REPORT.md`. A real production release still requires a networked dependency install, a full Vite/Electron production build, execution of the migrations against the real Supabase project, RLS/security advisor verification, printer tests, and reconciliation against production UMEED data.

## Installable desktop and Android builds

Version 0.5.1 adds runtime backend configuration plus Capacitor Android packaging. The installed EXE/APK can start in Demo Mode and later be connected from **Settings > Backend connection** using only the Supabase project URL, publishable key, and organization slug. Never enter a secret/service-role key in a client app.

Android build: `npm install && npm run mobile:add`, then build the Android project with Gradle/Android Studio. Desktop build: `npm install && npm run desktop:build`.
