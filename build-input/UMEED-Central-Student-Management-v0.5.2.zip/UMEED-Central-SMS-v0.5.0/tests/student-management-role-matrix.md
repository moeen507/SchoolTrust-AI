# Student Management Role Matrix

| Role | Student directory | Fee entry | Fee reports | Academic entry | Store entry | Canteen entry | Student self portal |
|---|---:|---:|---:|---:|---:|---:|---:|
| Owner / Super Admin | Yes | Yes | Yes | Yes | Yes | Yes | No |
| Admin | Yes | No by default | Yes | Yes | Yes | Yes | No |
| Accountant | Finance scope | Yes | Yes | No | Yes | Yes | No |
| Fee Cashier | Counter lookup | Yes | Limited | No | No | No | No |
| Academic Manager | Academic lookup | No | No | Yes | No | No | No |
| Teacher | Academic lookup | No | No | Attendance + marks | No | No | No |
| Student Store Clerk | Counter lookup only | No | No | No | Yes | No | No |
| Canteen Cashier | Counter lookup only | No | No | No | No | Yes | No |
| Auditor | Read only | No | Yes | Read | Read | Read | No |
| Student | Own record only | No | Own ledger | Own published data | Own slips | Own slips | Yes |
| Guardian | Linked children only | No | Linked ledgers | Linked published data | Linked slips | Linked slips | Yes |

The counter-search RPC returns only the minimum student directory fields required for daily operations. Store/canteen roles are not granted broad fee-ledger access.
