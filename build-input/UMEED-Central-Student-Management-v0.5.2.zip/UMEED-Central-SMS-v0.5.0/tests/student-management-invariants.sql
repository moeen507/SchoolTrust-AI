-- Run after migrations and a representative test dataset.
-- These queries should all return zero rows when invariants hold.

-- 1. Fee receipts must never collide with store/canteen slips.
select p.receipt_no from public.payments p join public.student_sales s on s.organization_id=p.organization_id and s.slip_no=p.receipt_no;

-- 2. Store and canteen sequence streams must remain independently unique.
select organization_id,slip_no,count(*) from public.student_sales group by organization_id,slip_no having count(*)>1;

-- 3. Posted sale total must equal subtotal less discount.
select id,subtotal_minor,discount_minor,total_minor from public.student_sales where total_minor<>subtotal_minor-discount_minor;

-- 4. Sale-item totals must reconcile to sale subtotal.
select s.id,s.subtotal_minor,coalesce(sum(i.total_minor),0) line_total
from public.student_sales s left join public.student_sale_items i on i.sale_id=s.id
group by s.id having s.subtotal_minor<>coalesce(sum(i.total_minor),0);

-- 5. No tracked inventory may be negative.
select id,sku,stock_quantity from public.catalog_items where track_stock and stock_quantity<0;

-- 6. Marks may never exceed the configured maximum.
select sm.id,sm.marks_obtained,es.max_marks from public.student_marks sm join public.exam_subjects es on es.id=sm.exam_subject_id where sm.marks_obtained>es.max_marks;

-- 7. One attendance record per student per date.
select student_id,attendance_date,count(*) from public.student_attendance group by student_id,attendance_date having count(*)>1;

-- 8. Student marks must be unique per exam subject.
select exam_subject_id,student_id,count(*) from public.student_marks group by exam_subject_id,student_id having count(*)>1;
