-- Run after seed/test fixtures in a non-production Supabase branch.
-- These queries should all return zero rows.
select 'invoice paid exceeds payable' issue,id from public.invoices where paid_minor > total_minor-discount_minor and status<>'void';
select 'allocation refund exceeds allocation' issue,id from public.payment_allocations where refunded_minor>amount_minor;
select 'credit refund exceeds credit amount' issue,id from public.student_credits where refunded_minor>amount_minor;
select 'credit allocation reversal exceeds allocation' issue,id from public.credit_allocations where reversed_minor>amount_minor;
select 'negative credit remaining' issue,id from public.student_credits where remaining_minor<0;
select 'posted refund exceeds payment' issue,r.payment_id
from (select payment_id,sum(amount_minor) amount from public.refunds where status='posted' group by payment_id) r
join public.payments p on p.id=r.payment_id where r.amount>p.amount_minor;
select 'duplicate active monthly invoice' issue,organization_id,student_id,invoice_month,count(*)
from public.invoices where invoice_month is not null and status<>'void' group by 2,3,4 having count(*)>1;
