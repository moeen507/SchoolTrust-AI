# RLS verification matrix

Run this matrix on a Supabase branch with separate Auth users. A UI permission check is not a substitute for these database assertions.

| Actor | Student master | Other student's ledger | Collect payment | Refund request | Refund approve | Settings | Tenant console |
|---|---|---|---|---|---|---|---|
| Student | own only | deny | deny | deny | deny | deny | deny |
| Guardian | linked children only | deny | deny | deny | deny | deny | deny |
| Cashier | tenant read | tenant read | allow | allow | deny | deny | deny |
| Accountant | tenant read | tenant read | allow | allow | allow, different requester | finance config | deny |
| Admin | tenant read/write master | tenant read | deny by default | deny | deny | deny | deny |
| Super admin | tenant | tenant | allow | allow | allow | allow | deny |
| Auditor | tenant read | tenant read | deny | deny | deny | deny | deny |
| Platform support | only during active support session, read-only | same | deny | deny | deny | deny | tenant list |
| Platform owner | no tenant ledger without support session | deny | deny | deny | deny | platform | allow |

Also verify that synthetic student login identifiers do not permit enumeration of other students through views or RPC parameters.
