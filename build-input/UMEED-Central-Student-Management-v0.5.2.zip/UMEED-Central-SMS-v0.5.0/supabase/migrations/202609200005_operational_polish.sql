-- Operational polish: atomic student creation and audited tenant configuration.

create or replace function public.create_student(
  p_admission_no text,
  p_full_name text,
  p_roll_no text default null,
  p_guardian_name text default null,
  p_guardian_phone text default null,
  p_guardian_email text default null,
  p_class_id uuid default null,
  p_section_id uuid default null,
  p_joined_on date default current_date
) returns jsonb
language plpgsql
security definer
set search_path=public,private
as $$
declare
  v_org uuid;
  v_student uuid;
  v_session uuid;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select m.organization_id into v_org
  from public.organization_memberships m
  where m.user_id=auth.uid() and m.active and m.role in ('owner','super_admin','admin')
  order by m.created_at limit 1;
  if v_org is null then raise exception 'Not authorized'; end if;
  if nullif(trim(p_admission_no),'') is null or nullif(trim(p_full_name),'') is null then
    raise exception 'Admission number and student name are required';
  end if;
  if p_class_id is not null and not exists(select 1 from public.classes c where c.id=p_class_id and c.organization_id=v_org and c.active) then
    raise exception 'Invalid class';
  end if;
  if p_section_id is not null and not exists(select 1 from public.sections s where s.id=p_section_id and s.organization_id=v_org and (p_class_id is null or s.class_id=p_class_id)) then
    raise exception 'Invalid section';
  end if;

  insert into public.students(organization_id,admission_no,roll_no,full_name,guardian_name,guardian_phone,guardian_email,class_id,section_id,joined_on,status)
  values(v_org,trim(p_admission_no),nullif(trim(p_roll_no),''),trim(p_full_name),nullif(trim(p_guardian_name),''),nullif(trim(p_guardian_phone),''),nullif(trim(p_guardian_email),''),p_class_id,p_section_id,coalesce(p_joined_on,current_date),'active')
  returning id into v_student;

  select id into v_session from public.academic_sessions where organization_id=v_org and active order by starts_on desc limit 1;
  if v_session is not null then
    insert into public.student_enrollments(organization_id,student_id,academic_session_id,class_id,section_id,roll_no,started_on,status,created_by)
    values(v_org,v_student,v_session,p_class_id,p_section_id,nullif(trim(p_roll_no),''),coalesce(p_joined_on,current_date),'active',auth.uid())
    on conflict(student_id,academic_session_id) do nothing;
  end if;

  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,after_data)
  values(v_org,auth.uid(),'student.created','student',v_student::text,jsonb_build_object('admission_no',trim(p_admission_no),'full_name',trim(p_full_name),'class_id',p_class_id,'section_id',p_section_id));

  return jsonb_build_object('student_id',v_student,'organization_id',v_org);
end;
$$;
revoke all on function public.create_student(text,text,text,text,text,text,uuid,uuid,date) from public;
grant execute on function public.create_student(text,text,text,text,text,text,uuid,uuid,date) to authenticated;

create or replace function public.update_organization_configuration(
  p_name text,
  p_currency text,
  p_timezone text,
  p_receipt_prefix text,
  p_branding jsonb default '{}'::jsonb,
  p_settings jsonb default '{}'::jsonb
) returns jsonb
language plpgsql
security definer
set search_path=public,private
as $$
declare
  v_org uuid;
  v_before jsonb;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select m.organization_id into v_org
  from public.organization_memberships m
  where m.user_id=auth.uid() and m.active and m.role in ('owner','super_admin')
  order by m.created_at limit 1;
  if v_org is null then raise exception 'Not authorized'; end if;
  if nullif(trim(p_name),'') is null then raise exception 'Organization name is required'; end if;
  if p_currency !~ '^[A-Z]{3}$' then raise exception 'Currency must be a 3-letter ISO code'; end if;
  if nullif(trim(p_receipt_prefix),'') is null or length(trim(p_receipt_prefix)) > 16 then raise exception 'Invalid receipt prefix'; end if;
  if not exists(select 1 from pg_timezone_names where name=p_timezone) then raise exception 'Unknown timezone'; end if;

  select to_jsonb(o) into v_before from public.organizations o where o.id=v_org for update;
  update public.organizations
  set name=trim(p_name), currency=upper(trim(p_currency)), timezone=p_timezone,
      receipt_prefix=upper(trim(p_receipt_prefix)), branding=coalesce(p_branding,'{}'::jsonb), settings=coalesce(p_settings,'{}'::jsonb)
  where id=v_org;

  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,before_data,after_data)
  select v_org,auth.uid(),'organization.configuration.updated','organization',v_org::text,v_before,to_jsonb(o)
  from public.organizations o where o.id=v_org;

  return jsonb_build_object('organization_id',v_org,'updated',true);
end;
$$;
revoke all on function public.update_organization_configuration(text,text,text,text,jsonb,jsonb) from public;
grant execute on function public.update_organization_configuration(text,text,text,text,jsonb,jsonb) to authenticated;
