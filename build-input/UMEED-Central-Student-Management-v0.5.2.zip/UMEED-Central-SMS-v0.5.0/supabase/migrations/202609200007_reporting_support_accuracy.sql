-- Timezone-correct reporting, academic-session collection periods and audited support access.

create or replace function private.current_org_local_date()
returns date language sql stable security definer set search_path=public,private as $$
  select timezone(coalesce(nullif(o.timezone,''),'UTC'),now())::date
  from public.organizations o where o.id=private.current_org();
$$;
revoke all on function private.current_org_local_date() from public;
grant execute on function private.current_org_local_date() to authenticated;

create or replace function private.user_can_access_student(p_student uuid)
returns boolean language sql stable security definer set search_path=public,private as $$
  select exists(
    select 1 from public.students s where s.id=p_student and (
      s.auth_user_id=(select auth.uid())
      or exists(select 1 from public.student_guardians g where g.student_id=s.id and g.auth_user_id=(select auth.uid()))
      or private.user_has_org_access(s.organization_id,array['owner','super_admin','admin','cashier','accountant','auditor'])
      or (
        private.is_platform_admin(array['platform_owner','platform_support'])
        and exists(select 1 from public.support_sessions ss where ss.organization_id=s.organization_id and ss.support_user_id=(select auth.uid()) and ss.ended_at is null and ss.expires_at>now())
      )
    )
  );
$$;
revoke all on function private.user_can_access_student(uuid) from public;
grant execute on function private.user_can_access_student(uuid) to authenticated;

create or replace view public.v_my_support_session with (security_invoker=true) as
select ss.id,ss.organization_id,o.name organization_name,o.slug organization_slug,ss.reason,ss.expires_at,ss.created_at
from public.support_sessions ss join public.organizations o on o.id=ss.organization_id
where ss.support_user_id=(select auth.uid()) and ss.ended_at is null and ss.expires_at>now()
order by ss.created_at desc limit 1;
grant select on public.v_my_support_session to authenticated;

create or replace function public.start_support_session(p_organization_id uuid,p_reason text,p_minutes int default 30)
returns jsonb language plpgsql security definer set search_path=public,private as $$
declare sid uuid; exp timestamptz;
begin
  if not private.is_platform_admin(array['platform_owner','platform_support']) then raise exception 'Not authorized'; end if;
  if not exists(select 1 from public.organizations where id=p_organization_id) then raise exception 'Organization not found'; end if;
  if length(trim(coalesce(p_reason,'')))<8 then raise exception 'A support reason of at least 8 characters is required'; end if;
  p_minutes:=greatest(5,least(coalesce(p_minutes,30),60));
  update public.support_sessions set ended_at=now() where support_user_id=(select auth.uid()) and ended_at is null;
  exp:=now()+make_interval(mins=>p_minutes);
  insert into public.support_sessions(organization_id,support_user_id,reason,expires_at)
  values(p_organization_id,(select auth.uid()),trim(p_reason),exp) returning id into sid;
  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,after_data)
  values(p_organization_id,(select auth.uid()),'platform.support.started','support_session',sid::text,jsonb_build_object('reason',trim(p_reason),'expires_at',exp));
  return jsonb_build_object('session_id',sid,'expires_at',exp);
end $$;
revoke all on function public.start_support_session(uuid,text,int) from public,anon;
grant execute on function public.start_support_session(uuid,text,int) to authenticated;

create or replace function public.end_support_session()
returns jsonb language plpgsql security definer set search_path=public,private as $$
declare s record;
begin
  select * into s from public.support_sessions where support_user_id=(select auth.uid()) and ended_at is null order by created_at desc limit 1 for update;
  if s.id is null then return jsonb_build_object('ended',false); end if;
  update public.support_sessions set ended_at=now() where id=s.id;
  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,after_data)
  values(s.organization_id,(select auth.uid()),'platform.support.ended','support_session',s.id::text,jsonb_build_object('ended_at',now()));
  return jsonb_build_object('ended',true,'session_id',s.id);
end $$;
revoke all on function public.end_support_session() from public,anon;
grant execute on function public.end_support_session() to authenticated;

create or replace view public.v_collection_last_7_days with (security_invoker=true) as
with cfg as (
  select o.id organization_id,o.timezone,private.current_org_local_date() local_date from public.organizations o where o.id=private.current_org()
), d as (
  select x::date business_date from cfg cross join lateral generate_series(cfg.local_date-6,cfg.local_date,'1 day') x
), p as (
  select timezone(cfg.timezone,p.received_at)::date business_date,sum(p.amount_minor)::bigint amount
  from public.payments p join cfg on cfg.organization_id=p.organization_id where p.status='posted' group by 1
), r as (
  select timezone(cfg.timezone,r.created_at)::date business_date,sum(r.amount_minor)::bigint amount
  from public.refunds r join cfg on cfg.organization_id=r.organization_id where r.status='posted' group by 1
)
select to_char(d.business_date,'Dy') label,(coalesce(p.amount,0)-coalesce(r.amount,0))::bigint amount
from d left join p using(business_date) left join r using(business_date) order by d.business_date;

grant select on public.v_collection_last_7_days to authenticated;

create or replace view public.v_current_month_defaulters with (security_invoker=true) as
with cfg as (select private.current_org() org,private.current_org_local_date() local_date)
select s.id student_id,s.admission_no,s.roll_no,s.full_name,s.guardian_name,s.guardian_phone,
       c.name class_name,se.name section_name,
       sum(greatest(i.total_minor-i.discount_minor-i.paid_minor,0))::bigint current_month_due_minor,
       (select coalesce(sum(greatest(ix.total_minor-ix.discount_minor-ix.paid_minor,0)),0) from public.invoices ix where ix.student_id=s.id and ix.status in ('open','partial'))::bigint outstanding_minor,
       (select coalesce(sum(sc.remaining_minor),0) from public.student_credits sc where sc.student_id=s.id)::bigint credit_minor
from public.students s join cfg on cfg.org=s.organization_id
join public.invoices i on i.student_id=s.id and i.organization_id=s.organization_id
left join public.classes c on c.id=s.class_id left join public.sections se on se.id=s.section_id
where s.status='active' and i.invoice_month=date_trunc('month',cfg.local_date)::date and i.status in ('open','partial') and i.due_date<cfg.local_date
group by s.id,s.admission_no,s.roll_no,s.full_name,s.guardian_name,s.guardian_phone,c.name,se.name;
grant select on public.v_current_month_defaulters to authenticated;

create or replace function public.dashboard_metrics()
returns jsonb language plpgsql security invoker set search_path=public,private as $$
declare
  org uuid:=private.current_org(); tz text; local_date date; week_start date; month_start date; ay_start date; ay_end date;
  students bigint; defaulters bigint; paid bigint; partial bigint; today_gross bigint; today_refund bigint; week_gross bigint; week_refund bigint;
  month_gross bigint; month_refund bigint; ay_gross bigint; ay_refund bigint; all_gross bigint; all_refund bigint; outstanding bigint;
begin
  if org is null then raise exception 'Organization not found'; end if;
  select coalesce(nullif(timezone,''),'UTC') into tz from public.organizations where id=org;
  local_date:=timezone(tz,now())::date; week_start:=date_trunc('week',local_date::timestamp)::date; month_start:=date_trunc('month',local_date)::date;
  select starts_on,ends_on into ay_start,ay_end from public.academic_sessions where organization_id=org and active order by starts_on desc limit 1;
  if ay_start is null then ay_start:=make_date(extract(year from local_date)::int,1,1); ay_end:=make_date(extract(year from local_date)::int,12,31); end if;

  select count(*) into students from public.students where organization_id=org and status='active';
  select count(distinct student_id) into defaulters from public.invoices where organization_id=org and status in ('open','partial') and due_date<local_date and invoice_month=month_start;
  select count(distinct student_id) filter(where status='paid'),count(distinct student_id) filter(where status='partial') into paid,partial from public.invoices where organization_id=org and invoice_month=month_start;

  select coalesce(sum(amount_minor) filter(where timezone(tz,received_at)::date=local_date),0),
         coalesce(sum(amount_minor) filter(where timezone(tz,received_at)::date>=week_start),0),
         coalesce(sum(amount_minor) filter(where timezone(tz,received_at)::date>=month_start),0),
         coalesce(sum(amount_minor) filter(where timezone(tz,received_at)::date between ay_start and ay_end),0),
         coalesce(sum(amount_minor),0)
  into today_gross,week_gross,month_gross,ay_gross,all_gross
  from public.payments where organization_id=org and status='posted';

  select coalesce(sum(amount_minor) filter(where timezone(tz,created_at)::date=local_date),0),
         coalesce(sum(amount_minor) filter(where timezone(tz,created_at)::date>=week_start),0),
         coalesce(sum(amount_minor) filter(where timezone(tz,created_at)::date>=month_start),0),
         coalesce(sum(amount_minor) filter(where timezone(tz,created_at)::date between ay_start and ay_end),0),
         coalesce(sum(amount_minor),0)
  into today_refund,week_refund,month_refund,ay_refund,all_refund
  from public.refunds where organization_id=org and status='posted';

  select coalesce(sum(greatest(total_minor-discount_minor-paid_minor,0)),0) into outstanding from public.invoices where organization_id=org and status in ('open','partial');
  return jsonb_build_object(
    'today',today_gross-today_refund,'week',week_gross-week_refund,'month',month_gross-month_refund,
    'academicYear',ay_gross-ay_refund,'allTime',all_gross-all_refund,'gross',month_gross,'refunds',month_refund,'net',month_gross-month_refund,
    'outstanding',outstanding,'students',students,'defaulters',defaulters,'paidThisMonth',coalesce(paid,0),'partialThisMonth',coalesce(partial,0),
    'academicYearStart',ay_start,'academicYearEnd',ay_end,'businessDate',local_date
  );
end $$;
revoke all on function public.dashboard_metrics() from public,anon;
grant execute on function public.dashboard_metrics() to authenticated;
