-- Student Management expansion: academics, attendance, performance, student store and canteen.
-- Keeps fee accounting, student-store sales and canteen sales as separate ledgers/number sequences.

-- -----------------------------------------------------------------------------
-- Roles
-- -----------------------------------------------------------------------------
alter table public.organization_memberships drop constraint if exists organization_memberships_role_check;
alter table public.organization_memberships add constraint organization_memberships_role_check
  check (role in (
    'owner','super_admin','admin','cashier','accountant','student','guardian','auditor',
    'academic_manager','teacher','store_clerk','canteen_cashier'
  ));

-- -----------------------------------------------------------------------------
-- Academic master data
-- -----------------------------------------------------------------------------
create table if not exists public.subjects (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  code text not null,
  name text not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (organization_id,code),
  unique (organization_id,name)
);

create table if not exists public.class_subjects (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  academic_session_id uuid not null references public.academic_sessions(id) on delete cascade,
  class_id uuid not null references public.classes(id) on delete cascade,
  section_id uuid references public.sections(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  teacher_id uuid references auth.users(id) on delete set null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create unique index if not exists class_subject_unique on public.class_subjects(
  organization_id,academic_session_id,class_id,coalesce(section_id,'00000000-0000-0000-0000-000000000000'::uuid),subject_id
);

create table if not exists public.student_attendance (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  attendance_date date not null,
  status text not null check (status in ('present','absent','late','leave','holiday')),
  remarks text,
  marked_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(student_id,attendance_date)
);
create index if not exists student_attendance_org_date_idx on public.student_attendance(organization_id,attendance_date desc,status);
create index if not exists student_attendance_student_idx on public.student_attendance(student_id,attendance_date desc);

create table if not exists public.exams (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  academic_session_id uuid not null references public.academic_sessions(id) on delete cascade,
  name text not null,
  term text,
  starts_on date,
  ends_on date,
  status text not null default 'draft' check (status in ('draft','published','locked')),
  published_at timestamptz,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  unique(organization_id,academic_session_id,name)
);

create table if not exists public.exam_subjects (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  exam_id uuid not null references public.exams(id) on delete cascade,
  class_id uuid not null references public.classes(id) on delete cascade,
  section_id uuid references public.sections(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  max_marks numeric(10,2) not null check(max_marks > 0),
  pass_marks numeric(10,2) not null check(pass_marks >= 0 and pass_marks <= max_marks),
  weight numeric(7,3) not null default 1 check(weight > 0),
  created_at timestamptz not null default now()
);
create unique index if not exists exam_subject_unique on public.exam_subjects(
  exam_id,class_id,coalesce(section_id,'00000000-0000-0000-0000-000000000000'::uuid),subject_id
);

create table if not exists public.student_marks (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  exam_subject_id uuid not null references public.exam_subjects(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  marks_obtained numeric(10,2) not null check(marks_obtained >= 0),
  remarks text,
  entered_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(exam_subject_id,student_id)
);
create index if not exists student_marks_student_idx on public.student_marks(student_id,updated_at desc);

create table if not exists public.grading_scales (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  min_percentage numeric(5,2) not null check(min_percentage between 0 and 100),
  max_percentage numeric(5,2) not null check(max_percentage between 0 and 100 and max_percentage >= min_percentage),
  grade text not null,
  remark text,
  sort_order int not null default 0,
  unique(organization_id,grade)
);

-- -----------------------------------------------------------------------------
-- Student store + canteen, intentionally independent from fee invoices/payments.
-- -----------------------------------------------------------------------------
create table if not exists public.sale_sequences (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  channel text not null check(channel in ('student_store','canteen')),
  fiscal_year int not null,
  last_number bigint not null default 0,
  primary key(organization_id,channel,fiscal_year)
);

create table if not exists public.catalog_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  sku text not null,
  name text not null,
  category text,
  sale_channel text not null check(sale_channel in ('student_store','canteen','both')),
  unit_price_minor bigint not null check(unit_price_minor >= 0),
  track_stock boolean not null default true,
  stock_quantity numeric(12,3) not null default 0 check(stock_quantity >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(organization_id,sku)
);
create index if not exists catalog_items_org_channel_idx on public.catalog_items(organization_id,sale_channel,active,name);

create table if not exists public.student_sales (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  student_id uuid not null references public.students(id) on delete restrict,
  channel text not null check(channel in ('student_store','canteen')),
  slip_no text not null,
  sold_at timestamptz not null default now(),
  subtotal_minor bigint not null check(subtotal_minor >= 0),
  discount_minor bigint not null default 0 check(discount_minor >= 0 and discount_minor <= subtotal_minor),
  total_minor bigint generated always as (subtotal_minor-discount_minor) stored,
  payment_method text not null check(payment_method in ('cash','bank','online','card','other')),
  reference text,
  notes text,
  status text not null default 'posted' check(status in ('posted','voided')),
  idempotency_key uuid not null,
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  unique(organization_id,slip_no),
  unique(organization_id,idempotency_key)
);
create index if not exists student_sales_org_date_idx on public.student_sales(organization_id,sold_at desc,channel,status);
create index if not exists student_sales_student_idx on public.student_sales(student_id,sold_at desc);

create table if not exists public.student_sale_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  sale_id uuid not null references public.student_sales(id) on delete cascade,
  catalog_item_id uuid not null references public.catalog_items(id) on delete restrict,
  item_name_snapshot text not null,
  sku_snapshot text not null,
  quantity numeric(12,3) not null check(quantity > 0),
  unit_price_minor bigint not null check(unit_price_minor >= 0),
  total_minor bigint not null check(total_minor >= 0)
);
create index if not exists student_sale_items_sale_idx on public.student_sale_items(sale_id);

create table if not exists public.stock_movements (
  id bigserial primary key,
  organization_id uuid not null references public.organizations(id) on delete cascade,
  catalog_item_id uuid not null references public.catalog_items(id) on delete restrict,
  movement_type text not null check(movement_type in ('opening','purchase','sale','sale_void','adjustment')),
  quantity_delta numeric(12,3) not null,
  reference_type text,
  reference_id text,
  note text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists stock_movements_item_idx on public.stock_movements(catalog_item_id,created_at desc);

-- -----------------------------------------------------------------------------
-- RLS
-- -----------------------------------------------------------------------------
alter table public.subjects enable row level security;
alter table public.class_subjects enable row level security;
alter table public.student_attendance enable row level security;
alter table public.exams enable row level security;
alter table public.exam_subjects enable row level security;
alter table public.student_marks enable row level security;
alter table public.grading_scales enable row level security;
alter table public.sale_sequences enable row level security;
alter table public.catalog_items enable row level security;
alter table public.student_sales enable row level security;
alter table public.student_sale_items enable row level security;
alter table public.stock_movements enable row level security;

create policy subjects_read on public.subjects for select to authenticated
  using(private.user_has_org_access(organization_id));
create policy subjects_write on public.subjects for all to authenticated
  using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','academic_manager']))
  with check(private.user_has_org_access(organization_id,array['owner','super_admin','admin','academic_manager']));

create policy class_subjects_read on public.class_subjects for select to authenticated
  using(private.user_has_org_access(organization_id));
create policy class_subjects_write on public.class_subjects for all to authenticated
  using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','academic_manager']))
  with check(private.user_has_org_access(organization_id,array['owner','super_admin','admin','academic_manager']));

create policy attendance_read on public.student_attendance for select to authenticated
  using(private.user_can_access_student(student_id) or private.user_has_org_access(organization_id,array['academic_manager','teacher']));
create policy attendance_write on public.student_attendance for all to authenticated
  using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','academic_manager','teacher']))
  with check(private.user_has_org_access(organization_id,array['owner','super_admin','admin','academic_manager','teacher']));

create policy exams_read on public.exams for select to authenticated
  using(private.user_has_org_access(organization_id));
create policy exams_write on public.exams for all to authenticated
  using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','academic_manager']))
  with check(private.user_has_org_access(organization_id,array['owner','super_admin','admin','academic_manager']));

create policy exam_subjects_read on public.exam_subjects for select to authenticated
  using(private.user_has_org_access(organization_id));
create policy exam_subjects_write on public.exam_subjects for all to authenticated
  using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','academic_manager']))
  with check(private.user_has_org_access(organization_id,array['owner','super_admin','admin','academic_manager']));

create policy marks_read on public.student_marks for select to authenticated
  using(private.user_can_access_student(student_id) or private.user_has_org_access(organization_id,array['academic_manager','teacher']));
create policy marks_write on public.student_marks for all to authenticated
  using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','academic_manager','teacher']))
  with check(private.user_has_org_access(organization_id,array['owner','super_admin','admin','academic_manager','teacher']));

create policy grading_read on public.grading_scales for select to authenticated
  using(private.user_has_org_access(organization_id));
create policy grading_write on public.grading_scales for all to authenticated
  using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','academic_manager']))
  with check(private.user_has_org_access(organization_id,array['owner','super_admin','admin','academic_manager']));

create policy catalog_read on public.catalog_items for select to authenticated
  using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant','store_clerk','canteen_cashier','auditor']));
create policy catalog_write on public.catalog_items for all to authenticated
  using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant']))
  with check(private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant']));

create policy sales_read on public.student_sales for select to authenticated
  using(
    private.user_can_access_student(student_id)
    or private.user_has_org_access(organization_id,array['store_clerk','canteen_cashier'])
  );
create policy sale_items_read on public.student_sale_items for select to authenticated
  using(exists(
    select 1 from public.student_sales x
    where x.id=sale_id and (
      private.user_can_access_student(x.student_id)
      or private.user_has_org_access(x.organization_id,array['store_clerk','canteen_cashier'])
    )
  ));
create policy stock_read on public.stock_movements for select to authenticated
  using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant','store_clerk','canteen_cashier','auditor']));

-- Direct writes to sales/sequence/movements are intentionally not granted via RLS policies.
-- Posting is through validated RPC functions below.

-- -----------------------------------------------------------------------------
-- Helpers and atomic posting
-- -----------------------------------------------------------------------------
create or replace function private.next_sale_slip(p_org uuid,p_channel text)
returns text
language plpgsql
security definer
set search_path=public,private
as $$
declare
  v_year int := extract(year from current_date)::int;
  v_no bigint;
  v_prefix text;
begin
  if p_channel not in ('student_store','canteen') then raise exception 'Invalid sales channel'; end if;
  insert into public.sale_sequences(organization_id,channel,fiscal_year,last_number)
  values(p_org,p_channel,v_year,1)
  on conflict(organization_id,channel,fiscal_year)
  do update set last_number=public.sale_sequences.last_number+1
  returning last_number into v_no;

  select case
    when p_channel='student_store' then coalesce(nullif(settings->>'store_slip_prefix',''),'STU')
    else coalesce(nullif(settings->>'canteen_slip_prefix',''),'CAN')
  end into v_prefix from public.organizations where id=p_org;

  return upper(v_prefix)||'-'||v_year::text||'-'||lpad(v_no::text,6,'0');
end;
$$;
revoke all on function private.next_sale_slip(uuid,text) from public;

create or replace function public.search_students_for_counter(p_query text default '',p_limit int default 30)
returns table(student_id uuid,admission_no text,roll_no text,full_name text,class_name text,section_name text)
language plpgsql
security definer
set search_path=public,private
as $$
declare v_org uuid;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select m.organization_id into v_org from public.organization_memberships m
  where m.user_id=auth.uid() and m.active and m.role in (
    'owner','super_admin','admin','cashier','accountant','academic_manager','teacher','store_clerk','canteen_cashier'
  ) order by m.created_at limit 1;
  if v_org is null then raise exception 'Not authorized'; end if;
  return query
  select s.id,s.admission_no,s.roll_no,s.full_name,c.name,se.name
  from public.students s
  left join public.classes c on c.id=s.class_id
  left join public.sections se on se.id=s.section_id
  where s.organization_id=v_org and s.status='active'
    and (coalesce(trim(p_query),'')='' or concat_ws(' ',s.full_name,s.admission_no,s.roll_no,c.name,se.name) ilike '%'||trim(p_query)||'%')
  order by s.full_name limit least(greatest(coalesce(p_limit,30),1),100);
end;
$$;
revoke all on function public.search_students_for_counter(text,int) from public;
grant execute on function public.search_students_for_counter(text,int) to authenticated;

create or replace function public.record_student_sale(
  p_student_id uuid,
  p_channel text,
  p_items jsonb,
  p_payment_method text,
  p_notes text default null,
  p_reference text default null,
  p_discount_minor bigint default 0,
  p_idempotency_key uuid default gen_random_uuid()
) returns jsonb
language plpgsql
security definer
set search_path=public,private
as $$
declare
  v_org uuid;
  v_role text;
  v_sale uuid;
  v_slip text;
  v_subtotal bigint := 0;
  v_item jsonb;
  v_catalog public.catalog_items%rowtype;
  v_qty numeric(12,3);
  v_line bigint;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_channel not in ('student_store','canteen') then raise exception 'Invalid sales channel'; end if;
  if p_payment_method not in ('cash','bank','online','card','other') then raise exception 'Invalid payment method'; end if;
  if jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 then raise exception 'At least one item is required'; end if;

  select organization_id,role into v_org,v_role
  from public.organization_memberships
  where user_id=auth.uid() and active
  order by created_at limit 1;
  if v_org is null then raise exception 'Not authorized'; end if;
  if p_channel='student_store' and v_role not in ('owner','super_admin','admin','accountant','store_clerk') then raise exception 'Not authorized for student store'; end if;
  if p_channel='canteen' and v_role not in ('owner','super_admin','admin','accountant','canteen_cashier') then raise exception 'Not authorized for canteen'; end if;
  if not exists(select 1 from public.students where id=p_student_id and organization_id=v_org and status='active') then raise exception 'Invalid student'; end if;

  if exists(select 1 from public.student_sales where organization_id=v_org and idempotency_key=p_idempotency_key) then
    return (select jsonb_build_object('sale_id',id,'slip_no',slip_no,'total_minor',total_minor,'channel',channel,'idempotent_replay',true) from public.student_sales where organization_id=v_org and idempotency_key=p_idempotency_key);
  end if;

  -- Lock and validate inventory before creating any financial record.
  for v_item in select * from jsonb_array_elements(p_items) loop
    v_qty := nullif(v_item->>'quantity','')::numeric;
    if v_qty is null or v_qty<=0 then raise exception 'Invalid item quantity'; end if;
    select * into v_catalog from public.catalog_items
    where id=(v_item->>'item_id')::uuid and organization_id=v_org and active
      and (sale_channel=p_channel or sale_channel='both')
    for update;
    if not found then raise exception 'Catalog item is unavailable'; end if;
    if v_catalog.track_stock and v_catalog.stock_quantity<v_qty then raise exception 'Insufficient stock for %',v_catalog.name; end if;
    v_line := round(v_catalog.unit_price_minor*v_qty)::bigint;
    v_subtotal := v_subtotal+v_line;
  end loop;
  if p_discount_minor<0 or p_discount_minor>v_subtotal then raise exception 'Invalid discount'; end if;

  v_slip := private.next_sale_slip(v_org,p_channel);
  insert into public.student_sales(organization_id,student_id,channel,slip_no,subtotal_minor,discount_minor,payment_method,reference,notes,idempotency_key,created_by)
  values(v_org,p_student_id,p_channel,v_slip,v_subtotal,p_discount_minor,p_payment_method,nullif(trim(p_reference),''),nullif(trim(p_notes),''),p_idempotency_key,auth.uid())
  returning id into v_sale;

  for v_item in select * from jsonb_array_elements(p_items) loop
    v_qty := (v_item->>'quantity')::numeric;
    select * into v_catalog from public.catalog_items where id=(v_item->>'item_id')::uuid and organization_id=v_org for update;
    v_line := round(v_catalog.unit_price_minor*v_qty)::bigint;
    insert into public.student_sale_items(organization_id,sale_id,catalog_item_id,item_name_snapshot,sku_snapshot,quantity,unit_price_minor,total_minor)
    values(v_org,v_sale,v_catalog.id,v_catalog.name,v_catalog.sku,v_qty,v_catalog.unit_price_minor,v_line);
    if v_catalog.track_stock then
      update public.catalog_items set stock_quantity=stock_quantity-v_qty,updated_at=now() where id=v_catalog.id;
      insert into public.stock_movements(organization_id,catalog_item_id,movement_type,quantity_delta,reference_type,reference_id,note,created_by)
      values(v_org,v_catalog.id,'sale',-v_qty,'student_sale',v_sale::text,v_slip,auth.uid());
    end if;
  end loop;

  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,after_data)
  values(v_org,auth.uid(),'student_sale.posted','student_sale',v_sale::text,jsonb_build_object('slip_no',v_slip,'channel',p_channel,'student_id',p_student_id,'subtotal_minor',v_subtotal,'discount_minor',p_discount_minor,'total_minor',v_subtotal-p_discount_minor));

  return jsonb_build_object('sale_id',v_sale,'slip_no',v_slip,'subtotal_minor',v_subtotal,'discount_minor',p_discount_minor,'total_minor',v_subtotal-p_discount_minor,'channel',p_channel);
end;
$$;
revoke all on function public.record_student_sale(uuid,text,jsonb,text,text,text,bigint,uuid) from public;
grant execute on function public.record_student_sale(uuid,text,jsonb,text,text,text,bigint,uuid) to authenticated;

create or replace function public.adjust_catalog_stock(p_item_id uuid,p_quantity_delta numeric,p_note text)
returns jsonb
language plpgsql
security definer
set search_path=public,private
as $$
declare v_org uuid; v_after numeric;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select organization_id into v_org from public.organization_memberships
  where user_id=auth.uid() and active and role in ('owner','super_admin','admin','accountant') order by created_at limit 1;
  if v_org is null then raise exception 'Not authorized'; end if;
  if p_quantity_delta=0 then raise exception 'Quantity change cannot be zero'; end if;
  update public.catalog_items set stock_quantity=stock_quantity+p_quantity_delta,updated_at=now()
  where id=p_item_id and organization_id=v_org and stock_quantity+p_quantity_delta>=0 returning stock_quantity into v_after;
  if v_after is null then raise exception 'Item not found or stock would become negative'; end if;
  insert into public.stock_movements(organization_id,catalog_item_id,movement_type,quantity_delta,note,created_by)
  values(v_org,p_item_id,'adjustment',p_quantity_delta,nullif(trim(p_note),''),auth.uid());
  return jsonb_build_object('item_id',p_item_id,'stock_quantity',v_after);
end;
$$;
revoke all on function public.adjust_catalog_stock(uuid,numeric,text) from public;
grant execute on function public.adjust_catalog_stock(uuid,numeric,text) to authenticated;

-- -----------------------------------------------------------------------------
-- Academic posting RPCs
-- -----------------------------------------------------------------------------
create or replace function public.upsert_student_attendance(p_student_id uuid,p_date date,p_status text,p_remarks text default null)
returns jsonb
language plpgsql
security definer
set search_path=public,private
as $$
declare v_org uuid; v_id uuid;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_status not in ('present','absent','late','leave','holiday') then raise exception 'Invalid attendance status'; end if;
  select organization_id into v_org from public.organization_memberships
  where user_id=auth.uid() and active and role in ('owner','super_admin','admin','academic_manager','teacher') order by created_at limit 1;
  if v_org is null then raise exception 'Not authorized'; end if;
  if not exists(select 1 from public.students where id=p_student_id and organization_id=v_org and status='active') then raise exception 'Invalid student'; end if;
  insert into public.student_attendance(organization_id,student_id,attendance_date,status,remarks,marked_by)
  values(v_org,p_student_id,p_date,p_status,nullif(trim(p_remarks),''),auth.uid())
  on conflict(student_id,attendance_date) do update set status=excluded.status,remarks=excluded.remarks,marked_by=auth.uid(),updated_at=now()
  returning id into v_id;
  return jsonb_build_object('attendance_id',v_id,'student_id',p_student_id,'date',p_date,'status',p_status);
end;
$$;
revoke all on function public.upsert_student_attendance(uuid,date,text,text) from public;
grant execute on function public.upsert_student_attendance(uuid,date,text,text) to authenticated;

create or replace function public.create_exam(p_name text,p_term text,p_starts_on date,p_ends_on date)
returns jsonb
language plpgsql
security definer
set search_path=public,private
as $$
declare v_org uuid; v_session uuid; v_id uuid;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select organization_id into v_org from public.organization_memberships
  where user_id=auth.uid() and active and role in ('owner','super_admin','admin','academic_manager') order by created_at limit 1;
  if v_org is null then raise exception 'Not authorized'; end if;
  select id into v_session from public.academic_sessions where organization_id=v_org and active order by starts_on desc limit 1;
  if v_session is null then raise exception 'No active academic session'; end if;
  insert into public.exams(organization_id,academic_session_id,name,term,starts_on,ends_on,created_by)
  values(v_org,v_session,trim(p_name),nullif(trim(p_term),''),p_starts_on,p_ends_on,auth.uid()) returning id into v_id;
  return jsonb_build_object('exam_id',v_id,'session_id',v_session);
end;
$$;
revoke all on function public.create_exam(text,text,date,date) from public;
grant execute on function public.create_exam(text,text,date,date) to authenticated;

create or replace function public.upsert_exam_subject(p_exam_id uuid,p_class_id uuid,p_section_id uuid,p_subject_id uuid,p_max_marks numeric,p_pass_marks numeric)
returns jsonb
language plpgsql
security definer
set search_path=public,private
as $$
declare v_org uuid; v_id uuid;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select organization_id into v_org from public.organization_memberships
  where user_id=auth.uid() and active and role in ('owner','super_admin','admin','academic_manager') order by created_at limit 1;
  if v_org is null then raise exception 'Not authorized'; end if;
  if p_max_marks<=0 or p_pass_marks<0 or p_pass_marks>p_max_marks then raise exception 'Invalid marks range'; end if;
  if not exists(select 1 from public.exams where id=p_exam_id and organization_id=v_org) then raise exception 'Invalid exam'; end if;
  if not exists(select 1 from public.classes where id=p_class_id and organization_id=v_org) then raise exception 'Invalid class'; end if;
  if not exists(select 1 from public.subjects where id=p_subject_id and organization_id=v_org and active) then raise exception 'Invalid subject'; end if;
  select id into v_id from public.exam_subjects where exam_id=p_exam_id and class_id=p_class_id and subject_id=p_subject_id and section_id is not distinct from p_section_id for update;
  if v_id is null then
    insert into public.exam_subjects(organization_id,exam_id,class_id,section_id,subject_id,max_marks,pass_marks)
    values(v_org,p_exam_id,p_class_id,p_section_id,p_subject_id,p_max_marks,p_pass_marks) returning id into v_id;
  else
    update public.exam_subjects set max_marks=p_max_marks,pass_marks=p_pass_marks where id=v_id;
  end if;
  return jsonb_build_object('exam_subject_id',v_id);
end;
$$;
revoke all on function public.upsert_exam_subject(uuid,uuid,uuid,uuid,numeric,numeric) from public;
grant execute on function public.upsert_exam_subject(uuid,uuid,uuid,uuid,numeric,numeric) to authenticated;

create or replace function public.upsert_student_mark(p_exam_subject_id uuid,p_student_id uuid,p_marks numeric,p_remarks text default null)
returns jsonb
language plpgsql
security definer
set search_path=public,private
as $$
declare v_org uuid; v_max numeric; v_class uuid; v_section uuid; v_id uuid;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select organization_id into v_org from public.organization_memberships
  where user_id=auth.uid() and active and role in ('owner','super_admin','admin','academic_manager','teacher') order by created_at limit 1;
  if v_org is null then raise exception 'Not authorized'; end if;
  select max_marks,class_id,section_id into v_max,v_class,v_section from public.exam_subjects where id=p_exam_subject_id and organization_id=v_org;
  if v_max is null then raise exception 'Invalid exam subject'; end if;
  if p_marks<0 or p_marks>v_max then raise exception 'Marks must be between 0 and %',v_max; end if;
  if not exists(select 1 from public.students s where s.id=p_student_id and s.organization_id=v_org and s.status='active' and s.class_id=v_class and (v_section is null or s.section_id=v_section)) then raise exception 'Student is not enrolled in this class/section'; end if;
  insert into public.student_marks(organization_id,exam_subject_id,student_id,marks_obtained,remarks,entered_by)
  values(v_org,p_exam_subject_id,p_student_id,p_marks,nullif(trim(p_remarks),''),auth.uid())
  on conflict(exam_subject_id,student_id) do update set marks_obtained=excluded.marks_obtained,remarks=excluded.remarks,entered_by=auth.uid(),updated_at=now()
  returning id into v_id;
  return jsonb_build_object('mark_id',v_id,'student_id',p_student_id,'marks',p_marks,'max_marks',v_max);
end;
$$;
revoke all on function public.upsert_student_mark(uuid,uuid,numeric,text) from public;
grant execute on function public.upsert_student_mark(uuid,uuid,numeric,text) to authenticated;

-- -----------------------------------------------------------------------------
-- Student-safe / staff-safe views
-- -----------------------------------------------------------------------------
create or replace view public.v_student_attendance_summary with (security_invoker=true) as
select a.organization_id,a.student_id,
       count(*) filter(where a.status in ('present','absent','late','leave'))::int recorded_days,
       count(*) filter(where a.status='present')::int present_days,
       count(*) filter(where a.status='absent')::int absent_days,
       count(*) filter(where a.status='late')::int late_days,
       count(*) filter(where a.status='leave')::int leave_days,
       case when count(*) filter(where a.status in ('present','absent','late','leave'))=0 then 0
            else round(100.0*(count(*) filter(where a.status in ('present','late'))) / nullif(count(*) filter(where a.status in ('present','absent','late','leave')),0),2) end attendance_percentage
from public.student_attendance a
group by a.organization_id,a.student_id;

create or replace view public.v_student_performance with (security_invoker=true) as
select sm.organization_id,sm.student_id,e.id exam_id,e.name exam_name,e.term,e.status exam_status,
       sub.id subject_id,sub.name subject_name,es.max_marks,es.pass_marks,sm.marks_obtained,
       round((sm.marks_obtained/nullif(es.max_marks,0))*100,2) percentage,
       (sm.marks_obtained>=es.pass_marks) passed,sm.remarks,sm.updated_at
from public.student_marks sm
join public.exam_subjects es on es.id=sm.exam_subject_id
join public.exams e on e.id=es.exam_id
join public.subjects sub on sub.id=es.subject_id;

create or replace view public.v_student_performance_summary with (security_invoker=true) as
select organization_id,student_id,
       count(*)::int assessed_subjects,
       round(avg(percentage),2) average_percentage,
       count(*) filter(where passed)::int passed_subjects,
       count(*) filter(where not passed)::int failed_subjects,
       max(updated_at) last_result_at
from public.v_student_performance
where exam_status in ('published','locked')
group by organization_id,student_id;

create or replace view public.v_sales_slips with (security_invoker=true) as
select x.id sale_id,x.organization_id,x.student_id,x.channel,x.slip_no,x.sold_at,x.subtotal_minor,x.discount_minor,x.total_minor,x.payment_method,x.reference,x.notes,x.status,
       s.admission_no,s.roll_no,s.full_name,c.name class_name,se.name section_name,o.name organization_name,
       coalesce(jsonb_agg(jsonb_build_object('name',si.item_name_snapshot,'sku',si.sku_snapshot,'quantity',si.quantity,'unit_price_minor',si.unit_price_minor,'total_minor',si.total_minor) order by si.id) filter(where si.id is not null),'[]'::jsonb) items
from public.student_sales x
join public.students s on s.id=x.student_id
join public.organizations o on o.id=x.organization_id
left join public.classes c on c.id=s.class_id
left join public.sections se on se.id=s.section_id
left join public.student_sale_items si on si.sale_id=x.id
group by x.id,x.organization_id,x.student_id,x.channel,x.slip_no,x.sold_at,x.subtotal_minor,x.discount_minor,x.total_minor,x.payment_method,x.reference,x.notes,x.status,s.admission_no,s.roll_no,s.full_name,c.name,se.name,o.name;

create or replace view public.v_student_activity_timeline with (security_invoker=true) as
select p.organization_id,p.student_id,p.received_at occurred_at,'fee_payment'::text activity_type,p.receipt_no reference,p.amount_minor amount_minor,'Fee payment' label
from public.payments p where p.status='posted'
union all
select x.organization_id,x.student_id,x.sold_at,'student_sale',x.slip_no,x.total_minor,
       case when x.channel='canteen' then 'Canteen purchase' else 'Student store purchase' end
from public.student_sales x where x.status='posted';

-- -----------------------------------------------------------------------------
-- Grants for Data API. RLS still controls rows.
-- -----------------------------------------------------------------------------
grant select on public.subjects,public.class_subjects,public.student_attendance,public.exams,public.exam_subjects,public.student_marks,public.grading_scales,public.catalog_items,public.student_sales,public.student_sale_items,public.stock_movements to authenticated;
grant select on public.v_student_attendance_summary,public.v_student_performance,public.v_student_performance_summary,public.v_sales_slips,public.v_student_activity_timeline to authenticated;
grant insert,update on public.subjects,public.class_subjects,public.student_attendance,public.exams,public.exam_subjects,public.student_marks,public.grading_scales,public.catalog_items to authenticated;

-- Updated-at triggers reuse private.touch_updated_at() from the commercial migration.
drop trigger if exists student_attendance_updated_at on public.student_attendance;
create trigger student_attendance_updated_at before update on public.student_attendance for each row execute function private.touch_updated_at();
drop trigger if exists student_marks_updated_at on public.student_marks;
create trigger student_marks_updated_at before update on public.student_marks for each row execute function private.touch_updated_at();
drop trigger if exists catalog_items_updated_at on public.catalog_items;
create trigger catalog_items_updated_at before update on public.catalog_items for each row execute function private.touch_updated_at();

-- Starter grade scale and feature flags are tenant-configurable; no global hard-coded grade policy is imposed.
