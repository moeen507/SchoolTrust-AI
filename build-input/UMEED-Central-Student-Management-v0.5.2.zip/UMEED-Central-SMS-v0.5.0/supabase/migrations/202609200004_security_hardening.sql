-- Security and commercial entitlement hardening.

create or replace function private.current_org()
returns uuid language sql stable security definer set search_path=public,private as $$
  select coalesce(
    (select m.organization_id from public.organization_memberships m where m.user_id=(select auth.uid()) and m.active order by m.created_at limit 1),
    (select s.organization_id from public.support_sessions s where s.support_user_id=(select auth.uid()) and s.ended_at is null and s.expires_at>now() order by s.created_at desc limit 1)
  );
$$;
revoke all on function private.current_org() from public;
grant execute on function private.current_org() to authenticated;

-- Student/guardian in-app notifications are readable by the linked account even when user_id is null.
create policy notification_student_read on public.notifications for select to authenticated
using(student_id is not null and private.user_can_access_student(student_id));
create policy notification_student_update on public.notifications for update to authenticated
using(student_id is not null and private.user_can_access_student(student_id))
with check(student_id is not null and private.user_can_access_student(student_id));

-- Scope staff-facing views to one current organization so multi-membership accounts do not get accidental aggregates.
create or replace view public.v_student_account_summary with (security_invoker=true) as
select s.id,s.organization_id,s.admission_no,s.login_id,s.roll_no,s.full_name,s.guardian_name,s.guardian_phone,s.status,
       c.name class_name,se.name section_name,
       coalesce((select fs.amount_minor from public.fee_structures fs join public.fee_categories fc on fc.id=fs.fee_category_id join public.academic_sessions a on a.id=fs.academic_session_id where fs.organization_id=s.organization_id and fs.active and a.active and (fs.class_id=s.class_id or fs.class_id is null) and fc.code='MONTHLY' order by fs.class_id nulls last limit 1),0)::bigint monthly_fee_minor,
       coalesce((select fs.amount_minor from public.fee_structures fs join public.fee_categories fc on fc.id=fs.fee_category_id join public.academic_sessions a on a.id=fs.academic_session_id where fs.organization_id=s.organization_id and fs.active and a.active and (fs.class_id=s.class_id or fs.class_id is null) and fc.code='ANNUAL_FUND' order by fs.class_id nulls last limit 1),0)::bigint annual_fund_minor,
       coalesce((select sum(i.total_minor-i.discount_minor-i.paid_minor) from public.invoices i where i.student_id=s.id and i.status in ('open','partial')),0)::bigint outstanding_minor,
       coalesce((select sum(sc.remaining_minor) from public.student_credits sc where sc.student_id=s.id),0)::bigint credit_minor
from public.students s
left join public.classes c on c.id=s.class_id
left join public.sections se on se.id=s.section_id
where s.organization_id=private.current_org();

create or replace view public.v_collection_last_7_days with (security_invoker=true) as
with d as (select x::date business_date from generate_series(current_date-6,current_date,'1 day') x),
p as (select received_at::date business_date,sum(amount_minor)::bigint amount from public.payments where organization_id=private.current_org() and status='posted' group by 1),
r as (select created_at::date business_date,sum(amount_minor)::bigint amount from public.refunds where organization_id=private.current_org() and status='posted' group by 1)
select to_char(d.business_date,'Dy') label,(coalesce(p.amount,0)-coalesce(r.amount,0))::bigint amount
from d left join p using(business_date) left join r using(business_date) order by d.business_date;

create or replace view public.v_current_month_defaulters with (security_invoker=true) as
select s.id student_id,s.admission_no,s.roll_no,s.full_name,s.guardian_name,s.guardian_phone,
       c.name class_name,se.name section_name,
       sum(greatest(i.total_minor-i.discount_minor-i.paid_minor,0))::bigint current_month_due_minor,
       (select coalesce(sum(greatest(ix.total_minor-ix.discount_minor-ix.paid_minor,0)),0) from public.invoices ix where ix.student_id=s.id and ix.status in ('open','partial'))::bigint outstanding_minor,
       (select coalesce(sum(sc.remaining_minor),0) from public.student_credits sc where sc.student_id=s.id)::bigint credit_minor
from public.students s
join public.invoices i on i.student_id=s.id and i.organization_id=s.organization_id
left join public.classes c on c.id=s.class_id
left join public.sections se on se.id=s.section_id
where s.organization_id=private.current_org() and s.status='active' and i.invoice_month=date_trunc('month',current_date)::date and i.status in ('open','partial') and i.due_date<current_date
group by s.id,s.admission_no,s.roll_no,s.full_name,s.guardian_name,s.guardian_phone,c.name,se.name;

create or replace view public.v_receipts with (security_invoker=true) as
select p.id payment_id,p.organization_id,p.student_id,p.receipt_no,p.received_at,p.amount_minor,p.payment_method,p.reference,p.notes,p.status,
       s.admission_no,s.roll_no,s.full_name,s.guardian_name,c.name class_name,se.name section_name,
       o.name organization_name,o.receipt_prefix,o.branding,
       coalesce((select sum(r.amount_minor) from public.refunds r where r.payment_id=p.id and r.status='posted'),0)::bigint refunded_minor,
       coalesce((select sum(pa.amount_minor-pa.refunded_minor) from public.payment_allocations pa where pa.payment_id=p.id),0)::bigint allocated_minor,
       coalesce((select sum(sc.amount_minor-sc.refunded_minor) from public.student_credits sc where sc.source_payment_id=p.id),0)::bigint credit_created_minor
from public.payments p join public.students s on s.id=p.student_id join public.organizations o on o.id=p.organization_id
left join public.classes c on c.id=s.class_id left join public.sections se on se.id=s.section_id
where p.organization_id=private.current_org();

create or replace view public.v_student_ledger with (security_invoker=true) as
select i.organization_id,i.student_id,i.issue_date::timestamptz occurred_at,'invoice'::text entry_type,i.id::text reference,
       i.invoice_no label,(i.total_minor-i.discount_minor)::bigint debit_minor,0::bigint credit_minor,i.status status
from public.invoices i where i.organization_id=private.current_org()
union all
select p.organization_id,p.student_id,p.received_at,'payment',p.id::text,p.receipt_no,0::bigint,p.amount_minor,p.status
from public.payments p where p.organization_id=private.current_org()
union all
select r.organization_id,p.student_id,r.created_at,'refund',r.id::text,r.refund_no,r.amount_minor,0::bigint,r.status
from public.refunds r join public.payments p on p.id=r.payment_id where r.organization_id=private.current_org();

-- Plan quotas are database-enforced, including imports and backend writes.
create or replace function private.enforce_student_limit()
returns trigger language plpgsql security definer set search_path=public,private as $$
declare lim int; current_count int;
begin
  if new.status<>'active' then return new; end if;
  select pl.student_limit into lim from public.subscriptions s join public.plans pl on pl.id=s.plan_id where s.organization_id=new.organization_id and s.status in ('trialing','active');
  if lim is null then return new; end if;
  select count(*) into current_count from public.students where organization_id=new.organization_id and status='active' and (tg_op='INSERT' or id<>new.id);
  if current_count>=lim then raise exception 'Student limit reached for current subscription plan (%)',lim; end if;
  return new;
end $$;
drop trigger if exists students_plan_limit on public.students;
create trigger students_plan_limit before insert or update of status,organization_id on public.students for each row execute function private.enforce_student_limit();

create or replace function private.enforce_staff_limit()
returns trigger language plpgsql security definer set search_path=public,private as $$
declare lim int; current_count int;
begin
  if not new.active or new.role in ('student','guardian') then return new; end if;
  select pl.staff_limit into lim from public.subscriptions s join public.plans pl on pl.id=s.plan_id where s.organization_id=new.organization_id and s.status in ('trialing','active');
  if lim is null then return new; end if;
  select count(*) into current_count from public.organization_memberships where organization_id=new.organization_id and active and role not in ('student','guardian') and (tg_op='INSERT' or id<>new.id);
  if current_count>=lim then raise exception 'Staff limit reached for current subscription plan (%)',lim; end if;
  return new;
end $$;
drop trigger if exists memberships_plan_limit on public.organization_memberships;
create trigger memberships_plan_limit before insert or update of active,role,organization_id on public.organization_memberships for each row execute function private.enforce_staff_limit();

create or replace function private.assert_finance_org_active()
returns trigger language plpgsql security definer set search_path=public,private as $$
declare org_status text; sub_status text; trial_end timestamptz;
begin
  select o.status,s.status,s.trial_ends_at into org_status,sub_status,trial_end
  from public.organizations o left join public.subscriptions s on s.organization_id=o.id where o.id=new.organization_id;
  if org_status<>'active' then raise exception 'Organization is not active'; end if;
  if sub_status is null then return new; end if;
  if sub_status='trialing' and trial_end is not null and trial_end<=now() then raise exception 'Subscription trial has expired'; end if;
  if sub_status not in ('trialing','active') then raise exception 'Subscription does not allow financial posting'; end if;
  return new;
end $$;
drop trigger if exists payments_org_active on public.payments;
create trigger payments_org_active before insert on public.payments for each row execute function private.assert_finance_org_active();
drop trigger if exists invoices_org_active on public.invoices;
create trigger invoices_org_active before insert on public.invoices for each row execute function private.assert_finance_org_active();

-- Prevent direct deletion of auditable finance records even by elevated API roles.
create or replace function private.block_finance_delete()
returns trigger language plpgsql as $$ begin raise exception 'Financial records are immutable; use a reversal/void workflow'; end $$;
drop trigger if exists payments_no_delete on public.payments; create trigger payments_no_delete before delete on public.payments for each row execute function private.block_finance_delete();
drop trigger if exists refunds_no_delete on public.refunds; create trigger refunds_no_delete before delete on public.refunds for each row execute function private.block_finance_delete();
drop trigger if exists audit_no_delete on public.audit_logs; create trigger audit_no_delete before delete on public.audit_logs for each row execute function private.block_finance_delete();
