create extension if not exists pgcrypto;
create schema if not exists private;
revoke all on schema private from public;
grant usage on schema private to authenticated;

create table public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  status text not null default 'active' check (status in ('active','suspended','closed')),
  plan text not null default 'growth',
  currency text not null default 'PKR',
  timezone text not null default 'Asia/Karachi',
  receipt_prefix text not null default 'REC',
  branding jsonb not null default '{}'::jsonb,
  settings jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  phone text,
  avatar_url text,
  created_at timestamptz not null default now()
);

create table public.organization_memberships (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('owner','super_admin','admin','cashier','accountant','student','guardian','auditor')),
  permissions jsonb not null default '{}'::jsonb,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (organization_id,user_id)
);

create table public.academic_sessions (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  starts_on date not null,
  ends_on date not null,
  active boolean not null default false,
  unique (organization_id,name)
);

create table public.classes (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  sort_order int not null default 0,
  active boolean not null default true,
  unique (organization_id,name)
);

create table public.sections (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  class_id uuid not null references public.classes(id) on delete cascade,
  name text not null,
  unique (class_id,name)
);

create table public.students (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  auth_user_id uuid unique references auth.users(id) on delete set null,
  admission_no text not null,
  login_id text,
  roll_no text,
  full_name text not null,
  guardian_name text,
  guardian_phone text,
  guardian_email text,
  class_id uuid references public.classes(id) on delete set null,
  section_id uuid references public.sections(id) on delete set null,
  joined_on date,
  status text not null default 'active' check (status in ('active','inactive','graduated','left')),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique (organization_id,admission_no),
  unique (organization_id,login_id)
);

create table public.student_guardians (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  auth_user_id uuid not null references auth.users(id) on delete cascade,
  relation text not null default 'guardian',
  unique (student_id,auth_user_id)
);

create table public.fee_categories (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  code text not null,
  name text not null,
  frequency text not null check (frequency in ('monthly','annual','one_time','custom')),
  include_in_monthly_defaulter boolean not null default false,
  active boolean not null default true,
  unique (organization_id,code)
);

create table public.fee_structures (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  academic_session_id uuid not null references public.academic_sessions(id) on delete cascade,
  class_id uuid references public.classes(id) on delete cascade,
  fee_category_id uuid not null references public.fee_categories(id) on delete cascade,
  amount_minor bigint not null check (amount_minor >= 0),
  due_day smallint not null default 7 check (due_day between 1 and 28),
  active boolean not null default true
);

create unique index fee_structure_unique on public.fee_structures(
  organization_id,academic_session_id,coalesce(class_id,'00000000-0000-0000-0000-000000000000'::uuid),fee_category_id
);

create table public.invoices (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  student_id uuid not null references public.students(id) on delete restrict,
  academic_session_id uuid references public.academic_sessions(id) on delete restrict,
  invoice_no text,
  invoice_month date,
  issue_date date not null default current_date,
  due_date date not null,
  total_minor bigint not null default 0 check (total_minor >= 0),
  discount_minor bigint not null default 0 check (discount_minor >= 0),
  paid_minor bigint not null default 0 check (paid_minor >= 0),
  status text not null default 'open' check (status in ('draft','open','partial','paid','void')),
  notes text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id,invoice_no)
);

create table public.invoice_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  invoice_id uuid not null references public.invoices(id) on delete cascade,
  fee_category_id uuid references public.fee_categories(id) on delete set null,
  description text not null,
  quantity int not null default 1 check (quantity > 0),
  unit_amount_minor bigint not null check (unit_amount_minor >= 0),
  total_amount_minor bigint not null check (total_amount_minor >= 0)
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  student_id uuid not null references public.students(id) on delete restrict,
  receipt_no text not null,
  received_at timestamptz not null default now(),
  amount_minor bigint not null check (amount_minor > 0),
  payment_method text not null check (payment_method in ('cash','bank','online','cheque','other')),
  reference text,
  notes text,
  status text not null default 'posted' check (status in ('posted','voided')),
  idempotency_key uuid not null,
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  unique (organization_id,receipt_no),
  unique (organization_id,idempotency_key)
);

create table public.payment_allocations (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  payment_id uuid not null references public.payments(id) on delete cascade,
  invoice_id uuid not null references public.invoices(id) on delete restrict,
  amount_minor bigint not null check (amount_minor > 0),
  unique (payment_id,invoice_id)
);

create table public.student_credits (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  source_payment_id uuid references public.payments(id) on delete restrict,
  amount_minor bigint not null check (amount_minor > 0),
  remaining_minor bigint not null check (remaining_minor >= 0 and remaining_minor <= amount_minor),
  created_at timestamptz not null default now()
);

create table public.refunds (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  payment_id uuid not null references public.payments(id) on delete restrict,
  refund_no text not null,
  amount_minor bigint not null check (amount_minor > 0),
  reason text not null,
  status text not null default 'posted' check (status in ('pending','posted','rejected','voided')),
  created_by uuid not null references auth.users(id) on delete restrict,
  approved_by uuid references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  unique (organization_id,refund_no)
);

create table public.receipt_sequences (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  fiscal_year int not null,
  last_number bigint not null default 0,
  primary key (organization_id,fiscal_year)
);

create table public.daily_closings (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  business_date date not null,
  cashier_id uuid not null references auth.users(id) on delete restrict,
  gross_minor bigint not null default 0,
  refunds_minor bigint not null default 0,
  net_minor bigint not null default 0,
  notes text,
  closed_at timestamptz not null default now(),
  unique (organization_id,business_date,cashier_id)
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  student_id uuid references public.students(id) on delete cascade,
  kind text not null,
  title text not null,
  body text,
  payload jsonb not null default '{}'::jsonb,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  organization_id uuid not null references public.organizations(id) on delete restrict,
  actor_id uuid references auth.users(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id text,
  before_data jsonb,
  after_data jsonb,
  created_at timestamptz not null default now()
);

create index memberships_user_idx on public.organization_memberships(user_id,active);
create index students_org_idx on public.students(organization_id,status,class_id,section_id);
create index invoices_student_idx on public.invoices(organization_id,student_id,status,due_date);
create index invoices_month_idx on public.invoices(organization_id,invoice_month);
create index payments_date_idx on public.payments(organization_id,received_at desc);
create index payments_student_idx on public.payments(organization_id,student_id,received_at desc);
create index audit_org_idx on public.audit_logs(organization_id,created_at desc);

create or replace function private.user_has_org_access(p_org uuid,p_roles text[] default null)
returns boolean language sql stable security definer set search_path=public,private as $$
  select exists(
    select 1 from public.organization_memberships m
    where m.organization_id=p_org and m.user_id=auth.uid() and m.active
      and (p_roles is null or m.role=any(p_roles))
  );
$$;

create or replace function private.user_can_access_student(p_student uuid)
returns boolean language sql stable security definer set search_path=public,private as $$
  select exists(
    select 1 from public.students s where s.id=p_student and (
      s.auth_user_id=auth.uid()
      or exists(select 1 from public.student_guardians g where g.student_id=s.id and g.auth_user_id=auth.uid())
      or private.user_has_org_access(s.organization_id,array['owner','super_admin','admin','cashier','accountant','auditor'])
    )
  );
$$;

revoke all on function private.user_has_org_access(uuid,text[]) from public;
revoke all on function private.user_can_access_student(uuid) from public;
grant execute on function private.user_has_org_access(uuid,text[]) to authenticated;
grant execute on function private.user_can_access_student(uuid) to authenticated;

alter table public.organizations enable row level security;
alter table public.profiles enable row level security;
alter table public.organization_memberships enable row level security;
alter table public.academic_sessions enable row level security;
alter table public.classes enable row level security;
alter table public.sections enable row level security;
alter table public.students enable row level security;
alter table public.student_guardians enable row level security;
alter table public.fee_categories enable row level security;
alter table public.fee_structures enable row level security;
alter table public.invoices enable row level security;
alter table public.invoice_items enable row level security;
alter table public.payments enable row level security;
alter table public.payment_allocations enable row level security;
alter table public.student_credits enable row level security;
alter table public.refunds enable row level security;
alter table public.receipt_sequences enable row level security;
alter table public.daily_closings enable row level security;
alter table public.notifications enable row level security;
alter table public.audit_logs enable row level security;

create policy org_read on public.organizations for select to authenticated using(private.user_has_org_access(id));
create policy org_write on public.organizations for update to authenticated using(private.user_has_org_access(id,array['owner','super_admin'])) with check(private.user_has_org_access(id,array['owner','super_admin']));
create policy profile_read on public.profiles for select to authenticated using(id=auth.uid());
create policy profile_write on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid());
create policy membership_read on public.organization_memberships for select to authenticated using(user_id=auth.uid() or private.user_has_org_access(organization_id,array['owner','super_admin','admin','auditor']));
create policy membership_insert on public.organization_memberships for insert to authenticated with check(private.user_has_org_access(organization_id,array['owner','super_admin']));
create policy membership_update on public.organization_memberships for update to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin'])) with check(private.user_has_org_access(organization_id,array['owner','super_admin']));

create policy academic_read on public.academic_sessions for select to authenticated using(private.user_has_org_access(organization_id));
create policy academic_write on public.academic_sessions for all to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin','admin'])) with check(private.user_has_org_access(organization_id,array['owner','super_admin','admin']));
create policy classes_read on public.classes for select to authenticated using(private.user_has_org_access(organization_id));
create policy classes_write on public.classes for all to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin','admin'])) with check(private.user_has_org_access(organization_id,array['owner','super_admin','admin']));
create policy sections_read on public.sections for select to authenticated using(private.user_has_org_access(organization_id));
create policy sections_write on public.sections for all to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin','admin'])) with check(private.user_has_org_access(organization_id,array['owner','super_admin','admin']));

create policy students_read on public.students for select to authenticated using(private.user_can_access_student(id));
create policy students_write on public.students for all to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant'])) with check(private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant']));
create policy guardians_read on public.student_guardians for select to authenticated using(auth_user_id=auth.uid() or private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant','auditor']));
create policy guardians_write on public.student_guardians for all to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin','admin'])) with check(private.user_has_org_access(organization_id,array['owner','super_admin','admin']));

create policy fee_cat_read on public.fee_categories for select to authenticated using(private.user_has_org_access(organization_id));
create policy fee_cat_write on public.fee_categories for all to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant'])) with check(private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant']));
create policy fee_struct_read on public.fee_structures for select to authenticated using(private.user_has_org_access(organization_id));
create policy fee_struct_write on public.fee_structures for all to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant'])) with check(private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant']));

create policy invoice_read on public.invoices for select to authenticated using(private.user_can_access_student(student_id));
create policy invoice_write on public.invoices for all to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant'])) with check(private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant']));
create policy item_read on public.invoice_items for select to authenticated using(exists(select 1 from public.invoices i where i.id=invoice_id and private.user_can_access_student(i.student_id)));
create policy item_write on public.invoice_items for all to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant'])) with check(private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant']));

create policy payment_read on public.payments for select to authenticated using(private.user_can_access_student(student_id));
create policy allocation_read on public.payment_allocations for select to authenticated using(exists(select 1 from public.payments p where p.id=payment_id and private.user_can_access_student(p.student_id)));
create policy credit_read on public.student_credits for select to authenticated using(private.user_can_access_student(student_id));
create policy refund_read on public.refunds for select to authenticated using(exists(select 1 from public.payments p where p.id=payment_id and private.user_can_access_student(p.student_id)));
create policy closing_read on public.daily_closings for select to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','cashier','accountant','auditor']));
create policy closing_insert on public.daily_closings for insert to authenticated with check(cashier_id=auth.uid() and private.user_has_org_access(organization_id,array['owner','super_admin','cashier','accountant']));
create policy notification_read on public.notifications for select to authenticated using(user_id=auth.uid() or private.user_has_org_access(organization_id,array['owner','super_admin','admin']));
create policy notification_update on public.notifications for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy audit_read on public.audit_logs for select to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant','auditor']));

create or replace view public.v_my_active_membership with (security_invoker=true) as
select m.organization_id,o.name organization_name,o.slug organization_slug,m.role,p.full_name,m.permissions
from public.organization_memberships m
join public.organizations o on o.id=m.organization_id
left join public.profiles p on p.id=m.user_id
where m.user_id=auth.uid() and m.active;

create or replace view public.v_student_account_summary with (security_invoker=true) as
select s.id,s.organization_id,s.admission_no,s.login_id,s.roll_no,s.full_name,s.guardian_name,s.guardian_phone,s.status,
       c.name class_name,se.name section_name,
       coalesce((select fs.amount_minor from public.fee_structures fs join public.fee_categories fc on fc.id=fs.fee_category_id join public.academic_sessions a on a.id=fs.academic_session_id where fs.organization_id=s.organization_id and fs.active and a.active and (fs.class_id=s.class_id or fs.class_id is null) and fc.code='MONTHLY' order by fs.class_id nulls last limit 1),0)::bigint monthly_fee_minor,
       coalesce((select fs.amount_minor from public.fee_structures fs join public.fee_categories fc on fc.id=fs.fee_category_id join public.academic_sessions a on a.id=fs.academic_session_id where fs.organization_id=s.organization_id and fs.active and a.active and (fs.class_id=s.class_id or fs.class_id is null) and fc.code='ANNUAL_FUND' order by fs.class_id nulls last limit 1),0)::bigint annual_fund_minor,
       coalesce((select sum(i.total_minor-i.discount_minor-i.paid_minor) from public.invoices i where i.student_id=s.id and i.status in ('open','partial')),0)::bigint outstanding_minor,
       coalesce((select sum(sc.remaining_minor) from public.student_credits sc where sc.student_id=s.id),0)::bigint credit_minor
from public.students s
left join public.classes c on c.id=s.class_id
left join public.sections se on se.id=s.section_id;

create or replace view public.v_collection_last_7_days with (security_invoker=true) as
with d as (select x::date business_date from generate_series(current_date-6,current_date,'1 day') x),
p as (select received_at::date business_date,sum(amount_minor)::bigint amount from public.payments where status='posted' group by 1),
r as (select created_at::date business_date,sum(amount_minor)::bigint amount from public.refunds where status='posted' group by 1)
select to_char(d.business_date,'Dy') label,(coalesce(p.amount,0)-coalesce(r.amount,0))::bigint amount
from d left join p using(business_date) left join r using(business_date) order by d.business_date;

create or replace function private.next_receipt_no(p_org uuid)
returns text language plpgsql security definer set search_path=public,private as $$
declare y int:=extract(year from current_date); n bigint; prefix text;
begin
  select receipt_prefix into prefix from public.organizations where id=p_org;
  if prefix is null then raise exception 'Organization not found'; end if;
  insert into public.receipt_sequences(organization_id,fiscal_year,last_number) values(p_org,y,1)
  on conflict(organization_id,fiscal_year) do update set last_number=public.receipt_sequences.last_number+1
  returning last_number into n;
  return prefix||'-'||y::text||'-'||lpad(n::text,6,'0');
end $$;
revoke all on function private.next_receipt_no(uuid) from public;

create or replace function public.record_payment(p_student_id uuid,p_amount_minor bigint,p_payment_method text,p_notes text,p_idempotency_key uuid)
returns jsonb language plpgsql security definer set search_path=public,private as $$
declare org uuid; pid uuid; receipt text; remaining bigint:=p_amount_minor; alloc bigint; existing public.payments%rowtype; inv record;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_amount_minor<=0 then raise exception 'Payment amount must be greater than zero'; end if;
  if p_payment_method not in ('cash','bank','online','cheque','other') then raise exception 'Unsupported payment method'; end if;
  select organization_id into org from public.students where id=p_student_id and status='active';
  if org is null then raise exception 'Active student not found'; end if;
  if not private.user_has_org_access(org,array['owner','super_admin','cashier','accountant']) then raise exception 'Not authorized to receive payments'; end if;
  select * into existing from public.payments where organization_id=org and idempotency_key=p_idempotency_key;
  if found then return jsonb_build_object('payment_id',existing.id,'receipt_no',existing.receipt_no,'amount_minor',existing.amount_minor,'duplicate',true); end if;
  receipt:=private.next_receipt_no(org);
  insert into public.payments(organization_id,student_id,receipt_no,amount_minor,payment_method,notes,idempotency_key,created_by)
  values(org,p_student_id,receipt,p_amount_minor,p_payment_method,p_notes,p_idempotency_key,auth.uid()) returning id into pid;
  for inv in select id,total_minor,discount_minor,paid_minor from public.invoices where organization_id=org and student_id=p_student_id and status in ('open','partial') order by due_date,id for update loop
    exit when remaining<=0;
    alloc:=least(remaining,greatest((inv.total_minor-inv.discount_minor)-inv.paid_minor,0));
    if alloc>0 then
      insert into public.payment_allocations(organization_id,payment_id,invoice_id,amount_minor) values(org,pid,inv.id,alloc);
      update public.invoices set paid_minor=paid_minor+alloc,status=case when paid_minor+alloc>=total_minor-discount_minor then 'paid' else 'partial' end,updated_at=now() where id=inv.id;
      remaining:=remaining-alloc;
    end if;
  end loop;
  if remaining>0 then insert into public.student_credits(organization_id,student_id,source_payment_id,amount_minor,remaining_minor) values(org,p_student_id,pid,remaining,remaining); end if;
  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,after_data)
  values(org,auth.uid(),'payment.recorded','payment',pid::text,jsonb_build_object('receipt_no',receipt,'student_id',p_student_id,'amount_minor',p_amount_minor,'advance_minor',remaining,'method',p_payment_method));
  return jsonb_build_object('payment_id',pid,'receipt_no',receipt,'amount_minor',p_amount_minor,'advance_minor',remaining,'duplicate',false);
end $$;
revoke all on function public.record_payment(uuid,bigint,text,text,uuid) from public,anon;
grant execute on function public.record_payment(uuid,bigint,text,text,uuid) to authenticated;

create or replace function public.dashboard_metrics()
returns jsonb language plpgsql security invoker set search_path=public,private as $$
declare org uuid; students bigint; defaulters bigint; paid bigint; partial bigint; today_amt bigint; week_amt bigint; month_amt bigint; year_amt bigint; all_amt bigint; refund_amt bigint; outstanding bigint;
begin
  select organization_id into org from public.organization_memberships where user_id=auth.uid() and active and role in ('owner','super_admin','admin','cashier','accountant','auditor') order by created_at limit 1;
  if org is null then raise exception 'Staff organization not found'; end if;
  select count(*) into students from public.students where organization_id=org and status='active';
  select count(distinct student_id) into defaulters from public.invoices where organization_id=org and status in ('open','partial') and due_date<current_date and invoice_month=date_trunc('month',current_date)::date;
  select count(distinct student_id) filter(where status='paid'),count(distinct student_id) filter(where status='partial') into paid,partial from public.invoices where organization_id=org and invoice_month=date_trunc('month',current_date)::date;
  select coalesce(sum(amount_minor),0) into today_amt from public.payments where organization_id=org and status='posted' and received_at::date=current_date;
  select coalesce(sum(amount_minor),0) into week_amt from public.payments where organization_id=org and status='posted' and received_at::date>=date_trunc('week',current_date)::date;
  select coalesce(sum(amount_minor),0) into month_amt from public.payments where organization_id=org and status='posted' and received_at::date>=date_trunc('month',current_date)::date;
  select coalesce(sum(amount_minor),0) into year_amt from public.payments where organization_id=org and status='posted' and extract(year from received_at)=extract(year from current_date);
  select coalesce(sum(amount_minor),0) into all_amt from public.payments where organization_id=org and status='posted';
  select coalesce(sum(amount_minor),0) into refund_amt from public.refunds where organization_id=org and status='posted' and created_at::date>=date_trunc('month',current_date)::date;
  select coalesce(sum(total_minor-discount_minor-paid_minor),0) into outstanding from public.invoices where organization_id=org and status in ('open','partial');
  return jsonb_build_object('today',today_amt,'week',week_amt,'month',month_amt-refund_amt,'academicYear',year_amt,'allTime',all_amt,'gross',month_amt,'refunds',refund_amt,'net',month_amt-refund_amt,'outstanding',outstanding,'students',students,'defaulters',defaulters,'paidThisMonth',coalesce(paid,0),'partialThisMonth',coalesce(partial,0));
end $$;
revoke all on function public.dashboard_metrics() from public,anon;
grant execute on function public.dashboard_metrics() to authenticated;

-- Supabase 2026 defaults require explicit Data API grants. RLS remains the row boundary.
grant select on public.organizations,public.profiles,public.organization_memberships,public.academic_sessions,public.classes,public.sections,public.students,public.student_guardians,public.fee_categories,public.fee_structures,public.invoices,public.invoice_items,public.payments,public.payment_allocations,public.student_credits,public.refunds,public.daily_closings,public.notifications,public.audit_logs to authenticated;
grant insert,update on public.profiles,public.organization_memberships,public.academic_sessions,public.classes,public.sections,public.students,public.student_guardians,public.fee_categories,public.fee_structures,public.invoices,public.invoice_items,public.daily_closings,public.notifications to authenticated;
grant select on public.v_my_active_membership,public.v_student_account_summary,public.v_collection_last_7_days to authenticated;
revoke all on public.receipt_sequences from anon,authenticated;
revoke insert,update,delete on public.payments,public.payment_allocations,public.student_credits,public.refunds,public.audit_logs from anon,authenticated;

create or replace view public.v_current_month_defaulters with (security_invoker=true) as
select s.id student_id,s.admission_no,s.roll_no,s.full_name,s.guardian_name,s.guardian_phone,
       c.name class_name,se.name section_name,
       sum(greatest(i.total_minor-i.discount_minor-i.paid_minor,0))::bigint current_month_due_minor,
       (select coalesce(sum(greatest(ix.total_minor-ix.discount_minor-ix.paid_minor,0)),0) from public.invoices ix where ix.student_id=s.id and ix.status in ('open','partial'))::bigint outstanding_minor,
       (select coalesce(sum(sc.remaining_minor),0) from public.student_credits sc where sc.student_id=s.id)::bigint credit_minor
from public.students s
join public.invoices i on i.student_id=s.id and i.organization_id=s.organization_id
left join public.classes c on c.id=s.class_id
left join public.sections se on se.id=s.section_id
where s.status='active' and i.invoice_month=date_trunc('month',current_date)::date and i.status in ('open','partial') and i.due_date<current_date
group by s.id,s.admission_no,s.roll_no,s.full_name,s.guardian_name,s.guardian_phone,c.name,se.name;

grant select on public.v_current_month_defaulters to authenticated;

create unique index invoices_one_monthly_per_student on public.invoices(organization_id,student_id,invoice_month) where invoice_month is not null;

create or replace function public.generate_monthly_invoices(p_month date)
returns jsonb language plpgsql security definer set search_path=public,private as $$
declare org uuid; session_id uuid; created_count int:=0; s record; fee bigint; due_day int; inv_id uuid; month_start date:=date_trunc('month',p_month)::date;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select organization_id into org from public.organization_memberships where user_id=auth.uid() and active and role in ('owner','super_admin','admin','accountant') order by created_at limit 1;
  if org is null then raise exception 'Not authorized'; end if;
  select id into session_id from public.academic_sessions where organization_id=org and active limit 1;
  if session_id is null then raise exception 'Active academic session missing'; end if;

  for s in select * from public.students where organization_id=org and status='active' loop
    select fs.amount_minor,fs.due_day into fee,due_day
    from public.fee_structures fs join public.fee_categories fc on fc.id=fs.fee_category_id
    where fs.organization_id=org and fs.academic_session_id=session_id and fs.active and fc.code='MONTHLY' and (fs.class_id=s.class_id or fs.class_id is null)
    order by fs.class_id nulls last limit 1;
    if fee is null then continue; end if;
    if exists(select 1 from public.invoices where organization_id=org and student_id=s.id and invoice_month=month_start) then continue; end if;
    insert into public.invoices(organization_id,student_id,academic_session_id,invoice_no,invoice_month,issue_date,due_date,total_minor,status,created_by)
    values(org,s.id,session_id,'INV-'||to_char(month_start,'YYYYMM')||'-'||s.admission_no,month_start,month_start,month_start+(greatest(due_day,1)-1),fee,'open',auth.uid()) returning id into inv_id;
    insert into public.invoice_items(organization_id,invoice_id,fee_category_id,description,quantity,unit_amount_minor,total_amount_minor)
    select org,inv_id,fc.id,to_char(month_start,'Mon YYYY')||' Monthly Tuition',1,fee,fee from public.fee_categories fc where fc.organization_id=org and fc.code='MONTHLY' limit 1;
    created_count:=created_count+1;
  end loop;
  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,after_data) values(org,auth.uid(),'billing.month.generated','invoice_batch',to_char(month_start,'YYYY-MM'),jsonb_build_object('created',created_count));
  return jsonb_build_object('month',month_start,'created',created_count);
end $$;
revoke all on function public.generate_monthly_invoices(date) from public,anon;
grant execute on function public.generate_monthly_invoices(date) to authenticated;
