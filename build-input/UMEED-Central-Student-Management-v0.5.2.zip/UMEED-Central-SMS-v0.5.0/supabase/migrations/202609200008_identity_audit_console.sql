-- Staff identity visibility and audit console support.
alter table public.profiles add column if not exists email text;

create policy profile_tenant_manager_read on public.profiles for select to authenticated
using(
  id=(select auth.uid())
  or exists(
    select 1
    from public.organization_memberships target
    where target.user_id=profiles.id and target.active
      and private.user_has_org_access(target.organization_id,array['owner','super_admin','admin','accountant','auditor'])
  )
);

create or replace view public.v_org_staff with (security_invoker=true) as
select m.id membership_id,m.organization_id,m.user_id,m.role,m.active,m.created_at,
       p.full_name,p.email,p.phone,p.avatar_url
from public.organization_memberships m
left join public.profiles p on p.id=m.user_id
where m.organization_id=private.current_org() and m.role not in ('student','guardian');
grant select on public.v_org_staff to authenticated;

create or replace view public.v_audit_feed with (security_invoker=true) as
select a.id,a.organization_id,a.actor_id,coalesce(p.full_name,'System') actor_name,a.action,a.entity_type,a.entity_id,a.before_data,a.after_data,a.created_at
from public.audit_logs a
left join public.profiles p on p.id=a.actor_id
where a.organization_id=private.current_org();
grant select on public.v_audit_feed to authenticated;
