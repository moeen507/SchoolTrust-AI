-- Academic security hardening, exam publication lifecycle and student-visible grading.

create or replace function private.user_is_linked_student(p_student uuid)
returns boolean
language sql
stable
security definer
set search_path=public,private
as $$
  select exists(
    select 1 from public.students s
    where s.id=p_student and s.auth_user_id=auth.uid()
  ) or exists(
    select 1 from public.student_guardians g
    where g.student_id=p_student and g.auth_user_id=auth.uid()
  );
$$;
revoke all on function private.user_is_linked_student(uuid) from public;
grant execute on function private.user_is_linked_student(uuid) to authenticated;

-- Remove broad read access inherited from general financial student access.
drop policy if exists subjects_read on public.subjects;
create policy subjects_read on public.subjects for select to authenticated
using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','academic_manager','teacher','student','guardian','auditor']));

drop policy if exists class_subjects_read on public.class_subjects;
create policy class_subjects_read on public.class_subjects for select to authenticated
using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','academic_manager','teacher','student','guardian','auditor']));

drop policy if exists attendance_read on public.student_attendance;
create policy attendance_read on public.student_attendance for select to authenticated
using(
  private.user_is_linked_student(student_id)
  or private.user_has_org_access(organization_id,array['owner','super_admin','admin','academic_manager','teacher','auditor'])
);

drop policy if exists exams_read on public.exams;
create policy exams_read on public.exams for select to authenticated
using(
  private.user_has_org_access(organization_id,array['owner','super_admin','admin','academic_manager','teacher','auditor'])
  or (status in ('published','locked') and private.user_has_org_access(organization_id,array['student','guardian']))
);

drop policy if exists exam_subjects_read on public.exam_subjects;
create policy exam_subjects_read on public.exam_subjects for select to authenticated
using(
  private.user_has_org_access(organization_id,array['owner','super_admin','admin','academic_manager','teacher','auditor'])
  or (private.user_has_org_access(organization_id,array['student','guardian']) and exists(
    select 1 from public.exams e where e.id=exam_id and e.status in ('published','locked')
  ))
);

drop policy if exists marks_read on public.student_marks;
create policy marks_read on public.student_marks for select to authenticated
using(
  private.user_has_org_access(organization_id,array['owner','super_admin','admin','academic_manager','teacher','auditor'])
  or (private.user_is_linked_student(student_id) and exists(
    select 1 from public.exam_subjects es join public.exams e on e.id=es.exam_id
    where es.id=exam_subject_id and e.status in ('published','locked')
  ))
);

drop policy if exists grading_read on public.grading_scales;
create policy grading_read on public.grading_scales for select to authenticated
using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','academic_manager','teacher','student','guardian','auditor']));

drop policy if exists sales_read on public.student_sales;
create policy sales_read on public.student_sales for select to authenticated
using(
  private.user_is_linked_student(student_id)
  or private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant','auditor','store_clerk','canteen_cashier'])
);

drop policy if exists sale_items_read on public.student_sale_items;
create policy sale_items_read on public.student_sale_items for select to authenticated
using(exists(
  select 1 from public.student_sales x
  where x.id=sale_id and (
    private.user_is_linked_student(x.student_id)
    or private.user_has_org_access(x.organization_id,array['owner','super_admin','admin','accountant','auditor','store_clerk','canteen_cashier'])
  )
));

create or replace function public.set_exam_status(p_exam_id uuid,p_status text)
returns jsonb
language plpgsql
security definer
set search_path=public,private
as $$
declare v_org uuid; v_old text;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_status not in ('draft','published','locked') then raise exception 'Invalid exam status'; end if;
  select organization_id into v_org from public.organization_memberships
  where user_id=auth.uid() and active and role in ('owner','super_admin','admin','academic_manager') order by created_at limit 1;
  if v_org is null then raise exception 'Not authorized'; end if;
  select status into v_old from public.exams where id=p_exam_id and organization_id=v_org for update;
  if v_old is null then raise exception 'Exam not found'; end if;
  if v_old='locked' and p_status<>'locked' then raise exception 'A locked exam cannot be reopened'; end if;
  if p_status in ('published','locked') and not exists(select 1 from public.exam_subjects where exam_id=p_exam_id) then
    raise exception 'Configure at least one exam subject before publishing';
  end if;
  update public.exams
  set status=p_status,
      published_at=case when p_status in ('published','locked') then coalesce(published_at,now()) else null end
  where id=p_exam_id;
  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,before_data,after_data)
  values(v_org,auth.uid(),'academic.exam.status','exam',p_exam_id::text,jsonb_build_object('status',v_old),jsonb_build_object('status',p_status));
  return jsonb_build_object('exam_id',p_exam_id,'status',p_status);
end;
$$;
revoke all on function public.set_exam_status(uuid,text) from public;
grant execute on function public.set_exam_status(uuid,text) to authenticated;

-- Lock-aware and audited attendance posting.
create or replace function public.upsert_student_attendance(p_student_id uuid,p_date date,p_status text,p_remarks text default null)
returns jsonb
language plpgsql
security definer
set search_path=public,private
as $$
declare v_org uuid; v_id uuid; v_before jsonb;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_status not in ('present','absent','late','leave','holiday') then raise exception 'Invalid attendance status'; end if;
  select organization_id into v_org from public.organization_memberships
  where user_id=auth.uid() and active and role in ('owner','super_admin','admin','academic_manager','teacher') order by created_at limit 1;
  if v_org is null then raise exception 'Not authorized'; end if;
  if not exists(select 1 from public.students where id=p_student_id and organization_id=v_org and status='active') then raise exception 'Invalid student'; end if;
  select to_jsonb(a) into v_before from public.student_attendance a where a.student_id=p_student_id and a.attendance_date=p_date;
  insert into public.student_attendance(organization_id,student_id,attendance_date,status,remarks,marked_by)
  values(v_org,p_student_id,p_date,p_status,nullif(trim(p_remarks),''),auth.uid())
  on conflict(student_id,attendance_date) do update set status=excluded.status,remarks=excluded.remarks,marked_by=auth.uid(),updated_at=now()
  returning id into v_id;
  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,before_data,after_data)
  values(v_org,auth.uid(),'academic.attendance.upsert','student_attendance',v_id::text,v_before,jsonb_build_object('student_id',p_student_id,'date',p_date,'status',p_status,'remarks',nullif(trim(p_remarks),'')));
  return jsonb_build_object('attendance_id',v_id,'student_id',p_student_id,'date',p_date,'status',p_status);
end;
$$;
revoke all on function public.upsert_student_attendance(uuid,date,text,text) from public;
grant execute on function public.upsert_student_attendance(uuid,date,text,text) to authenticated;

create or replace function public.upsert_exam_subject(p_exam_id uuid,p_class_id uuid,p_section_id uuid,p_subject_id uuid,p_max_marks numeric,p_pass_marks numeric)
returns jsonb
language plpgsql
security definer
set search_path=public,private
as $$
declare v_org uuid; v_id uuid; v_status text;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select organization_id into v_org from public.organization_memberships
  where user_id=auth.uid() and active and role in ('owner','super_admin','admin','academic_manager') order by created_at limit 1;
  if v_org is null then raise exception 'Not authorized'; end if;
  if p_max_marks<=0 or p_pass_marks<0 or p_pass_marks>p_max_marks then raise exception 'Invalid marks range'; end if;
  select status into v_status from public.exams where id=p_exam_id and organization_id=v_org;
  if v_status is null then raise exception 'Invalid exam'; end if;
  if v_status='locked' then raise exception 'Exam is locked'; end if;
  if not exists(select 1 from public.classes where id=p_class_id and organization_id=v_org) then raise exception 'Invalid class'; end if;
  if p_section_id is not null and not exists(select 1 from public.sections where id=p_section_id and organization_id=v_org and class_id=p_class_id) then raise exception 'Invalid section'; end if;
  if not exists(select 1 from public.subjects where id=p_subject_id and organization_id=v_org and active) then raise exception 'Invalid subject'; end if;
  select id into v_id from public.exam_subjects where exam_id=p_exam_id and class_id=p_class_id and subject_id=p_subject_id and section_id is not distinct from p_section_id for update;
  if v_id is null then
    insert into public.exam_subjects(organization_id,exam_id,class_id,section_id,subject_id,max_marks,pass_marks)
    values(v_org,p_exam_id,p_class_id,p_section_id,p_subject_id,p_max_marks,p_pass_marks) returning id into v_id;
  else
    update public.exam_subjects set max_marks=p_max_marks,pass_marks=p_pass_marks where id=v_id;
  end if;
  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,after_data)
  values(v_org,auth.uid(),'academic.exam_subject.upsert','exam_subject',v_id::text,jsonb_build_object('exam_id',p_exam_id,'class_id',p_class_id,'section_id',p_section_id,'subject_id',p_subject_id,'max_marks',p_max_marks,'pass_marks',p_pass_marks));
  return jsonb_build_object('exam_subject_id',v_id);
end;
$$;
revoke all on function public.upsert_exam_subject(uuid,uuid,uuid,uuid,numeric,numeric) from public;
grant execute on function public.upsert_exam_subject(uuid,uuid,uuid,uuid,numeric,numeric) to authenticated;

create or replace function public.upsert_student_mark(p_exam_subject_id uuid,p_student_id uuid,p_marks numeric,p_remarks text default null)
returns jsonb
language plpgsql
security definer
set search_path=public,private
as $$
declare v_org uuid; v_max numeric; v_class uuid; v_section uuid; v_id uuid; v_exam_status text; v_before jsonb;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select organization_id into v_org from public.organization_memberships
  where user_id=auth.uid() and active and role in ('owner','super_admin','admin','academic_manager','teacher') order by created_at limit 1;
  if v_org is null then raise exception 'Not authorized'; end if;
  select es.max_marks,es.class_id,es.section_id,e.status into v_max,v_class,v_section,v_exam_status
  from public.exam_subjects es join public.exams e on e.id=es.exam_id
  where es.id=p_exam_subject_id and es.organization_id=v_org;
  if v_max is null then raise exception 'Invalid exam subject'; end if;
  if v_exam_status='locked' then raise exception 'Exam is locked'; end if;
  if p_marks<0 or p_marks>v_max then raise exception 'Marks must be between 0 and %',v_max; end if;
  if not exists(select 1 from public.students s where s.id=p_student_id and s.organization_id=v_org and s.status='active' and s.class_id=v_class and (v_section is null or s.section_id=v_section)) then raise exception 'Student is not enrolled in this class/section'; end if;
  select to_jsonb(sm) into v_before from public.student_marks sm where sm.exam_subject_id=p_exam_subject_id and sm.student_id=p_student_id;
  insert into public.student_marks(organization_id,exam_subject_id,student_id,marks_obtained,remarks,entered_by)
  values(v_org,p_exam_subject_id,p_student_id,p_marks,nullif(trim(p_remarks),''),auth.uid())
  on conflict(exam_subject_id,student_id) do update set marks_obtained=excluded.marks_obtained,remarks=excluded.remarks,entered_by=auth.uid(),updated_at=now()
  returning id into v_id;
  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,before_data,after_data)
  values(v_org,auth.uid(),'academic.mark.upsert','student_mark',v_id::text,v_before,jsonb_build_object('student_id',p_student_id,'exam_subject_id',p_exam_subject_id,'marks',p_marks,'max_marks',v_max,'remarks',nullif(trim(p_remarks),'')));
  return jsonb_build_object('mark_id',v_id,'student_id',p_student_id,'marks',p_marks,'max_marks',v_max);
end;
$$;
revoke all on function public.upsert_student_mark(uuid,uuid,numeric,text) from public;
grant execute on function public.upsert_student_mark(uuid,uuid,numeric,text) to authenticated;

-- Attach tenant-defined grade/remark to each performance row.
create or replace view public.v_student_performance with (security_invoker=true) as
select sm.organization_id,sm.student_id,e.id exam_id,e.name exam_name,e.term,e.status exam_status,
       sub.id subject_id,sub.name subject_name,es.max_marks,es.pass_marks,sm.marks_obtained,
       round((sm.marks_obtained/nullif(es.max_marks,0))*100,2) percentage,
       (sm.marks_obtained>=es.pass_marks) passed,sm.remarks,sm.updated_at,
       gs.grade,gs.remark grade_remark
from public.student_marks sm
join public.exam_subjects es on es.id=sm.exam_subject_id
join public.exams e on e.id=es.exam_id
join public.subjects sub on sub.id=es.subject_id
left join lateral (
  select g.grade,g.remark from public.grading_scales g
  where g.organization_id=sm.organization_id
    and ((sm.marks_obtained/nullif(es.max_marks,0))*100) between g.min_percentage and g.max_percentage
  order by g.sort_order,g.max_percentage desc limit 1
) gs on true;

grant select on public.v_student_performance to authenticated;

-- Academic transactional records are written only through audited RPCs above.
-- This prevents clients from bypassing exam lock/publication rules with direct Data API writes.
revoke insert,update,delete on public.student_attendance from authenticated;
revoke insert,update,delete on public.exams from authenticated;
revoke insert,update,delete on public.exam_subjects from authenticated;
revoke insert,update,delete on public.student_marks from authenticated;
