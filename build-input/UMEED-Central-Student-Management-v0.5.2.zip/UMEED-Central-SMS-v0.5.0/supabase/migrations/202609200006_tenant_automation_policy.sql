-- Respect each tenant's configured defaulter alert day (default 8).
create or replace function private.queue_defaulters_for_org(p_org uuid,p_as_of date)
returns int language plpgsql security definer set search_path=public,private as $$
declare d record; queued int:=0; key text; msg text; alert_day int:=8;
begin
  select greatest(1,least(28,coalesce((settings->>'defaulter_day')::int,8))) into alert_day
  from public.organizations where id=p_org;
  if extract(day from p_as_of)<coalesce(alert_day,8) then return 0; end if;
  for d in
    select s.id student_id,s.full_name,s.guardian_phone,s.guardian_email,
           sum(greatest(i.total_minor-i.discount_minor-i.paid_minor,0))::bigint due_minor
    from public.students s join public.invoices i on i.student_id=s.id and i.organization_id=s.organization_id
    where s.organization_id=p_org and s.status='active' and i.status in ('open','partial')
      and i.invoice_month=date_trunc('month',p_as_of)::date and i.due_date<=p_as_of
    group by s.id,s.full_name,s.guardian_phone,s.guardian_email
  loop
    msg:=d.full_name||' has PKR '||to_char(d.due_minor/100.0,'FM999G999G999G990D00')||' pending for '||to_char(p_as_of,'Mon YYYY')||'.';
    key:='defaulter:'||to_char(p_as_of,'YYYY-MM')||':'||d.student_id::text||':in_app';
    insert into public.notification_queue(organization_id,student_id,channel,template_key,body,payload,dedupe_key)
    values(p_org,d.student_id,'in_app','monthly_defaulter',msg,jsonb_build_object('due_minor',d.due_minor,'month',to_char(p_as_of,'YYYY-MM')),key)
    on conflict(organization_id,dedupe_key) do nothing;
    if found then queued:=queued+1; end if;

    if d.guardian_phone is not null and exists(select 1 from public.notification_channels nc where nc.organization_id=p_org and nc.channel='sms' and nc.enabled) then
      key:='defaulter:'||to_char(p_as_of,'YYYY-MM')||':'||d.student_id::text||':sms';
      insert into public.notification_queue(organization_id,student_id,channel,destination,template_key,body,payload,dedupe_key)
      values(p_org,d.student_id,'sms',d.guardian_phone,'monthly_defaulter',msg,jsonb_build_object('due_minor',d.due_minor,'month',to_char(p_as_of,'YYYY-MM')),key)
      on conflict(organization_id,dedupe_key) do nothing;
      if found then queued:=queued+1; end if;
    end if;

    if d.guardian_email is not null and exists(select 1 from public.notification_channels nc where nc.organization_id=p_org and nc.channel='email' and nc.enabled) then
      key:='defaulter:'||to_char(p_as_of,'YYYY-MM')||':'||d.student_id::text||':email';
      insert into public.notification_queue(organization_id,student_id,channel,destination,template_key,subject,body,payload,dedupe_key)
      values(p_org,d.student_id,'email',d.guardian_email,'monthly_defaulter','Fee payment reminder',msg,jsonb_build_object('due_minor',d.due_minor,'month',to_char(p_as_of,'YYYY-MM')),key)
      on conflict(organization_id,dedupe_key) do nothing;
      if found then queued:=queued+1; end if;
    end if;
  end loop;
  return queued;
end $$;
revoke all on function private.queue_defaulters_for_org(uuid,date) from public,anon,authenticated;
grant execute on function private.queue_defaulters_for_org(uuid,date) to service_role;

create or replace function private.system_tick()
returns jsonb language plpgsql security definer set search_path=public,private as $$
declare o record; local_now timestamp; local_date date; monthly_created int:=0; queued int:=0; c int;
begin
  for o in select id,timezone from public.organizations where status='active' loop
    begin local_now:=timezone(coalesce(nullif(o.timezone,''),'UTC'),now());
    exception when others then local_now:=timezone('UTC',now()); end;
    local_date:=local_now::date;
    if extract(day from local_date)=1 then c:=private.system_generate_monthly_for_org(o.id,local_date); monthly_created:=monthly_created+c; end if;
    c:=private.queue_defaulters_for_org(o.id,local_date); queued:=queued+c;
  end loop;
  return jsonb_build_object('monthly_created',monthly_created,'notifications_queued',queued,'ran_at',now());
end $$;
revoke all on function private.system_tick() from public,anon,authenticated;
grant execute on function private.system_tick() to service_role;
