-- UMEED Central SaaS commercial completion layer
-- Adds accounting reversals, credit consumption, academic history, cashier control,
-- notification outbox, SaaS entitlements, import/export jobs and platform operations.

create extension if not exists pgcrypto;

-- -----------------------------------------------------------------------------
-- Platform / SaaS layer
-- -----------------------------------------------------------------------------
create table if not exists public.platform_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('platform_owner','platform_support','platform_billing')),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.plans (
  id text primary key,
  name text not null,
  price_minor bigint not null default 0 check (price_minor >= 0),
  billing_period text not null default 'month' check (billing_period in ('month','year','custom')),
  student_limit int,
  staff_limit int,
  features jsonb not null default '{}'::jsonb,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.subscriptions (
  organization_id uuid primary key references public.organizations(id) on delete cascade,
  plan_id text not null references public.plans(id),
  status text not null default 'trialing' check (status in ('trialing','active','past_due','suspended','cancelled')),
  started_at timestamptz not null default now(),
  trial_ends_at timestamptz,
  current_period_start timestamptz,
  current_period_end timestamptz,
  external_customer_ref text,
  external_subscription_ref text,
  metadata jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.feature_overrides (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  feature_key text not null,
  enabled boolean not null,
  reason text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (organization_id,feature_key)
);

create table if not exists public.organization_domains (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  hostname text not null unique,
  status text not null default 'pending' check (status in ('pending','verified','active','disabled')),
  verified_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.support_sessions (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  support_user_id uuid not null references auth.users(id) on delete cascade,
  reason text not null,
  expires_at timestamptz not null,
  ended_at timestamptz,
  created_at timestamptz not null default now()
);

-- -----------------------------------------------------------------------------
-- Academic history / transfers / promotion
-- -----------------------------------------------------------------------------
create table if not exists public.student_enrollments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  academic_session_id uuid not null references public.academic_sessions(id) on delete restrict,
  class_id uuid references public.classes(id) on delete set null,
  section_id uuid references public.sections(id) on delete set null,
  roll_no text,
  started_on date not null default current_date,
  ended_on date,
  status text not null default 'active' check (status in ('active','promoted','transferred','completed','withdrawn')),
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  unique(student_id,academic_session_id)
);

create index if not exists student_enrollments_org_session_idx on public.student_enrollments(organization_id,academic_session_id,class_id,status);

-- -----------------------------------------------------------------------------
-- Finance completion: adjustments, credit allocations, refund reversals
-- -----------------------------------------------------------------------------
alter table public.payment_allocations add column if not exists refunded_minor bigint not null default 0 check (refunded_minor >= 0 and refunded_minor <= amount_minor);
alter table public.student_credits add column if not exists refunded_minor bigint not null default 0 check (refunded_minor >= 0 and refunded_minor <= amount_minor);
alter table public.refunds add column if not exists approved_at timestamptz;
alter table public.refunds add column if not exists rejected_at timestamptz;
alter table public.refunds add column if not exists rejection_reason text;

create table if not exists public.credit_allocations (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  credit_id uuid not null references public.student_credits(id) on delete restrict,
  invoice_id uuid not null references public.invoices(id) on delete restrict,
  amount_minor bigint not null check (amount_minor > 0),
  reversed_minor bigint not null default 0 check (reversed_minor >= 0 and reversed_minor <= amount_minor),
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create index if not exists credit_allocations_credit_idx on public.credit_allocations(credit_id,created_at desc);
create index if not exists credit_allocations_invoice_idx on public.credit_allocations(invoice_id);

create table if not exists public.invoice_adjustments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  invoice_id uuid not null references public.invoices(id) on delete restrict,
  student_id uuid not null references public.students(id) on delete restrict,
  kind text not null check (kind in ('discount','scholarship','concession','waiver','late_fee')),
  effect text not null check (effect in ('credit','debit')),
  amount_minor bigint not null check (amount_minor > 0),
  reason text not null,
  status text not null default 'active' check (status in ('active','reversed')),
  created_by uuid not null references auth.users(id) on delete restrict,
  reversed_by uuid references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  reversed_at timestamptz
);

create index if not exists invoice_adjustments_invoice_idx on public.invoice_adjustments(invoice_id,status);

create table if not exists public.billing_runs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  run_type text not null check (run_type in ('monthly','annual','manual','scheduled')),
  period_start date,
  academic_session_id uuid references public.academic_sessions(id) on delete set null,
  status text not null default 'completed' check (status in ('preview','running','completed','failed')),
  created_count int not null default 0,
  skipped_count int not null default 0,
  error_count int not null default 0,
  details jsonb not null default '{}'::jsonb,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

-- -----------------------------------------------------------------------------
-- Cashier control and reconciliation
-- -----------------------------------------------------------------------------
create table if not exists public.cashier_shifts (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  cashier_id uuid not null references auth.users(id) on delete restrict,
  opened_at timestamptz not null default now(),
  closed_at timestamptz,
  opening_cash_minor bigint not null default 0 check (opening_cash_minor >= 0),
  expected_cash_minor bigint,
  counted_cash_minor bigint,
  variance_minor bigint,
  status text not null default 'open' check (status in ('open','closed')),
  opening_notes text,
  closing_notes text
);

create unique index if not exists cashier_one_open_shift on public.cashier_shifts(organization_id,cashier_id) where status='open';

create table if not exists public.bank_deposits (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  business_date date not null,
  amount_minor bigint not null check (amount_minor > 0),
  bank_name text,
  reference text,
  deposited_at timestamptz not null default now(),
  created_by uuid not null references auth.users(id) on delete restrict,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.reconciliation_runs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  business_date date not null,
  cash_collected_minor bigint not null default 0,
  noncash_collected_minor bigint not null default 0,
  refunds_minor bigint not null default 0,
  deposited_minor bigint not null default 0,
  variance_minor bigint not null default 0,
  status text not null default 'open' check (status in ('open','balanced','review')),
  reviewed_by uuid references auth.users(id) on delete set null,
  notes text,
  created_at timestamptz not null default now(),
  unique(organization_id,business_date)
);

-- -----------------------------------------------------------------------------
-- Notifications / outbox
-- -----------------------------------------------------------------------------
create table if not exists public.notification_channels (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  channel text not null check (channel in ('sms','whatsapp','email','webhook')),
  provider text not null,
  enabled boolean not null default false,
  sender_id text,
  vault_secret_name text,
  settings jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(organization_id,channel)
);

create table if not exists public.notification_queue (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  student_id uuid references public.students(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  channel text not null check (channel in ('sms','whatsapp','email','in_app','webhook')),
  destination text,
  template_key text not null,
  subject text,
  body text not null,
  payload jsonb not null default '{}'::jsonb,
  dedupe_key text,
  status text not null default 'pending' check (status in ('pending','processing','sent','failed','cancelled')),
  attempts int not null default 0,
  next_attempt_at timestamptz not null default now(),
  sent_at timestamptz,
  last_error text,
  created_at timestamptz not null default now(),
  unique(organization_id,dedupe_key)
);

create index if not exists notification_queue_dispatch_idx on public.notification_queue(status,next_attempt_at,created_at);

-- -----------------------------------------------------------------------------
-- Bulk import / exports / tenant lifecycle
-- -----------------------------------------------------------------------------
create table if not exists public.import_jobs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  kind text not null check (kind in ('students','opening_balances','payments','fee_structures')),
  filename text,
  status text not null default 'preview' check (status in ('preview','validated','importing','completed','failed')),
  total_rows int not null default 0,
  valid_rows int not null default 0,
  invalid_rows int not null default 0,
  errors jsonb not null default '[]'::jsonb,
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  completed_at timestamptz
);

create table if not exists public.tenant_export_jobs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  status text not null default 'queued' check (status in ('queued','processing','completed','failed','expired')),
  storage_path text,
  requested_by uuid not null references auth.users(id) on delete restrict,
  requested_at timestamptz not null default now(),
  completed_at timestamptz,
  expires_at timestamptz,
  error text
);

create table if not exists public.tenant_deletion_requests (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  requested_by uuid not null references auth.users(id) on delete restrict,
  reason text not null,
  status text not null default 'pending' check (status in ('pending','approved','executed','cancelled')),
  execute_after timestamptz not null default (now() + interval '14 days'),
  approved_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

-- Seed commercial plans without overriding custom edits.
insert into public.plans(id,name,price_minor,billing_period,student_limit,staff_limit,features) values
('starter','Starter',0,'month',300,8,'{"student_portal":true,"notifications":false,"custom_domain":false,"advanced_reports":false}'::jsonb),
('growth','Growth',0,'month',1000,30,'{"student_portal":true,"notifications":true,"custom_domain":false,"advanced_reports":true}'::jsonb),
('pro','Pro',0,'month',null,null,'{"student_portal":true,"notifications":true,"custom_domain":true,"advanced_reports":true,"api_access":true}'::jsonb)
on conflict(id) do nothing;

insert into public.subscriptions(organization_id,plan_id,status,trial_ends_at,current_period_start,current_period_end)
select o.id,case when exists(select 1 from public.plans p where p.id=o.plan) then o.plan else 'growth' end,'trialing',now()+interval '30 days',now(),now()+interval '30 days'
from public.organizations o
on conflict(organization_id) do nothing;

-- -----------------------------------------------------------------------------
-- Security helpers
-- -----------------------------------------------------------------------------
create or replace function private.is_platform_admin(p_roles text[] default null)
returns boolean language sql stable security definer set search_path=public,private as $$
  select exists(
    select 1 from public.platform_admins p
    where p.user_id=(select auth.uid()) and p.active
      and (p_roles is null or p.role=any(p_roles))
  );
$$;
revoke all on function private.is_platform_admin(text[]) from public;
grant execute on function private.is_platform_admin(text[]) to authenticated;

-- Add explicit, audited read-only support access. Existing role-specific write policies
-- remain membership-based and therefore do not grant support users financial mutation rights.
create or replace function private.user_has_org_access(p_org uuid,p_roles text[] default null)
returns boolean language sql stable security definer set search_path=public,private as $$
  select
    exists(
      select 1 from public.organization_memberships m
      where m.organization_id=p_org and m.user_id=(select auth.uid()) and m.active
        and (p_roles is null or m.role=any(p_roles))
    )
    or (
      p_roles is null
      and private.is_platform_admin(array['platform_support','platform_owner'])
      and exists(
        select 1 from public.support_sessions s
        where s.organization_id=p_org and s.support_user_id=(select auth.uid())
          and s.ended_at is null and s.expires_at>now()
      )
    );
$$;

create or replace function private.org_feature_enabled(p_org uuid,p_feature text)
returns boolean language sql stable security definer set search_path=public,private as $$
  select coalesce(
    (select fo.enabled from public.feature_overrides fo where fo.organization_id=p_org and fo.feature_key=p_feature),
    (select coalesce((pl.features->>p_feature)::boolean,false)
       from public.subscriptions s join public.plans pl on pl.id=s.plan_id
      where s.organization_id=p_org and s.status in ('trialing','active')
        and (s.status='active' or s.trial_ends_at is null or s.trial_ends_at>now())),
    false
  );
$$;
revoke all on function private.org_feature_enabled(uuid,text) from public;
grant execute on function private.org_feature_enabled(uuid,text) to authenticated;

-- -----------------------------------------------------------------------------
-- RLS for new tables
-- -----------------------------------------------------------------------------
alter table public.platform_admins enable row level security;
alter table public.plans enable row level security;
alter table public.subscriptions enable row level security;
alter table public.feature_overrides enable row level security;
alter table public.organization_domains enable row level security;
alter table public.support_sessions enable row level security;
alter table public.student_enrollments enable row level security;
alter table public.credit_allocations enable row level security;
alter table public.invoice_adjustments enable row level security;
alter table public.billing_runs enable row level security;
alter table public.cashier_shifts enable row level security;
alter table public.bank_deposits enable row level security;
alter table public.reconciliation_runs enable row level security;
alter table public.notification_channels enable row level security;
alter table public.notification_queue enable row level security;
alter table public.import_jobs enable row level security;
alter table public.tenant_export_jobs enable row level security;
alter table public.tenant_deletion_requests enable row level security;

create policy platform_self_read on public.platform_admins for select to authenticated using(user_id=(select auth.uid()));
create policy plans_authenticated_read on public.plans for select to authenticated using(active or private.is_platform_admin());
create policy plans_platform_write on public.plans for all to authenticated using(private.is_platform_admin(array['platform_owner','platform_billing'])) with check(private.is_platform_admin(array['platform_owner','platform_billing']));
create policy subscription_tenant_read on public.subscriptions for select to authenticated using(private.user_has_org_access(organization_id) or private.is_platform_admin());
create policy subscription_platform_write on public.subscriptions for all to authenticated using(private.is_platform_admin(array['platform_owner','platform_billing'])) with check(private.is_platform_admin(array['platform_owner','platform_billing']));
create policy overrides_tenant_read on public.feature_overrides for select to authenticated using(private.user_has_org_access(organization_id) or private.is_platform_admin());
create policy overrides_platform_write on public.feature_overrides for all to authenticated using(private.is_platform_admin(array['platform_owner','platform_billing'])) with check(private.is_platform_admin(array['platform_owner','platform_billing']));
create policy domains_read on public.organization_domains for select to authenticated using(private.user_has_org_access(organization_id) or private.is_platform_admin());
create policy domains_write on public.organization_domains for all to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin']) or private.is_platform_admin(array['platform_owner'])) with check(private.user_has_org_access(organization_id,array['owner','super_admin']) or private.is_platform_admin(array['platform_owner']));
create policy support_sessions_read on public.support_sessions for select to authenticated using(support_user_id=(select auth.uid()) or private.user_has_org_access(organization_id,array['owner','super_admin']) or private.is_platform_admin(array['platform_owner']));
create policy support_sessions_platform_write on public.support_sessions for all to authenticated using(private.is_platform_admin(array['platform_owner','platform_support'])) with check(private.is_platform_admin(array['platform_owner','platform_support']));

create policy enrollments_read on public.student_enrollments for select to authenticated using(private.user_can_access_student(student_id));
create policy enrollments_write on public.student_enrollments for all to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin','admin'])) with check(private.user_has_org_access(organization_id,array['owner','super_admin','admin']));
create policy credit_allocations_read on public.credit_allocations for select to authenticated using(exists(select 1 from public.student_credits c where c.id=credit_id and private.user_can_access_student(c.student_id)));
create policy adjustments_read on public.invoice_adjustments for select to authenticated using(private.user_can_access_student(student_id));
create policy billing_runs_read on public.billing_runs for select to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant','auditor']));
create policy shifts_read on public.cashier_shifts for select to authenticated using(cashier_id=(select auth.uid()) or private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant','auditor']));
create policy deposits_read on public.bank_deposits for select to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant','auditor']));
create policy deposits_write on public.bank_deposits for all to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin','accountant'])) with check(private.user_has_org_access(organization_id,array['owner','super_admin','accountant']));
create policy reconciliation_read on public.reconciliation_runs for select to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant','auditor']));
create policy reconciliation_write on public.reconciliation_runs for all to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin','accountant'])) with check(private.user_has_org_access(organization_id,array['owner','super_admin','accountant']));
create policy channels_read on public.notification_channels for select to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin','admin']));
create policy channels_write on public.notification_channels for all to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin'])) with check(private.user_has_org_access(organization_id,array['owner','super_admin']));
create policy queue_read on public.notification_queue for select to authenticated using(user_id=(select auth.uid()) or private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant','auditor']));
create policy imports_read on public.import_jobs for select to authenticated using(private.user_has_org_access(organization_id,array['owner','super_admin','admin','accountant','auditor']));
create policy exports_read on public.tenant_export_jobs for select to authenticated using(requested_by=(select auth.uid()) or private.user_has_org_access(organization_id,array['owner','super_admin']) or private.is_platform_admin());
create policy deletion_read on public.tenant_deletion_requests for select to authenticated using(private.user_has_org_access(organization_id,array['owner']) or private.is_platform_admin(array['platform_owner']));

-- Allow platform users to list organizations without implicitly granting tenant data access.
create policy org_platform_read on public.organizations for select to authenticated using(private.is_platform_admin());
create policy org_platform_update on public.organizations for update to authenticated using(private.is_platform_admin(array['platform_owner'])) with check(private.is_platform_admin(array['platform_owner']));

-- Explicit Data API grants. Mutation on controlled finance tables remains RPC-only.
grant select on public.platform_admins,public.plans,public.subscriptions,public.feature_overrides,public.organization_domains,public.support_sessions,
  public.student_enrollments,public.credit_allocations,public.invoice_adjustments,public.billing_runs,public.cashier_shifts,public.bank_deposits,
  public.reconciliation_runs,public.notification_channels,public.notification_queue,public.import_jobs,public.tenant_export_jobs,public.tenant_deletion_requests to authenticated;
grant insert,update on public.organization_domains,public.student_enrollments,public.bank_deposits,public.reconciliation_runs,public.notification_channels to authenticated;
grant insert,update,delete on public.plans,public.subscriptions,public.feature_overrides,public.support_sessions to authenticated;
revoke insert,update,delete on public.credit_allocations,public.invoice_adjustments,public.billing_runs,public.cashier_shifts,public.notification_queue,public.import_jobs,public.tenant_export_jobs,public.tenant_deletion_requests from anon,authenticated;

-- -----------------------------------------------------------------------------
-- Platform views
-- -----------------------------------------------------------------------------
create or replace view public.v_my_platform_role with (security_invoker=true) as
select p.user_id,p.role from public.platform_admins p where p.user_id=(select auth.uid()) and p.active;
grant select on public.v_my_platform_role to authenticated;

create or replace view public.v_platform_tenants with (security_invoker=true) as
select o.id,o.name,o.slug,o.status,o.plan,o.currency,o.timezone,o.created_at,
       s.status subscription_status,s.plan_id,s.trial_ends_at,s.current_period_end,
       (select count(*) from public.students st where st.organization_id=o.id and st.status='active') active_students,
       (select count(*) from public.organization_memberships m where m.organization_id=o.id and m.active) active_staff
from public.organizations o
left join public.subscriptions s on s.organization_id=o.id
where private.is_platform_admin();
grant select on public.v_platform_tenants to authenticated;

-- -----------------------------------------------------------------------------
-- Accounting helpers
-- -----------------------------------------------------------------------------
create or replace function private.recompute_invoice_status(p_invoice uuid)
returns void language plpgsql security definer set search_path=public,private as $$
declare total_due bigint; paid bigint;
begin
  select greatest(total_minor-discount_minor,0),paid_minor into total_due,paid from public.invoices where id=p_invoice for update;
  if not found then raise exception 'Invoice not found'; end if;
  update public.invoices
     set status=case when status='void' then 'void' when paid<=0 then 'open' when paid>=total_due then 'paid' else 'partial' end,
         updated_at=now()
   where id=p_invoice;
end $$;
revoke all on function private.recompute_invoice_status(uuid) from public;

create or replace function private.consume_credit_internal(p_student uuid,p_org uuid,p_limit bigint default null,p_actor uuid default null)
returns bigint language plpgsql security definer set search_path=public,private as $$
declare remaining bigint:=coalesce(p_limit,9223372036854775807); applied bigint:=0; inv record; cred record; x bigint;
begin
  for inv in
    select id,greatest(total_minor-discount_minor-paid_minor,0) due
      from public.invoices
     where organization_id=p_org and student_id=p_student and status in ('open','partial')
     order by due_date,id for update
  loop
    exit when remaining<=0;
    for cred in
      select id,remaining_minor from public.student_credits
       where organization_id=p_org and student_id=p_student and remaining_minor>0
       order by created_at,id for update
    loop
      exit when remaining<=0 or inv.due<=0;
      x:=least(inv.due,cred.remaining_minor,remaining);
      if x<=0 then continue; end if;
      insert into public.credit_allocations(organization_id,credit_id,invoice_id,amount_minor,created_by)
      values(p_org,cred.id,inv.id,x,p_actor);
      update public.student_credits set remaining_minor=remaining_minor-x where id=cred.id;
      update public.invoices set paid_minor=paid_minor+x,updated_at=now() where id=inv.id;
      inv.due:=inv.due-x; remaining:=remaining-x; applied:=applied+x;
      perform private.recompute_invoice_status(inv.id);
    end loop;
  end loop;
  return applied;
end $$;
revoke all on function private.consume_credit_internal(uuid,uuid,bigint,uuid) from public;

create or replace function public.apply_student_credit(p_student_id uuid,p_amount_minor bigint default null)
returns jsonb language plpgsql security definer set search_path=public,private as $$
declare org uuid; available bigint; applied bigint;
begin
  if (select auth.uid()) is null then raise exception 'Authentication required'; end if;
  select organization_id into org from public.students where id=p_student_id and status='active';
  if org is null then raise exception 'Student not found'; end if;
  if not private.user_has_org_access(org,array['owner','super_admin','cashier','accountant']) then raise exception 'Not authorized'; end if;
  select coalesce(sum(remaining_minor),0) into available from public.student_credits where organization_id=org and student_id=p_student_id;
  if p_amount_minor is not null and p_amount_minor<=0 then raise exception 'Amount must be positive'; end if;
  applied:=private.consume_credit_internal(p_student_id,org,least(coalesce(p_amount_minor,available),available),(select auth.uid()));
  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,after_data)
  values(org,(select auth.uid()),'credit.applied','student',p_student_id::text,jsonb_build_object('applied_minor',applied));
  return jsonb_build_object('applied_minor',applied,'remaining_credit_minor',greatest(available-applied,0));
end $$;
revoke all on function public.apply_student_credit(uuid,bigint) from public,anon;
grant execute on function public.apply_student_credit(uuid,bigint) to authenticated;

create or replace function public.request_refund(p_payment_id uuid,p_amount_minor bigint,p_reason text)
returns jsonb language plpgsql security definer set search_path=public,private as $$
declare p public.payments%rowtype; already bigint; rid uuid; rno text;
begin
  if (select auth.uid()) is null then raise exception 'Authentication required'; end if;
  select * into p from public.payments where id=p_payment_id and status='posted' for update;
  if not found then raise exception 'Posted payment not found'; end if;
  if not private.user_has_org_access(p.organization_id,array['owner','super_admin','cashier','accountant']) then raise exception 'Not authorized'; end if;
  if p_amount_minor<=0 then raise exception 'Refund amount must be positive'; end if;
  if length(trim(coalesce(p_reason,'')))<4 then raise exception 'Refund reason is required'; end if;
  select coalesce(sum(amount_minor),0) into already from public.refunds where payment_id=p_payment_id and status in ('pending','posted');
  if already+p_amount_minor>p.amount_minor then raise exception 'Refund exceeds refundable payment balance'; end if;
  rno:='RF-'||p.receipt_no||'-'||to_char(clock_timestamp(),'HH24MISS');
  insert into public.refunds(organization_id,payment_id,refund_no,amount_minor,reason,status,created_by)
  values(p.organization_id,p_payment_id,rno,p_amount_minor,p_reason,'pending',(select auth.uid())) returning id into rid;
  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,after_data)
  values(p.organization_id,(select auth.uid()),'refund.requested','refund',rid::text,jsonb_build_object('payment_id',p_payment_id,'amount_minor',p_amount_minor,'reason',p_reason));
  return jsonb_build_object('refund_id',rid,'refund_no',rno,'status','pending');
end $$;
revoke all on function public.request_refund(uuid,bigint,text) from public,anon;
grant execute on function public.request_refund(uuid,bigint,text) to authenticated;

create or replace function public.approve_refund(p_refund_id uuid)
returns jsonb language plpgsql security definer set search_path=public,private as $$
declare r public.refunds%rowtype; p public.payments%rowtype; remaining bigint; x bigint; c record; ca record; pa record;
begin
  if (select auth.uid()) is null then raise exception 'Authentication required'; end if;
  select * into r from public.refunds where id=p_refund_id for update;
  if not found or r.status<>'pending' then raise exception 'Pending refund not found'; end if;
  if not private.user_has_org_access(r.organization_id,array['owner','super_admin','accountant']) then raise exception 'Approval requires owner, super admin or accountant'; end if;
  if r.created_by=(select auth.uid()) then raise exception 'Four-eyes control: requester cannot approve the same refund'; end if;
  select * into p from public.payments where id=r.payment_id and status='posted' for update;
  remaining:=r.amount_minor;

  -- 1) Remove still-unspent advance generated by the payment.
  for c in select * from public.student_credits where source_payment_id=p.id and remaining_minor>0 order by created_at desc,id desc for update loop
    exit when remaining<=0;
    x:=least(remaining,c.remaining_minor);
    update public.student_credits set remaining_minor=remaining_minor-x,refunded_minor=refunded_minor+x where id=c.id;
    remaining:=remaining-x;
  end loop;

  -- 2) Reverse credit that originated from this payment and was subsequently used on invoices.
  for ca in
    select ca.*,sc.id credit_row_id from public.credit_allocations ca
    join public.student_credits sc on sc.id=ca.credit_id
    where sc.source_payment_id=p.id and ca.amount_minor>ca.reversed_minor
    order by ca.created_at desc,ca.id desc for update of ca
  loop
    exit when remaining<=0;
    x:=least(remaining,ca.amount_minor-ca.reversed_minor);
    update public.credit_allocations set reversed_minor=reversed_minor+x where id=ca.id;
    update public.student_credits set refunded_minor=refunded_minor+x where id=ca.credit_row_id;
    update public.invoices set paid_minor=greatest(paid_minor-x,0),updated_at=now() where id=ca.invoice_id;
    perform private.recompute_invoice_status(ca.invoice_id);
    remaining:=remaining-x;
  end loop;

  -- 3) Reverse direct allocations made by the original payment.
  for pa in select * from public.payment_allocations where payment_id=p.id and amount_minor>refunded_minor order by id desc for update loop
    exit when remaining<=0;
    x:=least(remaining,pa.amount_minor-pa.refunded_minor);
    update public.payment_allocations set refunded_minor=refunded_minor+x where id=pa.id;
    update public.invoices set paid_minor=greatest(paid_minor-x,0),updated_at=now() where id=pa.invoice_id;
    perform private.recompute_invoice_status(pa.invoice_id);
    remaining:=remaining-x;
  end loop;

  if remaining<>0 then raise exception 'Unable to restore ledger for full refund amount. Remaining minor units: %',remaining; end if;
  update public.refunds set status='posted',approved_by=(select auth.uid()),approved_at=now() where id=r.id;
  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,after_data)
  values(r.organization_id,(select auth.uid()),'refund.approved','refund',r.id::text,jsonb_build_object('payment_id',r.payment_id,'amount_minor',r.amount_minor));
  return jsonb_build_object('refund_id',r.id,'refund_no',r.refund_no,'status','posted','amount_minor',r.amount_minor);
end $$;
revoke all on function public.approve_refund(uuid) from public,anon;
grant execute on function public.approve_refund(uuid) to authenticated;

create or replace function public.reject_refund(p_refund_id uuid,p_reason text)
returns jsonb language plpgsql security definer set search_path=public,private as $$
declare r public.refunds%rowtype;
begin
  if (select auth.uid()) is null then raise exception 'Authentication required'; end if;
  select * into r from public.refunds where id=p_refund_id for update;
  if not found or r.status<>'pending' then raise exception 'Pending refund not found'; end if;
  if not private.user_has_org_access(r.organization_id,array['owner','super_admin','accountant']) then raise exception 'Not authorized'; end if;
  update public.refunds set status='rejected',approved_by=(select auth.uid()),rejected_at=now(),rejection_reason=p_reason where id=r.id;
  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,after_data)
  values(r.organization_id,(select auth.uid()),'refund.rejected','refund',r.id::text,jsonb_build_object('reason',p_reason));
  return jsonb_build_object('refund_id',r.id,'status','rejected');
end $$;
revoke all on function public.reject_refund(uuid,text) from public,anon;
grant execute on function public.reject_refund(uuid,text) to authenticated;

create or replace function public.create_invoice_adjustment(p_invoice_id uuid,p_kind text,p_amount_minor bigint,p_reason text)
returns jsonb language plpgsql security definer set search_path=public,private as $$
declare i public.invoices%rowtype; effect text; aid uuid; new_payable bigint;
begin
  if (select auth.uid()) is null then raise exception 'Authentication required'; end if;
  select * into i from public.invoices where id=p_invoice_id and status<>'void' for update;
  if not found then raise exception 'Invoice not found'; end if;
  if not private.user_has_org_access(i.organization_id,array['owner','super_admin','admin','accountant']) then raise exception 'Not authorized'; end if;
  if p_kind not in ('discount','scholarship','concession','waiver','late_fee') then raise exception 'Invalid adjustment type'; end if;
  if p_amount_minor<=0 or length(trim(coalesce(p_reason,'')))<3 then raise exception 'Amount and reason are required'; end if;
  effect:=case when p_kind='late_fee' then 'debit' else 'credit' end;
  if effect='credit' then
    new_payable:=i.total_minor-(i.discount_minor+p_amount_minor);
    if new_payable<0 then raise exception 'Adjustment exceeds invoice total'; end if;
    if new_payable<i.paid_minor then raise exception 'Adjustment would create an overpayment. Refund/reallocate payment first.'; end if;
    update public.invoices set discount_minor=discount_minor+p_amount_minor,updated_at=now() where id=i.id;
  else
    update public.invoices set total_minor=total_minor+p_amount_minor,updated_at=now() where id=i.id;
  end if;
  insert into public.invoice_adjustments(organization_id,invoice_id,student_id,kind,effect,amount_minor,reason,created_by)
  values(i.organization_id,i.id,i.student_id,p_kind,effect,p_amount_minor,p_reason,(select auth.uid())) returning id into aid;
  perform private.recompute_invoice_status(i.id);
  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,after_data)
  values(i.organization_id,(select auth.uid()),'invoice.adjusted','invoice_adjustment',aid::text,jsonb_build_object('invoice_id',i.id,'kind',p_kind,'amount_minor',p_amount_minor,'reason',p_reason));
  return jsonb_build_object('adjustment_id',aid,'invoice_id',i.id,'kind',p_kind,'amount_minor',p_amount_minor);
end $$;
revoke all on function public.create_invoice_adjustment(uuid,text,bigint,text) from public,anon;
grant execute on function public.create_invoice_adjustment(uuid,text,bigint,text) to authenticated;

-- -----------------------------------------------------------------------------
-- Cashier workflow RPCs
-- -----------------------------------------------------------------------------
create or replace function public.open_cashier_shift(p_opening_cash_minor bigint default 0,p_notes text default null)
returns jsonb language plpgsql security definer set search_path=public,private as $$
declare org uuid; sid uuid;
begin
  select organization_id into org from public.organization_memberships
   where user_id=(select auth.uid()) and active and role in ('owner','super_admin','cashier','accountant') order by created_at limit 1;
  if org is null then raise exception 'Authorized cashier organization not found'; end if;
  if p_opening_cash_minor<0 then raise exception 'Opening cash cannot be negative'; end if;
  insert into public.cashier_shifts(organization_id,cashier_id,opening_cash_minor,opening_notes)
  values(org,(select auth.uid()),p_opening_cash_minor,p_notes) returning id into sid;
  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,after_data)
  values(org,(select auth.uid()),'cashier.shift.opened','cashier_shift',sid::text,jsonb_build_object('opening_cash_minor',p_opening_cash_minor));
  return jsonb_build_object('shift_id',sid,'status','open');
end $$;
revoke all on function public.open_cashier_shift(bigint,text) from public,anon;
grant execute on function public.open_cashier_shift(bigint,text) to authenticated;

create or replace function public.close_cashier_shift(p_shift_id uuid,p_counted_cash_minor bigint,p_notes text default null)
returns jsonb language plpgsql security definer set search_path=public,private as $$
declare sh public.cashier_shifts%rowtype; cash_in bigint; cash_refunds bigint; expected bigint; variance bigint;
begin
  select * into sh from public.cashier_shifts where id=p_shift_id and status='open' for update;
  if not found then raise exception 'Open shift not found'; end if;
  if sh.cashier_id<>(select auth.uid()) and not private.user_has_org_access(sh.organization_id,array['owner','super_admin','accountant']) then raise exception 'Not authorized'; end if;
  if p_counted_cash_minor<0 then raise exception 'Counted cash cannot be negative'; end if;
  select coalesce(sum(amount_minor),0) into cash_in from public.payments
   where organization_id=sh.organization_id and created_by=sh.cashier_id and payment_method='cash' and status='posted' and received_at between sh.opened_at and now();
  select coalesce(sum(r.amount_minor),0) into cash_refunds from public.refunds r join public.payments p on p.id=r.payment_id
   where r.organization_id=sh.organization_id and r.status='posted' and p.payment_method='cash' and r.approved_at between sh.opened_at and now();
  expected:=sh.opening_cash_minor+cash_in-cash_refunds;
  variance:=p_counted_cash_minor-expected;
  update public.cashier_shifts set status='closed',closed_at=now(),expected_cash_minor=expected,counted_cash_minor=p_counted_cash_minor,variance_minor=variance,closing_notes=p_notes where id=sh.id;
  insert into public.daily_closings(organization_id,business_date,cashier_id,gross_minor,refunds_minor,net_minor,notes)
  values(sh.organization_id,current_date,sh.cashier_id,cash_in,cash_refunds,cash_in-cash_refunds,p_notes)
  on conflict(organization_id,business_date,cashier_id) do update set gross_minor=excluded.gross_minor,refunds_minor=excluded.refunds_minor,net_minor=excluded.net_minor,notes=excluded.notes,closed_at=now();
  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,after_data)
  values(sh.organization_id,(select auth.uid()),'cashier.shift.closed','cashier_shift',sh.id::text,jsonb_build_object('expected_minor',expected,'counted_minor',p_counted_cash_minor,'variance_minor',variance));
  return jsonb_build_object('shift_id',sh.id,'expected_cash_minor',expected,'counted_cash_minor',p_counted_cash_minor,'variance_minor',variance,'status','closed');
end $$;
revoke all on function public.close_cashier_shift(uuid,bigint,text) from public,anon;
grant execute on function public.close_cashier_shift(uuid,bigint,text) to authenticated;

-- -----------------------------------------------------------------------------
-- Academic promotion / transfer
-- -----------------------------------------------------------------------------
create or replace function public.promote_students(p_student_ids uuid[],p_session_id uuid,p_class_id uuid,p_section_id uuid default null,p_started_on date default current_date)
returns jsonb language plpgsql security definer set search_path=public,private as $$
declare org uuid; sid uuid; count_done int:=0; old_session uuid;
begin
  if coalesce(array_length(p_student_ids,1),0)=0 then raise exception 'No students selected'; end if;
  select organization_id into org from public.academic_sessions where id=p_session_id;
  if org is null then raise exception 'Target session not found'; end if;
  if not private.user_has_org_access(org,array['owner','super_admin','admin']) then raise exception 'Not authorized'; end if;
  if not exists(select 1 from public.classes where id=p_class_id and organization_id=org) then raise exception 'Target class is invalid'; end if;
  if p_section_id is not null and not exists(select 1 from public.sections where id=p_section_id and organization_id=org and class_id=p_class_id) then raise exception 'Target section is invalid'; end if;

  foreach sid in array p_student_ids loop
    if not exists(select 1 from public.students where id=sid and organization_id=org and status='active') then continue; end if;
    update public.student_enrollments set ended_on=p_started_on-1,status='promoted'
      where student_id=sid and organization_id=org and status='active';
    insert into public.student_enrollments(organization_id,student_id,academic_session_id,class_id,section_id,started_on,status,created_by)
      values(org,sid,p_session_id,p_class_id,p_section_id,p_started_on,'active',(select auth.uid()))
      on conflict(student_id,academic_session_id) do update set class_id=excluded.class_id,section_id=excluded.section_id,started_on=excluded.started_on,ended_on=null,status='active';
    update public.students set class_id=p_class_id,section_id=p_section_id where id=sid;
    count_done:=count_done+1;
  end loop;
  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,after_data)
  values(org,(select auth.uid()),'students.promoted','academic_session',p_session_id::text,jsonb_build_object('count',count_done,'class_id',p_class_id,'section_id',p_section_id));
  return jsonb_build_object('promoted',count_done,'session_id',p_session_id,'class_id',p_class_id,'section_id',p_section_id);
end $$;
revoke all on function public.promote_students(uuid[],uuid,uuid,uuid,date) from public,anon;
grant execute on function public.promote_students(uuid[],uuid,uuid,uuid,date) to authenticated;

-- -----------------------------------------------------------------------------
-- Billing helpers: annual fee and system credit application
-- -----------------------------------------------------------------------------
create or replace function public.generate_annual_invoices(p_session_id uuid)
returns jsonb language plpgsql security definer set search_path=public,private as $$
declare org uuid; created_count int:=0; skipped int:=0; s record; fs record; inv_id uuid; inv_no text;
begin
  select organization_id into org from public.academic_sessions where id=p_session_id;
  if org is null then raise exception 'Academic session not found'; end if;
  if not private.user_has_org_access(org,array['owner','super_admin','admin','accountant']) then raise exception 'Not authorized'; end if;
  for s in select * from public.students where organization_id=org and status='active' loop
    for fs in
      select fs.*,fc.code,fc.name from public.fee_structures fs join public.fee_categories fc on fc.id=fs.fee_category_id
      where fs.organization_id=org and fs.academic_session_id=p_session_id and fs.active and fc.frequency='annual'
        and (fs.class_id=s.class_id or fs.class_id is null)
      order by fs.class_id nulls last
    loop
      if exists(
        select 1 from public.invoices i join public.invoice_items ii on ii.invoice_id=i.id
        where i.organization_id=org and i.student_id=s.id and i.academic_session_id=p_session_id and ii.fee_category_id=fs.fee_category_id and i.status<>'void'
      ) then skipped:=skipped+1; continue; end if;
      inv_no:='ANN-'||replace((select name from public.academic_sessions where id=p_session_id),' ','')||'-'||fs.code||'-'||s.admission_no;
      insert into public.invoices(organization_id,student_id,academic_session_id,invoice_no,invoice_month,issue_date,due_date,total_minor,status,created_by)
      values(org,s.id,p_session_id,inv_no,null,current_date,current_date+(fs.due_day-1),fs.amount_minor,'open',(select auth.uid())) returning id into inv_id;
      insert into public.invoice_items(organization_id,invoice_id,fee_category_id,description,quantity,unit_amount_minor,total_amount_minor)
      values(org,inv_id,fs.fee_category_id,fs.name,1,fs.amount_minor,fs.amount_minor);
      perform private.consume_credit_internal(s.id,org,null,(select auth.uid()));
      created_count:=created_count+1;
    end loop;
  end loop;
  insert into public.billing_runs(organization_id,run_type,academic_session_id,status,created_count,skipped_count,created_by)
  values(org,'annual',p_session_id,'completed',created_count,skipped,(select auth.uid()));
  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,after_data)
  values(org,(select auth.uid()),'billing.annual.generated','academic_session',p_session_id::text,jsonb_build_object('created',created_count,'skipped',skipped));
  return jsonb_build_object('created',created_count,'skipped',skipped,'session_id',p_session_id);
end $$;
revoke all on function public.generate_annual_invoices(uuid) from public,anon;
grant execute on function public.generate_annual_invoices(uuid) to authenticated;

-- Scheduled monthly invoicing runs without a user JWT. Function is private and executable only by postgres/service role.
create or replace function private.system_generate_monthly_invoices(p_month date)
returns jsonb language plpgsql security definer set search_path=public,private as $$
declare orgrec record; s record; fee bigint; due_day int; inv_id uuid; session_id uuid; created_total int:=0; created_org int; month_start date:=date_trunc('month',p_month)::date;
begin
  for orgrec in select id from public.organizations where status='active' loop
    created_org:=0;
    select id into session_id from public.academic_sessions where organization_id=orgrec.id and active limit 1;
    if session_id is null then continue; end if;
    for s in select * from public.students where organization_id=orgrec.id and status='active' loop
      select fs.amount_minor,fs.due_day into fee,due_day
      from public.fee_structures fs join public.fee_categories fc on fc.id=fs.fee_category_id
      where fs.organization_id=orgrec.id and fs.academic_session_id=session_id and fs.active and fc.frequency='monthly'
        and (fs.class_id=s.class_id or fs.class_id is null)
      order by fs.class_id nulls last limit 1;
      if fee is null or exists(select 1 from public.invoices where organization_id=orgrec.id and student_id=s.id and invoice_month=month_start and status<>'void') then continue; end if;
      insert into public.invoices(organization_id,student_id,academic_session_id,invoice_no,invoice_month,issue_date,due_date,total_minor,status,created_by)
      values(orgrec.id,s.id,session_id,'INV-'||to_char(month_start,'YYYYMM')||'-'||s.admission_no,month_start,month_start,month_start+(greatest(due_day,1)-1),fee,'open',null) returning id into inv_id;
      insert into public.invoice_items(organization_id,invoice_id,fee_category_id,description,quantity,unit_amount_minor,total_amount_minor)
      select orgrec.id,inv_id,fc.id,to_char(month_start,'Mon YYYY')||' '||fc.name,1,fee,fee from public.fee_categories fc where fc.organization_id=orgrec.id and fc.frequency='monthly' order by case when fc.code='MONTHLY' then 0 else 1 end limit 1;
      perform private.consume_credit_internal(s.id,orgrec.id,null,null);
      created_org:=created_org+1; created_total:=created_total+1;
    end loop;
    insert into public.billing_runs(organization_id,run_type,period_start,academic_session_id,status,created_count,created_by)
    values(orgrec.id,'scheduled',month_start,session_id,'completed',created_org,null);
  end loop;
  return jsonb_build_object('month',month_start,'created',created_total);
end $$;
revoke all on function private.system_generate_monthly_invoices(date) from public,anon,authenticated;
grant execute on function private.system_generate_monthly_invoices(date) to service_role;

-- -----------------------------------------------------------------------------
-- Defaulter queue. Current-month monthly fee notices begin after due day / day 8.
-- -----------------------------------------------------------------------------
create or replace function private.queue_defaulter_notifications(p_as_of date default current_date)
returns bigint language plpgsql security definer set search_path=public,private as $$
declare d record; queued bigint:=0; key text; msg text;
begin
  if extract(day from p_as_of)<8 then return 0; end if;
  for d in
    select s.id student_id,s.organization_id,s.full_name,s.guardian_phone,s.guardian_email,
           sum(greatest(i.total_minor-i.discount_minor-i.paid_minor,0))::bigint due_minor
    from public.students s join public.invoices i on i.student_id=s.id and i.organization_id=s.organization_id
    where s.status='active' and i.status in ('open','partial') and i.invoice_month=date_trunc('month',p_as_of)::date and i.due_date<=p_as_of
    group by s.id,s.organization_id,s.full_name,s.guardian_phone,s.guardian_email
  loop
    msg:=d.full_name||' has PKR '||to_char(d.due_minor/100.0,'FM999G999G999G990D00')||' pending for '||to_char(p_as_of,'Mon YYYY')||'.';
    key:='defaulter:'||to_char(p_as_of,'YYYY-MM')||':'||d.student_id::text||':in_app';
    insert into public.notification_queue(organization_id,student_id,channel,template_key,body,payload,dedupe_key)
    values(d.organization_id,d.student_id,'in_app','monthly_defaulter',msg,jsonb_build_object('due_minor',d.due_minor,'month',to_char(p_as_of,'YYYY-MM')),key)
    on conflict(organization_id,dedupe_key) do nothing;
    if found then queued:=queued+1; end if;
    if d.guardian_phone is not null then
      key:='defaulter:'||to_char(p_as_of,'YYYY-MM')||':'||d.student_id::text||':sms';
      insert into public.notification_queue(organization_id,student_id,channel,destination,template_key,body,payload,dedupe_key)
      select d.organization_id,d.student_id,'sms',d.guardian_phone,'monthly_defaulter',msg,jsonb_build_object('due_minor',d.due_minor,'month',to_char(p_as_of,'YYYY-MM')),key
      where exists(select 1 from public.notification_channels nc where nc.organization_id=d.organization_id and nc.channel='sms' and nc.enabled)
      on conflict(organization_id,dedupe_key) do nothing;
      if found then queued:=queued+1; end if;
    end if;
    if d.guardian_email is not null then
      key:='defaulter:'||to_char(p_as_of,'YYYY-MM')||':'||d.student_id::text||':email';
      insert into public.notification_queue(organization_id,student_id,channel,destination,template_key,subject,body,payload,dedupe_key)
      select d.organization_id,d.student_id,'email',d.guardian_email,'monthly_defaulter','Fee payment reminder',msg,jsonb_build_object('due_minor',d.due_minor,'month',to_char(p_as_of,'YYYY-MM')),key
      where exists(select 1 from public.notification_channels nc where nc.organization_id=d.organization_id and nc.channel='email' and nc.enabled)
      on conflict(organization_id,dedupe_key) do nothing;
      if found then queued:=queued+1; end if;
    end if;
  end loop;

  insert into public.notifications(organization_id,student_id,kind,title,body,payload)
  select q.organization_id,q.student_id,'fee_defaulter','Fee reminder',q.body,q.payload
  from public.notification_queue q
  where q.channel='in_app' and q.status='pending' and q.created_at::date=p_as_of
    and not exists(select 1 from public.notifications n where n.organization_id=q.organization_id and n.student_id=q.student_id and n.kind='fee_defaulter' and n.payload->>'month'=q.payload->>'month');
  update public.notification_queue set status='sent',sent_at=now() where channel='in_app' and status='pending';
  return queued;
end $$;
revoke all on function private.queue_defaulter_notifications(date) from public,anon,authenticated;
grant execute on function private.queue_defaulter_notifications(date) to service_role;

-- -----------------------------------------------------------------------------
-- Receipt / ledger / reconciliation views
-- -----------------------------------------------------------------------------
create or replace view public.v_receipts with (security_invoker=true) as
select p.id payment_id,p.organization_id,p.student_id,p.receipt_no,p.received_at,p.amount_minor,p.payment_method,p.reference,p.notes,p.status,
       s.admission_no,s.roll_no,s.full_name,s.guardian_name,c.name class_name,se.name section_name,
       o.name organization_name,o.receipt_prefix,o.branding,
       coalesce((select sum(r.amount_minor) from public.refunds r where r.payment_id=p.id and r.status='posted'),0)::bigint refunded_minor,
       coalesce((select sum(pa.amount_minor-pa.refunded_minor) from public.payment_allocations pa where pa.payment_id=p.id),0)::bigint allocated_minor,
       coalesce((select sum(sc.amount_minor-sc.refunded_minor) from public.student_credits sc where sc.source_payment_id=p.id),0)::bigint credit_created_minor
from public.payments p
join public.students s on s.id=p.student_id
join public.organizations o on o.id=p.organization_id
left join public.classes c on c.id=s.class_id
left join public.sections se on se.id=s.section_id;

grant select on public.v_receipts to authenticated;

create or replace view public.v_student_ledger with (security_invoker=true) as
select i.organization_id,i.student_id,i.issue_date::timestamptz occurred_at,'invoice'::text entry_type,i.id::text reference,
       i.invoice_no label,(i.total_minor-i.discount_minor)::bigint debit_minor,0::bigint credit_minor,i.status status
from public.invoices i
union all
select p.organization_id,p.student_id,p.received_at,'payment',p.id::text,p.receipt_no,0::bigint,p.amount_minor,p.status
from public.payments p
union all
select r.organization_id,p.student_id,r.created_at,'refund',r.id::text,r.refund_no,r.amount_minor,0::bigint,r.status
from public.refunds r join public.payments p on p.id=r.payment_id;

grant select on public.v_student_ledger to authenticated;

create or replace view public.v_guardian_children with (security_invoker=true) as
select g.auth_user_id,g.student_id,s.organization_id,s.admission_no,s.roll_no,s.full_name,c.name class_name,se.name section_name,
       coalesce((select sum(greatest(i.total_minor-i.discount_minor-i.paid_minor,0)) from public.invoices i where i.student_id=s.id and i.status in ('open','partial')),0)::bigint outstanding_minor,
       coalesce((select sum(sc.remaining_minor) from public.student_credits sc where sc.student_id=s.id),0)::bigint credit_minor
from public.student_guardians g join public.students s on s.id=g.student_id
left join public.classes c on c.id=s.class_id left join public.sections se on se.id=s.section_id
where g.auth_user_id=(select auth.uid());
grant select on public.v_guardian_children to authenticated;

create or replace view public.v_refund_queue with (security_invoker=true) as
select r.id,r.organization_id,r.refund_no,r.payment_id,p.receipt_no,p.student_id,s.full_name,r.amount_minor,r.reason,r.status,r.created_by,r.approved_by,r.created_at,r.approved_at,r.rejected_at,r.rejection_reason
from public.refunds r join public.payments p on p.id=r.payment_id join public.students s on s.id=p.student_id;
grant select on public.v_refund_queue to authenticated;

create or replace view public.v_cashier_today with (security_invoker=true) as
select p.organization_id,p.created_by cashier_id,
  coalesce(sum(p.amount_minor) filter(where p.payment_method='cash' and p.status='posted'),0)::bigint cash_minor,
  coalesce(sum(p.amount_minor) filter(where p.payment_method<>'cash' and p.status='posted'),0)::bigint noncash_minor,
  count(*) filter(where p.status='posted')::bigint receipt_count
from public.payments p where p.received_at::date=current_date group by p.organization_id,p.created_by;
grant select on public.v_cashier_today to authenticated;

-- Maintain updated_at for subscriptions.
create or replace function private.touch_updated_at() returns trigger language plpgsql as $$ begin new.updated_at=now(); return new; end $$;
drop trigger if exists subscriptions_touch_updated_at on public.subscriptions;
create trigger subscriptions_touch_updated_at before update on public.subscriptions for each row execute function private.touch_updated_at();
