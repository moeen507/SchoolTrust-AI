-- Timezone-aware billing and defaulter automation.
-- Supabase Cron is backed by pg_cron. The hourly tick is idempotent.

create extension if not exists pg_cron;

create or replace function private.system_generate_monthly_for_org(p_org uuid,p_month date)
returns int language plpgsql security definer set search_path=public,private as $$
declare s record; fee bigint; due_day int; fee_cat uuid; fee_name text; inv_id uuid; session_id uuid; created_count int:=0; month_start date:=date_trunc('month',p_month)::date;
begin
  select id into session_id from public.academic_sessions where organization_id=p_org and active order by starts_on desc limit 1;
  if session_id is null then return 0; end if;
  for s in select * from public.students where organization_id=p_org and status='active' loop
    select fs.amount_minor,fs.due_day,fc.id,fc.name into fee,due_day,fee_cat,fee_name
    from public.fee_structures fs join public.fee_categories fc on fc.id=fs.fee_category_id
    where fs.organization_id=p_org and fs.academic_session_id=session_id and fs.active and fc.frequency='monthly'
      and (fs.class_id=s.class_id or fs.class_id is null)
    order by fs.class_id nulls last limit 1;
    if fee is null then continue; end if;
    if exists(select 1 from public.invoices where organization_id=p_org and student_id=s.id and invoice_month=month_start and status<>'void') then continue; end if;
    insert into public.invoices(organization_id,student_id,academic_session_id,invoice_no,invoice_month,issue_date,due_date,total_minor,status,created_by)
    values(p_org,s.id,session_id,'INV-'||to_char(month_start,'YYYYMM')||'-'||s.admission_no,month_start,month_start,month_start+(greatest(due_day,1)-1),fee,'open',null)
    returning id into inv_id;
    insert into public.invoice_items(organization_id,invoice_id,fee_category_id,description,quantity,unit_amount_minor,total_amount_minor)
    values(p_org,inv_id,fee_cat,to_char(month_start,'Mon YYYY')||' '||fee_name,1,fee,fee);
    perform private.consume_credit_internal(s.id,p_org,null,null);
    created_count:=created_count+1;
  end loop;
  if created_count>0 then
    insert into public.billing_runs(organization_id,run_type,period_start,academic_session_id,status,created_count,created_by)
    values(p_org,'scheduled',month_start,session_id,'completed',created_count,null);
  end if;
  return created_count;
end $$;
revoke all on function private.system_generate_monthly_for_org(uuid,date) from public,anon,authenticated;
grant execute on function private.system_generate_monthly_for_org(uuid,date) to service_role;

create or replace function private.queue_defaulters_for_org(p_org uuid,p_as_of date)
returns int language plpgsql security definer set search_path=public,private as $$
declare d record; queued int:=0; key text; msg text;
begin
  if extract(day from p_as_of)<8 then return 0; end if;
  for d in
    select s.id student_id,s.full_name,s.guardian_phone,s.guardian_email,
           sum(greatest(i.total_minor-i.discount_minor-i.paid_minor,0))::bigint due_minor
    from public.students s join public.invoices i on i.student_id=s.id and i.organization_id=s.organization_id
    where s.organization_id=p_org and s.status='active' and i.status in ('open','partial')
      and i.invoice_month=date_trunc('month',p_as_of)::date and i.due_date<=p_as_of
    group by s.id,s.full_name,s.guardian_phone,s.guardian_email
  loop
    msg:=d.full_name||' has PKR '||to_char(d.due_minor/100.0,'FM999G999G999G990D00')||' pending for '||to_char(p_as_of,'Mon YYYY')||'.';
    key:='defaulter:'||to_char(p_as_of,'YYYY-MM')||':'||d.student_id::text||':in_app';
    insert into public.notification_queue(organization_id,student_id,channel,template_key,body,payload,dedupe_key)
    values(p_org,d.student_id,'in_app','monthly_defaulter',msg,jsonb_build_object('due_minor',d.due_minor,'month',to_char(p_as_of,'YYYY-MM')),key)
    on conflict(organization_id,dedupe_key) do nothing;
    if found then queued:=queued+1; end if;

    if d.guardian_phone is not null and exists(select 1 from public.notification_channels nc where nc.organization_id=p_org and nc.channel='sms' and nc.enabled) then
      key:='defaulter:'||to_char(p_as_of,'YYYY-MM')||':'||d.student_id::text||':sms';
      insert into public.notification_queue(organization_id,student_id,channel,destination,template_key,body,payload,dedupe_key)
      values(p_org,d.student_id,'sms',d.guardian_phone,'monthly_defaulter',msg,jsonb_build_object('due_minor',d.due_minor,'month',to_char(p_as_of,'YYYY-MM')),key)
      on conflict(organization_id,dedupe_key) do nothing;
      if found then queued:=queued+1; end if;
    end if;

    if d.guardian_email is not null and exists(select 1 from public.notification_channels nc where nc.organization_id=p_org and nc.channel='email' and nc.enabled) then
      key:='defaulter:'||to_char(p_as_of,'YYYY-MM')||':'||d.student_id::text||':email';
      insert into public.notification_queue(organization_id,student_id,channel,destination,template_key,subject,body,payload,dedupe_key)
      values(p_org,d.student_id,'email',d.guardian_email,'monthly_defaulter','Fee payment reminder',msg,jsonb_build_object('due_minor',d.due_minor,'month',to_char(p_as_of,'YYYY-MM')),key)
      on conflict(organization_id,dedupe_key) do nothing;
      if found then queued:=queued+1; end if;
    end if;
  end loop;
  return queued;
end $$;
revoke all on function private.queue_defaulters_for_org(uuid,date) from public,anon,authenticated;
grant execute on function private.queue_defaulters_for_org(uuid,date) to service_role;

create or replace function private.system_tick()
returns jsonb language plpgsql security definer set search_path=public,private as $$
declare o record; local_now timestamp; local_date date; monthly_created int:=0; queued int:=0; c int;
begin
  for o in select id,timezone from public.organizations where status='active' loop
    begin
      local_now:=timezone(coalesce(nullif(o.timezone,''),'UTC'),now());
    exception when others then
      local_now:=timezone('UTC',now());
    end;
    local_date:=local_now::date;

    -- Running hourly is safe because invoice uniqueness and billing checks make this idempotent.
    if extract(day from local_date)=1 then
      c:=private.system_generate_monthly_for_org(o.id,local_date); monthly_created:=monthly_created+c;
    end if;
    if extract(day from local_date)>=8 then
      c:=private.queue_defaulters_for_org(o.id,local_date); queued:=queued+c;
    end if;
  end loop;
  return jsonb_build_object('monthly_created',monthly_created,'notifications_queued',queued,'ran_at',now());
end $$;
revoke all on function private.system_tick() from public,anon,authenticated;
grant execute on function private.system_tick() to service_role;

-- Upsert a single hourly job. Cron timestamps are UTC, but the function handles tenant timezones.
select cron.schedule('umeed-central-hourly-tick','7 * * * *',$$select private.system_tick();$$);

-- Replace the v0.1 manual generator with the same finance engine used by automation.
create or replace function public.generate_monthly_invoices(p_month date)
returns jsonb language plpgsql security definer set search_path=public,private as $$
declare org uuid; created_count int;
begin
  if (select auth.uid()) is null then raise exception 'Authentication required'; end if;
  select organization_id into org from public.organization_memberships
   where user_id=(select auth.uid()) and active and role in ('owner','super_admin','admin','accountant') order by created_at limit 1;
  if org is null then raise exception 'Not authorized'; end if;
  created_count:=private.system_generate_monthly_for_org(org,p_month);
  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,after_data)
  values(org,(select auth.uid()),'billing.month.generated','invoice_batch',to_char(date_trunc('month',p_month),'YYYY-MM'),jsonb_build_object('created',created_count));
  return jsonb_build_object('month',date_trunc('month',p_month)::date,'created',created_count);
end $$;
revoke all on function public.generate_monthly_invoices(date) from public,anon;
grant execute on function public.generate_monthly_invoices(date) to authenticated;

create or replace function public.queue_current_defaulter_reminders()
returns jsonb language plpgsql security definer set search_path=public,private as $$
declare org uuid; tz text; local_date date; queued int;
begin
  select m.organization_id,o.timezone into org,tz
  from public.organization_memberships m join public.organizations o on o.id=m.organization_id
  where m.user_id=(select auth.uid()) and m.active and m.role in ('owner','super_admin','admin','accountant') order by m.created_at limit 1;
  if org is null then raise exception 'Not authorized'; end if;
  local_date:=timezone(coalesce(nullif(tz,''),'UTC'),now())::date;
  queued:=private.queue_defaulters_for_org(org,local_date);
  insert into public.audit_logs(organization_id,actor_id,action,entity_type,entity_id,after_data)
  values(org,(select auth.uid()),'notifications.defaulters.queued','notification_batch',to_char(local_date,'YYYY-MM-DD'),jsonb_build_object('queued',queued));
  return jsonb_build_object('queued',queued,'as_of',local_date);
end $$;
revoke all on function public.queue_current_defaulter_reminders() from public,anon;
grant execute on function public.queue_current_defaulter_reminders() to authenticated;
