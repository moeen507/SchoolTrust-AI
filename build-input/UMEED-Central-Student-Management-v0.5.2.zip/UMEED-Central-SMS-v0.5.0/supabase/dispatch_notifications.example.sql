-- Example: dispatch queued SMS/email/WhatsApp notifications every 5 minutes.
-- Run after deploying `dispatch-notifications` and storing values in Vault.
-- Do not hardcode the secret key in SQL.
--
-- One-time Vault setup (replace values in a protected SQL session):
-- select vault.create_secret('https://YOUR-PROJECT.supabase.co', 'project_url');
-- select vault.create_secret('<YOUR_SUPABASE_SECRET_KEY>', 'notification_dispatch_secret');

create extension if not exists pg_net;
create extension if not exists pg_cron;

select cron.schedule(
  'umeed-central-notification-dispatch',
  '*/5 * * * *',
  $$
  select net.http_post(
    url := (select decrypted_secret from vault.decrypted_secrets where name='project_url') || '/functions/v1/dispatch-notifications',
    headers := jsonb_build_object(
      'Content-Type','application/json',
      'apikey',(select decrypted_secret from vault.decrypted_secrets where name='notification_dispatch_secret')
    ),
    body := '{}'::jsonb
  );
  $$
);
