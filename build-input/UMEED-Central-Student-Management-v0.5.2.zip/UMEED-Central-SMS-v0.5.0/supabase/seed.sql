insert into public.organizations(id,name,slug,currency,timezone,receipt_prefix,branding)
values('11111111-1111-1111-1111-111111111111','UMEED Education System','umeed-education-system','PKR','Asia/Karachi','UES','{"primary":"#6e1e38","accent":"#d8b46b"}'::jsonb)
on conflict (id) do nothing;

insert into public.academic_sessions(id,organization_id,name,starts_on,ends_on,active)
values('22222222-2222-2222-2222-222222222222','11111111-1111-1111-1111-111111111111','2026-27','2026-04-01','2027-03-31',true)
on conflict do nothing;

insert into public.classes(id,organization_id,name,sort_order) values
('30000000-0000-0000-0000-000000000005','11111111-1111-1111-1111-111111111111','9',9),
('30000000-0000-0000-0000-000000000006','11111111-1111-1111-1111-111111111111','10',10)
on conflict do nothing;

insert into public.sections(id,organization_id,class_id,name) values
('40000000-0000-0000-0000-000000000005','11111111-1111-1111-1111-111111111111','30000000-0000-0000-0000-000000000005','A'),
('40000000-0000-0000-0000-000000000006','11111111-1111-1111-1111-111111111111','30000000-0000-0000-0000-000000000006','A')
on conflict do nothing;

insert into public.fee_categories(id,organization_id,code,name,frequency,include_in_monthly_defaulter) values
('50000000-0000-0000-0000-000000000001','11111111-1111-1111-1111-111111111111','MONTHLY','Monthly Tuition','monthly',true),
('50000000-0000-0000-0000-000000000002','11111111-1111-1111-1111-111111111111','ANNUAL_FUND','Annual Fund','annual',false)
on conflict do nothing;

insert into public.fee_structures(organization_id,academic_session_id,class_id,fee_category_id,amount_minor,due_day) values
('11111111-1111-1111-1111-111111111111','22222222-2222-2222-2222-222222222222',null,'50000000-0000-0000-0000-000000000001',200000,7),
('11111111-1111-1111-1111-111111111111','22222222-2222-2222-2222-222222222222','30000000-0000-0000-0000-000000000005','50000000-0000-0000-0000-000000000001',220000,7),
('11111111-1111-1111-1111-111111111111','22222222-2222-2222-2222-222222222222','30000000-0000-0000-0000-000000000006','50000000-0000-0000-0000-000000000001',220000,7),
('11111111-1111-1111-1111-111111111111','22222222-2222-2222-2222-222222222222',null,'50000000-0000-0000-0000-000000000002',215000,7)
on conflict do nothing;

-- Student-management demo setup introduced in v0.4.
update public.organizations
set settings = coalesce(settings,'{}'::jsonb) || '{"defaulter_day":8,"store_slip_prefix":"STU","canteen_slip_prefix":"CAN"}'::jsonb
where id='11111111-1111-1111-1111-111111111111';

insert into public.subjects(id,organization_id,code,name) values
('61000000-0000-0000-0000-000000000001','11111111-1111-1111-1111-111111111111','ENG','English'),
('61000000-0000-0000-0000-000000000002','11111111-1111-1111-1111-111111111111','URD','Urdu'),
('61000000-0000-0000-0000-000000000003','11111111-1111-1111-1111-111111111111','MATH','Mathematics'),
('61000000-0000-0000-0000-000000000004','11111111-1111-1111-1111-111111111111','BIO','Biology')
on conflict do nothing;

insert into public.catalog_items(id,organization_id,sku,name,category,sale_channel,unit_price_minor,stock_quantity) values
('62000000-0000-0000-0000-000000000001','11111111-1111-1111-1111-111111111111','BK-ENG-09','English Book Grade 9','Books','student_store',85000,50),
('62000000-0000-0000-0000-000000000002','11111111-1111-1111-1111-111111111111','ST-FCARD','Student Fee Card','Student stationery','student_store',15000,200),
('62000000-0000-0000-0000-000000000003','11111111-1111-1111-1111-111111111111','ST-ENV','School Envelope','Student stationery','student_store',5000,400),
('62000000-0000-0000-0000-000000000004','11111111-1111-1111-1111-111111111111','CAN-JUICE','Juice','Drinks','canteen',8000,80),
('62000000-0000-0000-0000-000000000005','11111111-1111-1111-1111-111111111111','CAN-SAND','Sandwich','Food','canteen',18000,40)
on conflict do nothing;

insert into public.grading_scales(organization_id,min_percentage,max_percentage,grade,remark,sort_order) values
('11111111-1111-1111-1111-111111111111',80,100,'A+','Outstanding',1),
('11111111-1111-1111-1111-111111111111',70,79.99,'A','Excellent',2),
('11111111-1111-1111-1111-111111111111',60,69.99,'B','Very Good',3),
('11111111-1111-1111-1111-111111111111',50,59.99,'C','Good',4),
('11111111-1111-1111-1111-111111111111',40,49.99,'D','Pass',5),
('11111111-1111-1111-1111-111111111111',0,39.99,'F','Needs Improvement',6)
on conflict do nothing;
