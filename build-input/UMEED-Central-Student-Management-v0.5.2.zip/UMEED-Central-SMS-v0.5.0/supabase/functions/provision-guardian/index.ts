import { adminClient, cors, json, requireUser } from '../_shared/clients.ts'

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  try {
    const { client: caller, user } = await requireUser(req)
    const admin = adminClient()
    const { organizationId, fullName, email, loginId, studentIds, relation = 'guardian' } = await req.json()
    if (!organizationId || !fullName || !Array.isArray(studentIds) || !studentIds.length) throw new Error('Guardian and linked students are required')
    const { data: membership } = await caller.from('organization_memberships').select('role').eq('organization_id',organizationId).eq('user_id',user.id).eq('active',true).maybeSingle()
    if (!membership || !['owner','super_admin','admin'].includes(membership.role)) throw new Error('Not authorized')
    const { data: org } = await admin.from('organizations').select('slug').eq('id',organizationId).single()
    if (!org) throw new Error('Organization not found')
    const identifier = email?.trim() || `${String(loginId || fullName).toLowerCase().replace(/[^a-z0-9._-]/g,'')}.guardian@${org.slug}.students.invalid`
    const temporaryPassword = crypto.randomUUID().replaceAll('-','').slice(0,12)+'aA1!'
    const { data: created, error } = await admin.auth.admin.createUser({ email: identifier, password: temporaryPassword, email_confirm: !email, app_metadata:{ account_type:'guardian',organization_id:organizationId } })
    if (error || !created.user) throw error ?? new Error('Guardian creation failed')
    await admin.from('profiles').insert({ id:created.user.id,full_name:fullName, email: identifier })
    await admin.from('organization_memberships').insert({ organization_id:organizationId,user_id:created.user.id,role:'guardian' })
    const links = studentIds.map((studentId:string)=>({ organization_id:organizationId,student_id:studentId,auth_user_id:created.user!.id,relation }))
    const { error: linkError } = await admin.from('student_guardians').insert(links)
    if (linkError) throw linkError
    await admin.from('audit_logs').insert({ organization_id:organizationId,actor_id:user.id,action:'guardian.provisioned',entity_type:'user',entity_id:created.user.id,after_data:{ students:studentIds,relation } })
    return json({ guardianUserId:created.user.id, login:identifier, temporaryPassword, linkedStudents:studentIds.length })
  } catch(error) { return json({ error:error instanceof Error?error.message:'Unknown error' },400) }
})
