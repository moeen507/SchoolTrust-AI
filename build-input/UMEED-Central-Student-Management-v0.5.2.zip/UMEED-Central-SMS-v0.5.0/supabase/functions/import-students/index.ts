import { adminClient, cors, json, requireUser } from '../_shared/clients.ts'

type Row = { admission_no?:string; roll_no?:string; full_name?:string; guardian_name?:string; guardian_phone?:string; guardian_email?:string; class_name?:string; section_name?:string }

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  try {
    const { client: caller, user } = await requireUser(req)
    const admin = adminClient()
    const { organizationId, rows, filename = 'upload.csv', dryRun = true } = await req.json() as { organizationId:string; rows:Row[]; filename?:string; dryRun?:boolean }
    if (!organizationId || !Array.isArray(rows) || rows.length === 0) throw new Error('No import rows supplied')
    if (rows.length > 5000) throw new Error('Maximum 5,000 rows per import')
    const { data: membership } = await caller.from('organization_memberships').select('role').eq('organization_id',organizationId).eq('user_id',user.id).eq('active',true).maybeSingle()
    if (!membership || !['owner','super_admin','admin','accountant'].includes(membership.role)) throw new Error('Not authorized')

    const { data: classes } = await admin.from('classes').select('id,name').eq('organization_id',organizationId)
    const { data: sections } = await admin.from('sections').select('id,name,class_id').eq('organization_id',organizationId)
    const classMap = new Map((classes??[]).map((c:any)=>[c.name.trim().toLowerCase(),c]))
    const sectionMap = new Map((sections??[]).map((s:any)=>[`${s.class_id}:${s.name.trim().toLowerCase()}`,s]))
    const seen = new Set<string>(); const valid:any[]=[]; const errors:any[]=[]
    rows.forEach((row,index)=>{
      const admission = String(row.admission_no??'').trim(); const name=String(row.full_name??'').trim();
      if(!admission || !name){errors.push({row:index+2,error:'Admission number and full name are required'});return}
      if(seen.has(admission.toLowerCase())){errors.push({row:index+2,error:'Duplicate admission number in file'});return} seen.add(admission.toLowerCase())
      const cls=row.class_name?classMap.get(String(row.class_name).trim().toLowerCase()):undefined
      if(row.class_name && !cls){errors.push({row:index+2,error:`Unknown class: ${row.class_name}`});return}
      const sec=cls&&row.section_name?sectionMap.get(`${cls.id}:${String(row.section_name).trim().toLowerCase()}`):undefined
      if(row.section_name && !sec){errors.push({row:index+2,error:`Unknown section: ${row.section_name}`});return}
      valid.push({ organization_id:organizationId,admission_no:admission,roll_no:row.roll_no||null,full_name:name,guardian_name:row.guardian_name||null,guardian_phone:row.guardian_phone||null,guardian_email:row.guardian_email||null,class_id:cls?.id??null,section_id:sec?.id??null,status:'active' })
    })
    const { data: job, error:jobError } = await admin.from('import_jobs').insert({ organization_id:organizationId,kind:'students',filename,status:dryRun?'preview':'importing',total_rows:rows.length,valid_rows:valid.length,invalid_rows:errors.length,errors,created_by:user.id }).select('id').single()
    if(jobError) throw jobError
    if(!dryRun && errors.length===0){
      const { error:insertError } = await admin.from('students').insert(valid)
      if(insertError){ await admin.from('import_jobs').update({status:'failed',errors:[{error:insertError.message}]}).eq('id',job.id); throw insertError }
      await admin.from('import_jobs').update({status:'completed',completed_at:new Date().toISOString()}).eq('id',job.id)
      await admin.from('audit_logs').insert({organization_id:organizationId,actor_id:user.id,action:'students.bulk_imported',entity_type:'import_job',entity_id:job.id,after_data:{rows:valid.length,filename}})
    }
    return json({ jobId:job.id,dryRun,total:rows.length,valid:valid.length,invalid:errors.length,errors:errors.slice(0,100) })
  } catch(error){ return json({error:error instanceof Error?error.message:'Unknown error'},400) }
})
