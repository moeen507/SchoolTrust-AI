import { adminClient, cors, json, requireSecretRequest } from '../_shared/clients.ts'

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  try {
    requireSecretRequest(req)
    const admin=adminClient(); const limit=50
    const { data:items,error }=await admin.from('notification_queue').select('*').eq('status','pending').lte('next_attempt_at',new Date().toISOString()).order('created_at').limit(limit)
    if(error) throw error
    const gateway=Deno.env.get('NOTIFICATION_GATEWAY_URL'); const token=Deno.env.get('NOTIFICATION_GATEWAY_TOKEN')
    let sent=0,failed=0
    for(const item of items??[]){
      await admin.from('notification_queue').update({status:'processing',attempts:(item.attempts??0)+1}).eq('id',item.id)
      try{
        if(item.channel==='in_app'){
          await admin.from('notifications').insert({organization_id:item.organization_id,user_id:item.user_id,student_id:item.student_id,kind:item.template_key,title:item.subject??'Notification',body:item.body,payload:item.payload})
        }else{
          if(!gateway) throw new Error('NOTIFICATION_GATEWAY_URL is not configured')
          const response=await fetch(gateway,{method:'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:`Bearer ${token}`}:{})},body:JSON.stringify({channel:item.channel,destination:item.destination,subject:item.subject,body:item.body,payload:item.payload,organizationId:item.organization_id})})
          if(!response.ok) throw new Error(`Gateway HTTP ${response.status}: ${(await response.text()).slice(0,240)}`)
        }
        await admin.from('notification_queue').update({status:'sent',sent_at:new Date().toISOString(),last_error:null}).eq('id',item.id); sent++
      }catch(err){
        const attempts=(item.attempts??0)+1; const final=attempts>=5
        await admin.from('notification_queue').update({status:final?'failed':'pending',last_error:err instanceof Error?err.message:'Unknown gateway error',next_attempt_at:new Date(Date.now()+Math.min(60,2**attempts)*60_000).toISOString()}).eq('id',item.id); failed++
      }
    }
    return json({processed:(items??[]).length,sent,failed})
  }catch(error){return json({error:error instanceof Error?error.message:'Unknown error'},401)}
})
