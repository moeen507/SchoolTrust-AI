import { adminClient, cors, json, requireUser } from '../_shared/clients.ts'

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  try {
    const { client: caller, user } = await requireUser(req)
    const admin = adminClient()
    const { studentId, organizationId, loginId } = await req.json()
    if (!studentId || !organizationId || !loginId) throw new Error('Missing required fields')
    const { data: membership } = await caller.from('organization_memberships').select('role')
      .eq('organization_id', organizationId).eq('user_id', user.id).eq('active', true).maybeSingle()
    if (!membership || !['owner','super_admin','admin'].includes(membership.role)) throw new Error('Not authorized')

    const { data: org } = await admin.from('organizations').select('slug').eq('id', organizationId).single()
    const { data: student } = await admin.from('students').select('full_name,auth_user_id').eq('id', studentId).eq('organization_id', organizationId).single()
    if (!org || !student) throw new Error('Organization or student not found')
    if (student.auth_user_id) throw new Error('Student access is already provisioned')

    const normalized = String(loginId).trim().toLowerCase().replace(/[^a-z0-9._-]/g, '')
    if (normalized.length < 3) throw new Error('Login ID is too short')
    const loginEmail = `${normalized}@${org.slug}.students.invalid`
    const temporaryPassword = crypto.randomUUID().replaceAll('-', '').slice(0, 12) + 'aA1!'
    const { data: created, error: createError } = await admin.auth.admin.createUser({
      email: loginEmail, password: temporaryPassword, email_confirm: true,
      app_metadata: { account_type: 'student', organization_id: organizationId, login_id: loginId },
    })
    if (createError || !created.user) throw createError ?? new Error('User creation failed')
    await admin.from('profiles').insert({ id: created.user.id, full_name: student.full_name, email: loginEmail })
    await admin.from('organization_memberships').insert({ organization_id: organizationId, user_id: created.user.id, role: 'student' })
    const { error: studentError } = await admin.from('students').update({ auth_user_id: created.user.id, login_id: loginId }).eq('id', studentId).eq('organization_id', organizationId)
    if (studentError) throw studentError
    await admin.from('audit_logs').insert({ organization_id: organizationId, actor_id: user.id, action: 'student.access.provisioned', entity_type: 'student', entity_id: studentId, after_data: { login_id: loginId } })
    return json({ loginId, temporaryPassword })
  } catch (error) { return json({ error: error instanceof Error ? error.message : 'Unknown error' }, 400) }
})
