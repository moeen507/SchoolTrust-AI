import { adminClient, cors, json, requireUser } from '../_shared/clients.ts'

Deno.serve(async(req)=>{
  if(req.method==='OPTIONS') return new Response('ok',{headers:cors})
  try{
    const {client:caller,user}=await requireUser(req); const admin=adminClient(); const {organizationId}=await req.json()
    const {data:member}=await caller.from('organization_memberships').select('role').eq('organization_id',organizationId).eq('user_id',user.id).eq('active',true).maybeSingle()
    const {data:platform}=await caller.from('platform_admins').select('role').eq('user_id',user.id).eq('active',true).maybeSingle()
    if(!member || !['owner','super_admin'].includes(member.role)) { if(!platform || platform.role!=='platform_owner') throw new Error('Not authorized') }
    const tables=['organizations','academic_sessions','classes','sections','students','student_guardians','fee_categories','fee_structures','invoices','invoice_items','payments','payment_allocations','student_credits','credit_allocations','refunds','invoice_adjustments','daily_closings','cashier_shifts','audit_logs']
    const bundle:any={schema:'umeed-central-export-v1',organizationId,exportedAt:new Date().toISOString(),tables:{}}
    for(const table of tables){
      let query=admin.from(table).select('*')
      if(table==='organizations') query=query.eq('id',organizationId); else query=query.eq('organization_id',organizationId)
      const {data,error}=await query.limit(100000); if(error) throw new Error(`${table}: ${error.message}`); bundle.tables[table]=data??[]
    }
    await admin.from('audit_logs').insert({organization_id:organizationId,actor_id:user.id,action:'tenant.exported',entity_type:'organization',entity_id:organizationId,after_data:{tables:tables.length}})
    return json(bundle)
  }catch(error){return json({error:error instanceof Error?error.message:'Unknown error'},400)}
})
