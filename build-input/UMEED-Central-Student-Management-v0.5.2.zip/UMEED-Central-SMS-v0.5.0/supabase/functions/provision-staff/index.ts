import { adminClient, cors, json, requireUser } from '../_shared/clients.ts'

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  try {
    const { client: caller, user } = await requireUser(req)
    const admin = adminClient()
    const { organizationId, email, fullName, role } = await req.json()
    const allowedRoles = ['super_admin','admin','cashier','accountant','auditor','academic_manager','teacher','store_clerk','canteen_cashier']
    if (!organizationId || !email || !fullName || !allowedRoles.includes(role)) throw new Error('Invalid staff payload')

    const { data: membership } = await caller.from('organization_memberships').select('role')
      .eq('organization_id', organizationId).eq('user_id', user.id).eq('active', true).maybeSingle()
    if (!membership || !['owner','super_admin'].includes(membership.role)) throw new Error('Not authorized')

    const temporaryPassword = crypto.randomUUID().replaceAll('-', '').slice(0, 12) + 'aA1!'
    const { data: created, error } = await admin.auth.admin.createUser({
      email, password: temporaryPassword, email_confirm: false,
      app_metadata: { account_type: 'staff', organization_id: organizationId },
    })
    if (error || !created.user) throw error ?? new Error('User creation failed')

    const { error: profileError } = await admin.from('profiles').insert({ id: created.user.id, full_name: fullName, email })
    if (profileError) throw profileError
    const { error: memberError } = await admin.from('organization_memberships').insert({ organization_id: organizationId, user_id: created.user.id, role })
    if (memberError) throw memberError
    await admin.from('audit_logs').insert({ organization_id: organizationId, actor_id: user.id, action: 'staff.provisioned', entity_type: 'user', entity_id: created.user.id, after_data: { email, role } })
    return json({ userId: created.user.id, temporaryPassword })
  } catch (error) { return json({ error: error instanceof Error ? error.message : 'Unknown error' }, 400) }
})
