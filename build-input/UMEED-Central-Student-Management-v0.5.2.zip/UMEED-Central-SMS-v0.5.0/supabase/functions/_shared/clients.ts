import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.116.0'

function namedKey(envName: string, legacyNames: string[]) {
  const raw = Deno.env.get(envName)
  if (raw) {
    try {
      const parsed = JSON.parse(raw)
      if (typeof parsed === 'object' && parsed) {
        const first = parsed.default ?? Object.values(parsed)[0]
        if (typeof first === 'string') return first
      }
    } catch {
      if (raw.startsWith('sb_')) return raw
    }
  }
  for (const name of legacyNames) {
    const value = Deno.env.get(name)
    if (value) return value
  }
  throw new Error(`Missing Supabase key: ${envName}`)
}

export const supabaseUrl = () => {
  const url = Deno.env.get('SUPABASE_URL')
  if (!url) throw new Error('SUPABASE_URL is missing')
  return url
}

export const publishableKey = () => namedKey('SUPABASE_PUBLISHABLE_KEYS', ['SUPABASE_PUBLISHABLE_KEY', 'SUPABASE_ANON_KEY'])
export const secretKey = () => namedKey('SUPABASE_SECRET_KEYS', ['SUPABASE_SECRET_KEY', 'SUPABASE_SERVICE_ROLE_KEY'])

export function userClient(authorization: string) {
  return createClient(supabaseUrl(), publishableKey(), {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { headers: { Authorization: authorization } },
  })
}

export function adminClient() {
  return createClient(supabaseUrl(), secretKey(), {
    auth: { persistSession: false, autoRefreshToken: false },
  })
}

export async function requireUser(req: Request) {
  const auth = req.headers.get('Authorization')
  if (!auth) throw new Error('Authentication required')
  const client = userClient(auth)
  const { data: { user }, error } = await client.auth.getUser()
  if (error || !user) throw new Error('Invalid session')
  return { client, user }
}

export function requireSecretRequest(req: Request) {
  const supplied = req.headers.get('apikey') ?? ''
  if (!supplied || supplied !== secretKey()) throw new Error('Invalid backend secret')
}

export const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

export const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { ...cors, 'Content-Type': 'application/json' },
})
