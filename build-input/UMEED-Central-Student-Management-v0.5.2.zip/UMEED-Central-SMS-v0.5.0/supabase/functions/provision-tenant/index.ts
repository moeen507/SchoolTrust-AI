import { adminClient, cors, json, requireUser } from '../_shared/clients.ts'

Deno.serve(async(req)=>{
  if(req.method==='OPTIONS') return new Response('ok',{headers:cors})
  try{
    const {client:caller,user}=await requireUser(req); const admin=adminClient()
    const {data:platform}=await caller.from('platform_admins').select('role').eq('user_id',user.id).eq('active',true).maybeSingle()
    if(!platform || platform.role!=='platform_owner') throw new Error('Platform owner access required')
    const {name,slug,ownerName,ownerEmail,planId='growth',timezone='Asia/Karachi',currency='PKR'}=await req.json()
    if(!name||!slug||!ownerName||!ownerEmail) throw new Error('Tenant and owner details are required')
    const cleanSlug=String(slug).trim().toLowerCase().replace(/[^a-z0-9-]/g,'-')
    const {data:org,error:orgError}=await admin.from('organizations').insert({name,slug:cleanSlug,plan:planId,timezone,currency,status:'active'}).select('id,name,slug').single(); if(orgError) throw orgError
    const temp=crypto.randomUUID().replaceAll('-','').slice(0,12)+'aA1!'
    const {data:created,error:createError}=await admin.auth.admin.createUser({email:ownerEmail,password:temp,email_confirm:false,app_metadata:{account_type:'staff',organization_id:org.id}}); if(createError||!created.user) throw createError??new Error('Owner creation failed')
    await admin.from('profiles').insert({id:created.user.id,full_name:ownerName,email:ownerEmail})
    await admin.from('organization_memberships').insert({organization_id:org.id,user_id:created.user.id,role:'owner'})
    await admin.from('subscriptions').upsert({organization_id:org.id,plan_id:planId,status:'trialing',trial_ends_at:new Date(Date.now()+30*86400_000).toISOString(),current_period_start:new Date().toISOString(),current_period_end:new Date(Date.now()+30*86400_000).toISOString()})
    await admin.from('audit_logs').insert({organization_id:org.id,actor_id:user.id,action:'tenant.provisioned',entity_type:'organization',entity_id:org.id,after_data:{name,slug:cleanSlug,planId,ownerEmail}})
    return json({organization:org,ownerUserId:created.user.id,temporaryPassword:temp})
  }catch(error){return json({error:error instanceof Error?error.message:'Unknown error'},400)}
})
