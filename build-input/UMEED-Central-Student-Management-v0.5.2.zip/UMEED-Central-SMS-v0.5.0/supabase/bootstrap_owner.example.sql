-- Bootstrap examples. Create the Auth user first in Supabase Auth, then replace placeholders.
-- Use ONE appropriate section.

-- A) Platform SaaS owner, can provision/suspend/export tenants.
insert into public.profiles(id,full_name)
values('<AUTH_USER_UUID>'::uuid,'SaaS Platform Owner')
on conflict(id) do update set full_name=excluded.full_name;

insert into public.platform_admins(user_id,role,active)
values('<AUTH_USER_UUID>'::uuid,'platform_owner',true)
on conflict(user_id) do update set role='platform_owner',active=true;

-- B) Tenant owner for the seeded UMEED organization.
-- insert into public.profiles(id,full_name)
-- values('<TENANT_OWNER_AUTH_UUID>'::uuid,'UMEED Owner')
-- on conflict(id) do update set full_name=excluded.full_name;
--
-- insert into public.organization_memberships(organization_id,user_id,role,active)
-- values('11111111-1111-1111-1111-111111111111','<TENANT_OWNER_AUTH_UUID>'::uuid,'owner',true)
-- on conflict(organization_id,user_id) do update set role='owner',active=true;
